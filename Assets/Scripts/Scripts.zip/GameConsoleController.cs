using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Встроенная отладочная консоль (открывается клавишей `).
// Команды: help, save, load, regen, step, stop, next, prev, clear, quit.
// Горячие клавиши (консоль закрыта): Space — шаг, +/= — следующая система, - — предыдущая.

public class GameConsoleController : MonoBehaviour
{
    [Tooltip("Ссылка на SystemViewManager. Если не задана — ищется автоматически в Start().")]
    public SystemViewManager ViewManager;
    [Tooltip("Клавиша открытия/закрытия консоли.")]
    public KeyCode ToggleKey = KeyCode.BackQuote;

    // Устаревшее событие — оставлено для обратной совместимости.
    public static event Action OnTurnPerformed;

    private bool _showConsole;
    private string _input = "";
    private Vector2 _scroll;
    private readonly List<string> _logs = new List<string>();
    private const int MaxLog = 50;

    private int _starIndex = 0; // индекс текущей звезды в StarsMap.Values
    private Dictionary<string, (Action act, string desc)> _cmds;

    void Awake() => RegisterCommands();

    void Start()
    {
        if (!ViewManager) ViewManager = FindObjectOfType<SystemViewManager>();
        StartCoroutine(WaitForInit());
    }

    System.Collections.IEnumerator WaitForInit()
    {
        while (GalaxyManager.Instance?.CurrentStar == null) yield return null;
        var list = GalaxyManager.Instance.GeneratedGalaxy.StarsMap.Values.ToList();
        _starIndex = list.IndexOf(GalaxyManager.Instance.CurrentStar);
        if (_starIndex < 0) _starIndex = 0;
        Log($"Viewing: {GalaxyManager.Instance.CurrentStar.Name}");
    }

    void Update()
    {
        if (Input.GetKeyDown(ToggleKey)) { _showConsole = !_showConsole; _input = ""; }

        if (_showConsole) return;

        // Space — НЕ обрабатываем здесь: GalaxyManager.HandleSpaceBarInput() делает это сам.
        // Оставляем только навигацию по системам.
        if (Input.GetKeyDown(KeyCode.Equals) || Input.GetKeyDown(KeyCode.KeypadPlus)) ChangeSystem(1);
        if (Input.GetKeyDown(KeyCode.Minus) || Input.GetKeyDown(KeyCode.KeypadMinus)) ChangeSystem(-1);
    }


    void ChangeSystem(int dir)
    {
        var g = GalaxyManager.Instance?.GeneratedGalaxy;
        if (g == null || g.StarsMap.Count == 0) { Log("No Galaxy."); return; }
        var list = g.StarsMap.Values.ToList();
        _starIndex = (_starIndex + dir + list.Count) % list.Count;
        var s = list[_starIndex];
        Log($"Viewing: {s.Name} ({_starIndex})");
        GalaxyManager.Instance.SetCurrentStar(s);
    }

    void RegisterCommands()
    {
        _cmds = new Dictionary<string, (Action, string)>(StringComparer.OrdinalIgnoreCase);

        Reg("save", "Save Game", () => GalaxyManager.Instance.SaveGame());
        Reg("load", "Load Game", () => { GalaxyManager.Instance.LoadGame(); OnTurnPerformed?.Invoke(); });
        Reg("regen", "New Galaxy (rand seed)", () => GalaxyManager.Instance.GenerateNewGalaxy((int)DateTime.Now.Ticks));

        // step: снимаем все паузы и запускаем ход (аналог нажатия Space в Planning).
        Reg("step", "Start next turn", () =>
        {
            if (GalaxyManager.Instance.Phase == TurnPhase.Animating)
            {
                Log("Turn already running.");
                return;
            }
            Log("Turn started.");
            OnTurnPerformed?.Invoke();
            GalaxyManager.Instance.ClearAllPauses();
            GalaxyManager.Instance.StartTurn();
        });

        // stop: запрашиваем паузу — авторежим остановится после текущей анимации.
        Reg("stop", "Stop auto mode", () =>
        {
            GalaxyManager.Instance.RequestPause(PauseReason.PlayerInput);
            Log("Auto mode stop requested.");
        });

        // pause info: показывает активные причины паузы.
        Reg("pauses", "Show active pauses", () =>
        {
            var gm = GalaxyManager.Instance;
            Log(gm.IsAutoMode
                ? "No active pauses (auto mode running)."
                : $"Phase: {gm.Phase}. Auto mode OFF.");
        });

        Reg("next", "Next Star", () => ChangeSystem(1));
        Reg("prev", "Prev Star", () => ChangeSystem(-1));
        Reg("clear", "Clear Log", () => _logs.Clear());
        Reg("quit", "Exit", Application.Quit);
        Reg("help", "Show Help", () => { foreach (var c in _cmds) Log($"{c.Key}: {c.Value.desc}"); });
    }

    void Reg(string k, string d, Action a) => _cmds[k] = (a, d);

    void Exec(string line)
    {
        if (string.IsNullOrWhiteSpace(line)) return;
        string key = line.Trim().Split(' ')[0];
        if (_cmds.TryGetValue(key, out var cmd)) { Log($">> {line}"); cmd.act(); }
        else Log($"Unknown command: {key}. Type 'help' for list.");
    }

    void Log(string m)
    {
        _logs.Add(m);
        if (_logs.Count > MaxLog) _logs.RemoveAt(0);
        _scroll.y = float.MaxValue;
    }

    void OnGUI()
    {
        if (!_showConsole) return;
        float h = Screen.height * 0.4f;
        GUI.Box(new Rect(0, 0, Screen.width, h), "");
        GUILayout.BeginArea(new Rect(10, 10, Screen.width - 20, h - 20));

        _scroll = GUILayout.BeginScrollView(_scroll);
        foreach (var l in _logs) GUILayout.Label(l);
        GUILayout.EndScrollView();

        GUI.SetNextControlName("ConsoleInput");
        _input = GUILayout.TextField(_input);
        GUI.FocusControl("ConsoleInput");

        if (Event.current.type == EventType.KeyDown &&
            (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter))
        {
            Exec(_input);
            _input = "";
            Event.current.Use();
        }

        GUILayout.EndArea();
    }
}