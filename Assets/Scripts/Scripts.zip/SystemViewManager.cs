using UnityEngine;
using System.Collections.Generic;

public class SystemViewManager : MonoBehaviour
{
    public static SystemViewManager Instance { get; private set; }

    [Header("Components")]
    public Transform SystemContainer;
    public SystemMinimapController MinimapController;

    [Header("Prefabs")]
    public GameObject StarPrefab;
    public GameObject PlanetPrefab;
    public GameObject SatellitePrefab;
    // Должен содержать ShipVisualController и CircleCollider2D (IsTrigger=true).
    // Контроллер поведения (PlayerShip, NpcController и т.д.) навешивается в рантайме.
    public GameObject ShipPrefab;
    /// <summary>
    /// Префаб астероида. Должен содержать AsteroidVisualController и SpriteRenderer.
    /// Если null — астероиды не отображаются визуально (симуляция всё равно работает).
    /// </summary>
    public GameObject AsteroidPrefab;

    /// <summary>
    /// Префаб взрыва (AsteroidExplosionController + SpriteRenderer).
    /// Если null — объект создаётся динамически без префаба.
    /// </summary>
    public GameObject ExplosionPrefab;

    /// <summary>
    /// Префаб предмета в космосе (DroppedItemVisualController + SpriteRenderer).
    /// Если null — объект создаётся динамически без префаба.
    /// </summary>
    public GameObject DroppedItemPrefab;

    [Header("Visual Settings")]
    public Color BaseSpaceColor = Color.black;

    [Header("Config")]
    [SerializeField] private GameSettingsConfig _settings;

    private readonly List<GameObject> _spawnedObjects = new();
    // Fix #20: убран _planetTransforms — дублировал данные _planetList и нигде не использовался.
    private readonly List<(PlanetData planet, Transform t)> _planetList = new();
    private readonly List<(ShipData ship, Transform t, ShipVisualController visual)> _shipList = new();

    /// <summary>
    /// Активные визуальные контроллеры астероидов.
    /// Ключ — AsteroidData.Uid. Заполняется в SpawnAsteroids и SpawnAsteroidVisual.
    /// </summary>
    private readonly Dictionary<string, AsteroidVisualController> _asteroidControllers = new();

    private BackgroundVisualController _bgController;
    private float _currentWorldSize;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    public void RenderSystem(StarData star)
    {
        ClearScene();
        if (star == null) return;

        _currentWorldSize = star.SystemSize / 100f;

        SpawnStar(star);
        SpawnPlanets(star);
        SpawnShips(star);
        SpawnAsteroids(star);

        MinimapController?.InitializeMinimap(star, _currentWorldSize);

        if (_bgController == null || _bgController.gameObject == null)
        {
            _bgController = new GameObject("BackgroundVisualController").AddComponent<BackgroundVisualController>();
        }
        _bgController.Setup(Camera.main, star.Name.GetHashCode());

        UpdatePlanetPositions();
    }

    // ── SPAWN ─────────────────────────────────────────────────────────────────

    private void SpawnStar(StarData star)
    {
        if (StarPrefab == null) return;
        var (frames, speed) = GraphicsManager.Instance.GetStarVisuals(star.Color, star.GraphVar);
        float scale = GraphicsManager.Instance.GetStarScale(star.Type);
        var obj = Instantiate(StarPrefab, SystemContainer);
        obj.name = $"Star_{star.Name}";
        obj.transform.localPosition = Vector3.zero;
        obj.GetComponent<StarVisualController>()?.Setup(frames, speed, scale);

        // Цветное название звезды. StarLabelRenderer — опциональный компонент на префабе;
        // если его нет — добавляем динамически.
        var label = obj.GetComponent<StarLabelRenderer>() ?? obj.AddComponent<StarLabelRenderer>();
        label.Setup(star);

        _spawnedObjects.Add(obj);
    }

    private void SpawnPlanets(StarData star)
    {
        if (PlanetPrefab == null) return;
        foreach (var planet in star.Planets)
        {
            var obj = Instantiate(PlanetPrefab, SystemContainer);
            obj.name = $"Planet_{planet.Name}";
            obj.GetComponent<PlanetVisualController>()?.Setup(planet, SatellitePrefab);
            // Fix #20: убрана запись в _planetTransforms, остался только _planetList.
            _planetList.Add((planet, obj.transform));
            _spawnedObjects.Add(obj);
        }
    }

    private void SpawnShips(StarData star)
    {
        if (ShipPrefab == null) return;
        foreach (var ship in star.Ships)
        {
            // Fix #2: если игрок уже существует и его объект жив — просто обновляем позицию.
            if (ship.IsPlayer)
            {
                if (PlayerShip.Instance != null && PlayerShip.Instance.gameObject != null)
                {
                    PlayerShip.Instance.transform.position = new Vector3(ship.Position.x, ship.Position.y, 0f);
                    continue;
                }
                // Instance есть, но объект уничтожен — упадём ниже и создадим заново.
            }

            var obj = SpawnShip(ship);
            if (ship.IsPlayer)
            {
                obj.name = "PlayerShip";
                obj.AddComponent<PlayerShip>().Init(ship, Camera.main, _settings);
                Object.DontDestroyOnLoad(obj);
            }
            else obj.name = $"Ship_{ship.Uid}";
            // TODO: навесить NpcController / StationController по ship.Role
        }
    }

    // Инстанциирует ShipPrefab, настраивает визуал. Контроллер навешивается снаружи.
    private GameObject SpawnShip(ShipData ship)
    {
        var obj = Instantiate(ShipPrefab, SystemContainer);
        obj.transform.localPosition = new Vector3(ship.Position.x, ship.Position.y, 0f);
        var visual = obj.GetComponent<ShipVisualController>();
        visual?.Setup(ship, ship.IsPlayer);
        _shipList.Add((ship, obj.transform, visual));
        _spawnedObjects.Add(obj);
        return obj;
    }

    /// <summary>
    /// Спавнит визуальные объекты для всех активных астероидов системы.
    /// Вызывается из RenderSystem при входе в систему.
    /// </summary>
    /// <summary>
    /// Спавнит визуальные объекты для всех активных астероидов системы.
    /// Вызывается из RenderSystem при входе в систему.
    /// </summary>
    private void SpawnAsteroids(StarData star)
    {
        if (AsteroidPrefab == null || star.Asteroids == null) return;

        foreach (var asteroid in star.Asteroids)
        {
            if (!asteroid.IsDestroyed)
                SpawnAsteroidVisual(asteroid);
        }
    }

    /// <summary>
    /// Инстанциирует префаб астероида и инициализирует AsteroidVisualController.
    /// </summary>
    private void SpawnAsteroidVisual(AsteroidData asteroid)
    {
        if (AsteroidPrefab == null) return;

        var obj = Instantiate(AsteroidPrefab, SystemContainer);
        obj.name = $"Asteroid_{asteroid.Uid}";
        obj.transform.localPosition = new Vector3(asteroid.Position.x, asteroid.Position.y, 0f);

        var ctrl = obj.GetComponent<AsteroidVisualController>();
        if (ctrl != null)
        {
            ctrl.Setup(asteroid);
            _asteroidControllers[asteroid.Uid] = ctrl;
            // Сообщаем миникарте о новом астероиде
            MinimapController?.OnAsteroidSpawned(asteroid);
        }
        else
        {
            Debug.LogError("[SpawnAsteroidVisual] AsteroidPrefab missing AsteroidVisualController component!");
        }

        _spawnedObjects.Add(obj);
    }

    // ── ANIMATION ─────────────────────────────────────────────────────────────

    public void UpdatePlanetPositions()
    {
        // Снэп в финальные позиции — вызывается из GalaxyManager.CompleteCurrentTurn().
        // LastTurnData может быть null при первом рендере системы — используем прямые данные планет.
        var anim = GalaxyManager.Instance?.LastTurnData;
        AnimateSystem(1f, GalaxyData.TurnRounds, anim);
    }

    public void AnimateSystem(float progress, int currentTick, TurnAnimationData anim)
    {
        // ── Планеты ───────────────────────────────────────────────────────────────
        foreach (var (planet, t) in _planetList)
        {
            if (planet == null || t == null || t.gameObject == null) continue;

            float fromAngle = planet.PreviousAngle;
            float toAngle = planet.CurrentAngle;

            // Если есть данные анимации — берём углы из них (более точно при быстром ходе).
            if (anim != null && anim.PlanetAngles.TryGetValue(planet.Uid, out var angles))
            {
                fromAngle = angles.From;
                toAngle = angles.To;
            }

            float a = planet.OrbitRadius > 0f ? planet.OrbitRadius / 100f : 2f + planet.OrbitIndex * 1.5f;
            float e = Mathf.Clamp(planet.OrbitEccentricity, 0f, 0.99f);
            float b = a * Mathf.Sqrt(1f - e * e);
            float c = a * e;

            float angle = Mathf.LerpAngle(fromAngle, toAngle, progress);
            float rad = angle * Mathf.Deg2Rad;
            float lx = Mathf.Cos(rad) * a - c;
            float ly = Mathf.Sin(rad) * b;

            float tiltRad = planet.OrbitTiltDeg * Mathf.Deg2Rad;
            float cosT = Mathf.Cos(tiltRad), sinT = Mathf.Sin(tiltRad);
            var worldPos = new Vector3(lx * cosT - ly * sinT, lx * sinT + ly * cosT, 0f);

            t.localPosition = worldPos;
            MinimapController?.UpdatePlanetPosition(planet, worldPos);
        }

        // ── Корабли NPC ───────────────────────────────────────────────────────────
        // Игрок анимируется сам через PlayerShip.OnTurnAnimate.
        foreach (var (ship, t, visual) in _shipList)
        {
            if (ship == null || t == null || t.gameObject == null || ship.IsPlayer) continue;

            Vector2 pos;

            if (anim != null && anim.ShipFrames.TryGetValue(ship.Uid, out var frames))
            {
                // Интерполируем позицию между раундом (tick-1) и раундом tick.
                float tickProgress = Mathf.Clamp01((progress * GalaxyData.TurnRounds) - (currentTick - 1));
                pos = Vector2.Lerp(frames.Rounds[currentTick - 1], frames.Rounds[currentTick], tickProgress);
            }
            else
            {
                // Fallback: простой Lerp от старой до новой позиции (как было раньше).
                pos = Vector2.Lerp(ship.PreviousPosition, ship.Position, progress);
            }

            t.localPosition = new Vector3(pos.x, pos.y, 0f);

            var delta = ship.Position - ship.PreviousPosition;
            if (delta.sqrMagnitude > 0.0001f)
            {
                visual?.SetMovementDirection(delta);
                visual?.SetThrustersActive(true);
            }
            else
            {
                visual?.SetThrustersActive(false);
            }
        }

        // ── Смерти NPC — показываем в тике 10 ────────────────────────────────────
        // (вызывается из GalaxyManager.OnTurnComplete, не здесь — это заглушка на будущее)
        // TODO: if (currentTick == GalaxyData.TurnRounds && anim != null)
        //           foreach (var uid in anim.DeathUids) SpawnExplosion(uid);

        // ── Астероиды ─────────────────────────────────────────────────────────────

        if (anim != null)
        {
            // Спавн новых астероидов появившихся в этом ходу
            foreach (var spawnEvt in anim.AsteroidSpawns)
            {
                if (!_asteroidControllers.ContainsKey(spawnEvt.AsteroidUid))
                {
                    var star = GalaxyManager.Instance?.CurrentStar;
                    if (star != null)
                    {
                        var asteroid = star.Asteroids.Find(a => a.Uid == spawnEvt.AsteroidUid);
                        if (asteroid != null)
                            SpawnAsteroidVisual(asteroid);
                    }
                }
            }

            // Уничтожение астероидов (коллизия или тихий выход за границу)
            foreach (var destroyEvt in anim.AsteroidDestroys)
            {
                if (_asteroidControllers.TryGetValue(destroyEvt.AsteroidUid, out var ctrl))
                {
                    // Взрыв — только при реальном столкновении
                    if (destroyEvt.CollisionType != AsteroidCollisionType.None)
                        SpawnExplosionEffect(destroyEvt.Position, destroyEvt.CollisionType);

                    // Дроп предметов — минералы и оборудование как объекты сцены
                    SpawnDroppedItems(destroyEvt.Position, destroyEvt.DroppedStacks,
                        destroyEvt.DroppedItems);

                    if (ctrl != null && ctrl.gameObject != null)
                    {
                        _spawnedObjects.Remove(ctrl.gameObject);
                        Destroy(ctrl.gameObject);
                    }
                    _asteroidControllers.Remove(destroyEvt.AsteroidUid);
                }
            }
        }

        // Обновляем позиции живых астероидов
        var currentStar = GalaxyManager.Instance?.CurrentStar;
        if (currentStar?.Asteroids != null)
        {
            foreach (var asteroid in currentStar.Asteroids)
            {
                if (asteroid.IsDestroyed) continue;
                if (!_asteroidControllers.TryGetValue(asteroid.Uid, out var ctrl) || ctrl == null) continue;

                Vector2 pos;
                if (anim != null && anim.AsteroidFrames.TryGetValue(asteroid.Uid, out var frames))
                {
                    // Покадровая интерполяция — точно как для кораблей NPC.
                    float tickProgress = Mathf.Clamp01((progress * GalaxyData.TurnRounds) - (currentTick - 1));
                    pos = Vector2.Lerp(frames.Rounds[currentTick - 1], frames.Rounds[currentTick], tickProgress);
                }
                else
                {
                    // Fallback: грубый lerp (первый ход после спавна, кадры ещё не заполнены)
                    pos = Vector2.Lerp(asteroid.PreviousPosition, asteroid.Position, progress);
                }

                ctrl.UpdateVisualPosition(pos);
            }
        }
    }

    /// <summary>
    /// Возвращает текущую визуальную (интерполированную) позицию астероида.
    /// Используется миникартой для плавного обновления иконок.
    /// Возвращает false если контроллер не найден.
    /// </summary>
    public bool TryGetAsteroidVisualPosition(string uid, out Vector2 position)
    {
        if (_asteroidControllers.TryGetValue(uid, out var ctrl) && ctrl != null)
        {
            position = ctrl.transform.localPosition;
            return true;
        }
        position = Vector2.zero;
        return false;
    }

    // ── EXPLOSION & DROP SPAWN ────────────────────────────────────────────────

    /// <summary>
    /// Создаёт визуал взрыва в точке position.
    /// Использует ExplosionPrefab если назначен, иначе создаёт пустой GameObject.
    /// AsteroidExplosionController загружает спрайты сам через Resources и уничтожает
    /// себя по завершении анимации — объект НЕ добавляется в _spawnedObjects.
    /// </summary>
    public void SpawnExplosionEffect(Vector2 position, AsteroidCollisionType collisionType)
    {
        GameObject obj = ExplosionPrefab != null
            ? Instantiate(ExplosionPrefab, SystemContainer)
            : new GameObject("AsteroidExplosion");

        if (ExplosionPrefab == null)
            obj.transform.SetParent(SystemContainer, false);

        obj.transform.localPosition = new Vector3(position.x, position.y, 0f);

        var ctrl = obj.GetComponent<AsteroidExplosionController>()
                   ?? obj.AddComponent<AsteroidExplosionController>();
        ctrl.Play();
        // Объект уничтожает себя сам — не добавляем в _spawnedObjects
    }

    /// <summary>
    /// Создаёт визуальные объекты для каждого выпавшего предмета — минерала или оборудования.
    /// Предметы разлетаются веером от position.
    /// Используется DroppedItemPrefab если назначен.
    /// Объекты добавляются в _spawnedObjects и очищаются при смене системы.
    /// </summary>
    public void SpawnDroppedItems(
        Vector2 position,
        System.Collections.Generic.List<ItemStack> stacks,
        System.Collections.Generic.List<ItemInstance> items)
    {
        var ctx = GalaxyManager.Instance?.Context;

        int totalCount = (stacks?.Count ?? 0) + (items?.Count ?? 0);
        if (totalCount == 0) return;

        float angleStep = totalCount > 1 ? 360f / totalCount : 0f;
        float baseAngle = Random.Range(0f, 360f);
        int idx = 0;

        // ── Минералы ─────────────────────────────────────────────────────────
        if (stacks != null)
        {
            foreach (var stack in stacks)
            {
                if (stack == null || stack.TotalWeight <= 0) { idx++; continue; }

                var obj = SpawnDroppedItemObject($"Drop_{stack.ItemId}");
                obj.transform.localPosition = new Vector3(position.x, position.y, 0f);

                float angle = (baseAngle + angleStep * idx) * Mathf.Deg2Rad;
                float speed = Random.Range(0.5f, 1.4f);
                var drift = new Vector2(Mathf.Cos(angle) * speed, Mathf.Sin(angle) * speed);

                var ctrl = obj.GetComponent<DroppedItemVisualController>()
                           ?? obj.AddComponent<DroppedItemVisualController>();
                ctrl.SetupStack(stack, drift, ctx);

                _spawnedObjects.Add(obj);
                idx++;
            }
        }

        // ── Оборудование ─────────────────────────────────────────────────────
        if (items != null)
        {
            foreach (var item in items)
            {
                if (item == null) { idx++; continue; }

                var obj = SpawnDroppedItemObject($"Drop_{item.Category}");
                obj.transform.localPosition = new Vector3(position.x, position.y, 0f);

                float angle = (baseAngle + angleStep * idx) * Mathf.Deg2Rad;
                float speed = Random.Range(0.5f, 1.4f);
                var drift = new Vector2(Mathf.Cos(angle) * speed, Mathf.Sin(angle) * speed);

                var ctrl = obj.GetComponent<DroppedItemVisualController>()
                           ?? obj.AddComponent<DroppedItemVisualController>();
                ctrl.SetupItem(item, drift);

                _spawnedObjects.Add(obj);
                idx++;
            }
        }
    }

    private GameObject SpawnDroppedItemObject(string name)
    {
        if (DroppedItemPrefab != null)
            return Instantiate(DroppedItemPrefab, SystemContainer);

        var obj = new GameObject(name);
        obj.transform.SetParent(SystemContainer, false);
        return obj;
    }

    private void ClearScene()
    {
        foreach (var obj in _spawnedObjects)
            if (obj != null && obj.GetComponent<PlayerShip>() == null)
                Destroy(obj);

        _spawnedObjects.Clear();
        _planetList.Clear();
        _shipList.Clear();
        _asteroidControllers.Clear();
        MinimapController?.ClearMinimap();
    }
}