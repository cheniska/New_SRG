using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

// Модели для десериализации конфигурационных JSON-файлов:
//   GalaxyConfig.json, TextsConfig.json, PremadeConfig.json, EquipmentConfig.json.

// ── ROOT CONFIGS ─────────────────────────────────────────────────────────────

// InitialDate дублирует Settings.InitialDate — сохранено для совместимости со старыми сохранениями.
public class GalaxyConfig
{
    [JsonProperty("InitialDate")] public string InitialDate { get; set; } = "01.01.0001";
    [JsonProperty("Races")] public Dictionary<string, RaceConfig> Races { get; set; }
    [JsonProperty("Galaxies")] public Dictionary<string, GalaxyConfigData> Galaxies { get; set; }
    [JsonProperty("Stars")] public StarConfigSection Stars { get; set; }
    [JsonProperty("Planets")] public PlanetConfigSection Planets { get; set; }
    [JsonProperty("Satellites")] public SatelliteConfigSection Satellites { get; set; }
    [JsonProperty("Ships")] public ShipConfigSection Ships { get; set; }
    /// <summary>Конфигурация астероидов системы. Null — астероиды отключены.</summary>
    [JsonProperty("Asteroids")] public AsteroidConfigSection Asteroids { get; set; }
    /// <summary>Параметры визуальной анимации взрыва астероида.</summary>
    [JsonProperty("Explosion")] public ExplosionConfig Explosion { get; set; }
    // Ключ 1-го уровня — категория ("Stars", "Planets"), 2-го — имя свойства.
    [JsonProperty("CustomProperties")] public Dictionary<string, Dictionary<string, CustomPropertyConfig>> CustomProperties { get; set; }
    [JsonProperty("Settings")] public SettingsConfigSection Settings { get; set; }
    [JsonProperty("TechLevels")] public TechLevelsConfig TechLevels { get; set; }
}

public class TextConfig
{
    [JsonProperty("ConstNames")] public Dictionary<string, string> ConstNames { get; set; }     // общий пул созвездий
    [JsonProperty("StarsNames")] public Dictionary<string, RaceNamesData> StarsNames { get; set; }   // ключ "Common" — общий пул
    [JsonProperty("PlanetsNames")] public Dictionary<string, RaceNamesData> PlanetsNames { get; set; }
    [JsonProperty("RaceNames")] public Dictionary<string, string> RaceNames { get; set; }      // ключ — внутренний ключ расы
}

// Fixed — привязанные имена (ключ → имя, для PremadeConfig), Pool — случайный пул генерации.
public class RaceNamesData
{
    [JsonProperty("Fixed")] public Dictionary<string, string> Fixed { get; set; } = new();
    [JsonProperty("Pool")] public List<string> Pool { get; set; } = new();
}

public class PremadeConfig
{
    [JsonProperty("Galaxies")] public Dictionary<string, PremadeGalaxyData> Galaxies { get; set; }
}

public class PremadeGalaxyData
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("Constellations")] public Dictionary<string, FixedConstellationData> Constellations { get; set; }
}

// ── SECTIONS & DATA ───────────────────────────────────────────────────────────

public class GalaxyConfigData
{
    [JsonProperty("GalaxySize")] public int[] GalaxySize { get; set; } // [width, height]
    [JsonProperty("StarsCount")] public int StarsCount { get; set; }
    [JsonProperty("ConstCount")] public int ConstCount { get; set; }
    [JsonProperty("MinStarsPerConstellation")] public int MinStarsPerConstellation { get; set; }
    [JsonProperty("MaxStarsPerConstellation")] public int MaxStarsPerConstellation { get; set; }
    [JsonProperty("MinPlanetsPerStar")] public int MinPlanetsPerStar { get; set; }
    [JsonProperty("MaxPlanetsPerStar")] public int MaxPlanetsPerStar { get; set; }
}

public class StarConfigSection
{
    [JsonProperty("Types")] public Dictionary<string, StarTypeData> Types { get; set; }   // Normal, Dwarf, Big, Giant
    [JsonProperty("Colors")] public Dictionary<string, StarColorData> Colors { get; set; } // White, Red, Green…
}

public class SettingsConfigSection
{
    [JsonProperty("SystemSizeMult")] public int SystemSizeMult { get; set; }       // множитель расстояний между орбитами
    [JsonProperty("InitialDate")] public string InitialDate { get; set; } = "01.01.0001";
    /// <summary>Стоимость топлива за единицу дистанции прыжка. ceil(dist * JumpFuelCostPerUnit).</summary>
    [JsonProperty("JumpFuelCostPerUnit")] public float JumpFuelCostPerUnit { get; set; } = 1.0f;
}

public class StarTypeData
{
    [JsonProperty("GraphicSizeMult")] public float GraphicSizeMult { get; set; }
    [JsonProperty("MaxPlanets")] public int MaxPlanets { get; set; }
}

public class StarColorData
{
    [JsonProperty("VariantsCount")] public int VariantsCount { get; set; }
    [JsonProperty("Path")] public string Path { get; set; } // базовый путь без /VarN
}

public class PlanetConfigSection
{
    [JsonProperty("OrbitsEccentricity")] public float[] OrbitsEccentricity = { 0f, 0f }; // [min, max]
    [JsonProperty("Sizes")] public Dictionary<string, PlanetSizeData> Sizes { get; set; }
    [JsonProperty("Types")] public List<string> Types { get; set; }

    public float EccentricityMin => OrbitsEccentricity?.Length > 0 ? OrbitsEccentricity[0] : 0f;
    public float EccentricityMax => OrbitsEccentricity?.Length > 1 ? OrbitsEccentricity[1] : 0f;
}

public class PlanetSizeData
{
    [JsonProperty("BaseScale")] public float BaseScale { get; set; }
    [JsonProperty("MaxSatellites")] public int MaxSatellites { get; set; }
    [JsonProperty("AtmosphereChance")] public int AtmosphereChance { get; set; }  // 0..100
    [JsonProperty("SatOrbitPixelRadius")] public float PixelRadius { get; set; }
}

public class SatelliteConfigSection
{
    [JsonProperty("Sizes")] public Dictionary<string, SatelliteSizeData> Sizes { get; set; }
}

public class SatelliteSizeData
{
    [JsonProperty("BaseScale")] public float BaseScale { get; set; }
}

// ── ASTEROID CONFIG ───────────────────────────────────────────────────────────

/// <summary>
/// Секция конфига астероидов из GalaxyConfig.json.
/// Содержит глобальные параметры генерации и таблицу типов астероидов.
/// Астероиды генерируются только в системах с игроком.
/// </summary>
public class AsteroidConfigSection
{
    /// <summary>Шанс спавна нового астероида каждый ход (0..1). Проверяется после MaxAsteroids.</summary>
    [JsonProperty("SpawnChancePerTurn")]
    public float SpawnChancePerTurn { get; set; } = 0.3f;

    /// <summary>
    /// Константа гравитации звезды.
    /// Влияет на величину ускорения астероида при сближении со звездой:
    ///   acceleration = GravityConst / distance²
    /// </summary>
    [JsonProperty("GravityConst")]
    public float GravityConst { get; set; } = 500f;

    /// <summary>
    /// Демпфирующая константа для формулы урона при столкновении:
    ///   damage = (Mass × Speed²) / DampingConstant × (1 - AsteroidProtection)
    /// Чем больше — тем меньше урон при тех же параметрах астероида.
    /// </summary>
    [JsonProperty("DampingConstant")]
    public float DampingConstant { get; set; } = 10000f;

    /// <summary>Типы астероидов. Ключ — TypeId (Rocky, Metallic и т.д.).</summary>
    [JsonProperty("Types")]
    public Dictionary<string, AsteroidTypeConfig> Types { get; set; } = new();

    // ── HELPERS ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Выбирает случайный TypeId с учётом весов SpawnWeight.
    /// Аналогично ApplyWeightedStarColor для звёзд.
    /// Возвращает null если Types пуст или суммарный вес = 0.
    /// </summary>
    public string RollRandomTypeId()
    {
        if (Types == null || Types.Count == 0) return null;

        int total = 0;
        foreach (var t in Types.Values) total += t.SpawnWeight;
        if (total <= 0) return null;

        int roll = UnityEngine.Random.Range(0, total);
        int sum = 0;
        foreach (var kv in Types)
        {
            sum += kv.Value.SpawnWeight;
            if (roll < sum) return kv.Key;
        }
        return null;
    }
}

/// <summary>
/// Конфигурация одного типа астероида.
/// Все вероятности дропа независимы — при уничтожении проверяется каждая отдельно,
/// поэтому могут выпасть несколько типов лута одновременно.
/// </summary>
public class AsteroidTypeConfig
{
    [JsonProperty("Name")] public string Name { get; set; }

    // ── Физика ───────────────────────────────────────────────────────────────

    /// <summary>Диапазон масс. Влияет на урон при столкновении.</summary>
    [JsonProperty("MassMin")] public float MassMin { get; set; } = 50f;
    [JsonProperty("MassMax")] public float MassMax { get; set; } = 200f;

    /// <summary>Начальная скорость при спавне (мировых единиц за ход).</summary>
    [JsonProperty("SpeedMin")] public float SpeedMin { get; set; } = 1.5f;
    [JsonProperty("SpeedMax")] public float SpeedMax { get; set; } = 4.0f;

    /// <summary>Скорость визуального вращения спрайта (градусов в секунду). Знак случайный.</summary>
    [JsonProperty("SelfRotationSpeedMin")] public float SelfRotationSpeedMin { get; set; } = 20f;
    [JsonProperty("SelfRotationSpeedMax")] public float SelfRotationSpeedMax { get; set; } = 120f;

    /// <summary>Радиус коллизии в мировых единицах.</summary>
    [JsonProperty("CollisionRadius")] public float CollisionRadius { get; set; } = 0.3f;

    // ── Графика ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Путь к папке со спрайтами этого типа (Resources).
    /// Конкретный спрайт выбирается случайно из папки при спавне.
    /// </summary>
    [JsonProperty("GraphicPath")] public string GraphicPath { get; set; }

    // ── Лут ───────────────────────────────────────────────────────────────────

    /// <summary>Независимый шанс дропа обычного минерала (CommonMineral) [0..1].</summary>
    [JsonProperty("CommonMineralChance")] public float CommonMineralChance { get; set; } = 0.9f;

    /// <summary>Независимый шанс дропа драгоценного минерала (PreciousMineral) [0..1].</summary>
    [JsonProperty("PreciousMineralChance")] public float PreciousMineralChance { get; set; } = 0.05f;

    /// <summary>Независимый шанс дропа случайного предмета оборудования [0..1].</summary>
    [JsonProperty("EquipmentDropChance")] public float EquipmentDropChance { get; set; } = 0.02f;

    // ── Спавн ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Вес для взвешенного рандома при выборе типа.
    /// Шанс = SpawnWeight / сумма всех SpawnWeight.
    /// </summary>
    [JsonProperty("SpawnWeight")] public int SpawnWeight { get; set; } = 50;

    /// <summary>FPS анимации спрайтлиста. По умолчанию 12.</summary>
    [JsonProperty("AnimFps")] public float AnimFps { get; set; } = 12f;
}

// ── EXPLOSION CONFIG ──────────────────────────────────────────────────────────

/// <summary>
/// Параметры анимации взрыва из GalaxyConfig.json.
/// Путь к спрайтлисту задаётся в GameSettingsConfig.ExplosionSpritePath — там же где все
/// остальные пути к графике. Здесь только игровые параметры воспроизведения.
/// </summary>
public class ExplosionConfig
{
    /// <summary>FPS воспроизведения спрайтлиста. Переопределяет GameSettingsConfig.ExplosionFPS.</summary>
    [JsonProperty("FPS")] public float FPS { get; set; } = 12f;

    /// <summary>Масштаб объекта взрыва в мировых единицах. Переопределяет GameSettingsConfig.ExplosionScale.</summary>
    [JsonProperty("Scale")] public float Scale { get; set; } = 1.5f;
}

// ── TECH LEVELS ───────────────────────────────────────────────────────────────

/// <summary>
/// Конфигурация технических уровней галактики.
/// Count — максимальный TechLevel в галактике.
/// Предметы с TechLevel > GalaxyTechLevel не генерируются нигде.
/// Планета не продаёт предметы выше своего TechLevel.
/// </summary>
public class TechLevelsConfig
{
    [JsonProperty("Count")] public int Count { get; set; } = 8;
}

// ── SHIPS CONFIG ──────────────────────────────────────────────────────────────

public class ShipConfigSection
{
    // Ключ — идентификатор стороны (Coalition, Pirates, Dominators).
    [JsonProperty("ConflictSides")] public Dictionary<string, ConflictSideConfig> ConflictSides { get; set; }
    // Ключ "SideA-SideB", значение — уровень отношений (0=враги, 100=союзники).
    [JsonProperty("SideRelations")] public Dictionary<string, int> SideRelations { get; set; }
    // Ключ — FactionId, значение — конфиг фракции.
    [JsonProperty("Factions")] public Dictionary<string, FactionConfig> Factions { get; set; }
    // Ключ "FactionA-FactionB" → явное попарное переопределение отношений.
    [JsonProperty("FactionRelations")] public Dictionary<string, int> FactionRelations { get; set; }
    // Реестр типов слотов. Конкретные предметы — в EquipmentConfig.json.
    [JsonProperty("Equipment")] public Dictionary<string, EquipmentSlotConfig> Equipment { get; set; }
    [JsonProperty("ShipTypes")] public Dictionary<string, ShipTypeConfig> ShipTypes { get; set; }
    // FactionId → список ShipTypeId.
    [JsonProperty("FactionLineups")] public Dictionary<string, List<string>> FactionLineups { get; set; }
}

public class ConflictSideConfig
{
    [JsonProperty("DefaultInternalRelation")] public int DefaultInternalRelation { get; set; } // 0=враги, 100=союзники
    [JsonProperty("Color")] public string Color { get; set; }         // "R,G,B" или null
    [JsonProperty("StarNameStyle")] public string StarNameStyle { get; set; } // см. StarNameStyle enum
}

public class FactionConfig
{
    [JsonProperty("ConflictSideId")] public string ConflictSideId { get; set; }
    [JsonProperty("RaceId")] public string RaceId { get; set; }         // null = безрасовая
    [JsonProperty("Color")] public string Color { get; set; }           // "R,G,B" или null
    [JsonProperty("EmblemPath")] public string EmblemPath { get; set; } // null = нет значка

    /// <summary>
    /// Множители производителя для предметов этой фракции.
    /// Применяются поверх расовых множителей.
    /// Если null — 1.0 по всем параметрам.
    /// </summary>
    [JsonProperty("EquipmentManufacturing")]
    public EquipmentManufacturingConfig EquipmentManufacturing { get; set; }
}

// Стиль отображения названия звезды в зависимости от принадлежности системы.
public enum StarNameStyle
{
    SolidSide,              // весь текст в цвете стороны
    SideWithFactionAccent,  // цвет стороны + первая буква в цвете фракции
    SideWithFactionIcon,    // цвет стороны + значок фракции
    FactionSolid,           // цвет фракции (если null — цвет стороны)
    RaceGradient,           // текст разбит на N частей по числу рас в системе
    RaceGradientWithIcon,   // то же + значок фракции
    SideWithRaceIcon,       // цвет стороны + значок расы системы
}

public class EquipmentSlotConfig
{
    [JsonProperty("Count")] public int Count { get; set; } = 1;
}

public class ShipTypeConfig
{
    [JsonProperty("SpritesheetPath")] public string SpritesheetPath { get; set; }
    [JsonProperty("MinimapIconPath")] public string MinimapIconPath { get; set; }
    [JsonProperty("BaseHull")] public int BaseHull { get; set; } = 100;
    [JsonProperty("BaseWeight")] public int BaseWeight { get; set; } = 500;
    [JsonProperty("DefaultEngineSpeed")] public int DefaultEngineSpeed { get; set; } = 400;
    /// <summary>
    /// Анимационные клипы корабля. Использует тот же тип что и runtime-данные ShipData.Animations —
    /// дополнительного копирования при спавне не требуется.
    /// </summary>
    [JsonProperty("Animations")] public Dictionary<string, ShipAnimationClip> Animations { get; set; }
    [JsonProperty("Thrusters")] public List<ShipThrusterConfig> Thrusters { get; set; }

    /// <summary>
    /// Стартовый набор снаряжения для этого типа корабля.
    /// Ключ — категория (Hull, Engine, …), значение — ItemId.
    /// Используется ItemFactory.EquipStarterKit при спавне.
    /// Если null — корабль создаётся без оборудования.
    /// </summary>
    [JsonProperty("StarterKit")]
    public Dictionary<string, string> StarterKit { get; set; }
}

// ShipAnimationClipConfig удалён — используйте ShipAnimationClip из GalaxyDataModels.cs.
// Поля идентичны; объединение устраняет ручное копирование в ShipFactory.

public class ShipThrusterConfig
{
    [JsonProperty("OffsetX")] public float OffsetX { get; set; }
    [JsonProperty("OffsetY")] public float OffsetY { get; set; }
    [JsonProperty("SpritesheetPath")] public string SpritesheetPath { get; set; }
    [JsonProperty("FPS")] public float FPS { get; set; } = 12f;
}

// ── EQUIPMENT MANUFACTURING ───────────────────────────────────────────────────

/// <summary>
/// Множители производителя для расы или фракции.
/// Влияют на итоговую цену и MaxDurability создаваемых ItemInstance.
///
/// finalPrice         = basePrice         × race.PriceMult      × faction.PriceMult
/// finalMaxDurability = baseMaxDurability × race.DurabilityMult × faction.DurabilityMult
///
/// Если раса/фракция не задана или поле EquipmentManufacturing == null — множитель 1.0.
/// </summary>
public class EquipmentManufacturingConfig
{
    [JsonProperty("PriceMult")] public float PriceMult { get; set; } = 1.0f;
    [JsonProperty("DurabilityMult")] public float DurabilityMult { get; set; } = 1.0f;
}

// ── RACE CONFIG ───────────────────────────────────────────────────────────────

public class RaceConfig
{
    [JsonProperty("EmblemPath")] public string EmblemPath { get; set; }
    [JsonProperty("Color")] public string Color { get; set; } // "R,G,B" (0-255) или null

    /// <summary>
    /// Множители производителя для предметов этой расы.
    /// Если null — 1.0 по всем параметрам.
    /// </summary>
    [JsonProperty("EquipmentManufacturing")]
    public EquipmentManufacturingConfig EquipmentManufacturing { get; set; }
}

// ── CUSTOM PROPERTIES ─────────────────────────────────────────────────────────

// Поддерживает три формата Default:
//   1. Строка:  "Default": "No"
//   2. Объект:  "Default": { "FieldName": { "FieldValue": "Result" } }
//   3. Массив:  "Default": [ { "Conditions": {...}, "Result": "..." } ]
public class CustomPropertyConfig
{
    [JsonProperty("Values")] public List<string> Values { get; set; }
    [JsonProperty("Default")] public JToken Default { get; set; }
}

// Условия объединяются через AND. Значения внутри одного условия — через OR.
// Пустой словарь условий — всегда совпадает (catch-all).
public class CustomPropertyRule
{
    [JsonProperty("Conditions")] public Dictionary<string, List<string>> Conditions { get; set; } = new();
    [JsonProperty("Result")] public string Result { get; set; } // "Random" = случайное из Values
}

// ── FIXED DATA STRUCTURES (PremadeConfig) ────────────────────────────────────

public class FixedConstellationData
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("StarsCount")] public int? StarsCount { get; set; } // переопределяет случайное кол-во
    [JsonProperty("Stars")] public Dictionary<string, FixedStarData> Stars { get; set; }
    [JsonProperty("Owner")] public string Owner;
}

public class FixedStarData
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("Type")] public string Type { get; set; }
    [JsonProperty("Color")] public string Color { get; set; }
    [JsonProperty("PlanetsCount")] public int? PlanetsCount { get; set; }
    // Строка вида "1,3" — слоты без планет (отображается в UI системы).
    [JsonProperty("PlanetsNoneCount")] public string PlanetsNoneCount { get; set; }
    [JsonProperty("GraphVar")] public int? GraphVar;
    [JsonProperty("Planets")] public Dictionary<string, FixedPlanetData> Planets { get; set; }
    [JsonProperty("Owner")] public string Owner;

    /// <summary>
    /// Переопределяет дефолтное максимальное число астероидов для этой системы.
    /// Null = использовать GalaxyConstants.DEFAULT_MAX_ASTEROIDS.
    /// </summary>
    [JsonProperty("MaxAsteroids")]
    public int? MaxAsteroids { get; set; }
}

// null-поля генерируются по общим правилам.
public class FixedPlanetData
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("Size")] public string Size { get; set; }
    [JsonProperty("Race")] public string Race { get; set; }
    [JsonProperty("CurOwner")] public string CurOwner { get; set; }
    [JsonProperty("Graphic")] public string Graphic { get; set; }
    [JsonProperty("Atmosphere")] public string Atmosphere { get; set; }
    [JsonProperty("OrbitalObjects")] public string OrbitalObjects { get; set; }
    [JsonProperty("SatellitesCount")] public int? SatellitesCount { get; set; }
    [JsonProperty("OrbitIndex")] public int? OrbitIndex { get; set; }
    [JsonProperty("OrbitRadius")] public float? OrbitRadius { get; set; }
    [JsonProperty("OrbitSpeed")] public float? OrbitSpeed { get; set; }
    [JsonProperty("DaySpeed")] public int? DaySpeed { get; set; }  // дней на полный оборот
    [JsonProperty("CloudsSpeed")] public int? CloudsSpeed { get; set; }
    [JsonProperty("Satellites")] public Dictionary<string, FixedSatelliteData> Satellites { get; set; }
    [JsonProperty("Type")] public string Type { get; set; }
}

// null-поля генерируются по общим правилам.
public class FixedSatelliteData
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("CurOwner")] public string CurOwner { get; set; }
    [JsonProperty("Graphic")] public string Graphic { get; set; }
    [JsonProperty("Atmosphere")] public string Atmosphere { get; set; }
    [JsonProperty("OrbitRadius")] public float? OrbitRadius { get; set; }
    [JsonProperty("OrbitSpeed")] public float? OrbitSpeed { get; set; }
    [JsonProperty("Size")] public string Size { get; set; }
    [JsonProperty("DaySpeed")] public int? DaySpeed { get; set; }
    [JsonProperty("CloudsSpeed")] public int? CloudsSpeed { get; set; }
}

// ── EQUIPMENT CONFIG MODELS ───────────────────────────────────────────────────
// Модели для десериализации нового EquipmentConfig.json.
//
// Структура файла:
//   EquipmentTypes  — метаданные категорий (износ, лимиты слотов, флаги)
//   HullSeries      — серии корпусов (слоты, уязвимости)
//   Equipment       — конкретные предметы по категориям
//
// Загрузка через GalaxyConfigLoader вместе с остальными конфигами.
// Экземпляр хранится в GalaxyGenerationContext.Equipment (тип EquipmentConfig).

// ── ROOT ──────────────────────────────────────────────────────────────────────

public class EquipmentConfig
{
    /// <summary>Метаданные категорий оборудования. Ключ — ID категории (Hull, Engine, …).</summary>
    [JsonProperty("EquipmentTypes")]
    public Dictionary<string, EquipmentTypeConfig> EquipmentTypes { get; set; } = new();

    /// <summary>Серии корпусов. Ключ — ID серии (Light, Combat, Freighter, Universal).</summary>
    [JsonProperty("HullSeries")]
    public Dictionary<string, HullSeriesConfig> HullSeries { get; set; } = new();

    /// <summary>
    /// Предметы по категориям. Внешний ключ — ID категории, внутренний — ID предмета.
    /// Пример: Equipment["Engine"]["E_Fast"].
    /// </summary>
    [JsonProperty("Equipment")]
    public Dictionary<string, Dictionary<string, EquipmentItemConfig>> Equipment { get; set; } = new();

    // ── HELPERS ───────────────────────────────────────────────────────────────

    /// <summary>Возвращает конфиг предмета или null если не найден.</summary>
    public EquipmentItemConfig GetItem(string category, string itemId)
    {
        if (Equipment.TryGetValue(category, out var cat) &&
            cat.TryGetValue(itemId, out var item))
            return item;
        return null;
    }

    /// <summary>Возвращает метаданные категории или null.</summary>
    public EquipmentTypeConfig GetTypeConfig(string category) =>
        EquipmentTypes.TryGetValue(category, out var t) ? t : null;

    /// <summary>Возвращает конфиг серии корпуса или null.</summary>
    public HullSeriesConfig GetSeries(string seriesId) =>
        HullSeries.TryGetValue(seriesId, out var s) ? s : null;

    /// <summary>
    /// Возвращает случайный предмет оборудования из всех категорий.
    /// Используется для дропа из астероидов (EquipmentDropChance).
    /// Возвращает null если Equipment пуст.
    /// </summary>
    public (string category, string itemId, EquipmentItemConfig config)? GetRandomItem()
    {
        var all = new List<(string cat, string id, EquipmentItemConfig cfg)>();
        foreach (var cat in Equipment)
            foreach (var item in cat.Value)
                all.Add((cat.Key, item.Key, item.Value));
        if (all.Count == 0) return null;
        var pick = all[UnityEngine.Random.Range(0, all.Count)];
        return pick;
    }
}

// ── EQUIPMENT TYPE (категория) ────────────────────────────────────────────────

/// <summary>Метаданные одной категории оборудования (Engine, Shield, …).</summary>
public class EquipmentTypeConfig
{
    [JsonProperty("DisplayName")] public string DisplayName { get; set; }

    /// <summary>Глобальный максимум слотов данной категории на любом корабле.</summary>
    [JsonProperty("MaxSlots")] public int MaxSlots { get; set; } = 1;

    /// <summary>
    /// Пассивный износ в % от MaxDurability за ход для установленных предметов.
    /// 0 = нет пассивного износа. Устарел — оставлен для совместимости конфига.
    /// </summary>
    [JsonProperty("WearPerTurnPct")] public float WearPerTurnPct { get; set; } = 0f;

    /// <summary>Единиц прочности за ход движения (Engine, FuelTank, Radar, Scaner).</summary>
    [JsonProperty("WearOnMove")] public int WearOnMove { get; set; } = 0;

    /// <summary>Единиц прочности за каждый принятый удар (Shield).</summary>
    [JsonProperty("WearOnHit")] public int WearOnHit { get; set; } = 0;

    /// <summary>Единиц прочности за каждый выстрел (Weapons).</summary>
    [JsonProperty("WearOnShot")] public int WearOnShot { get; set; } = 0;

    /// <summary>Может ли предмет этой категории получить урон от оружия противника.</summary>
    [JsonProperty("CanBeDamagedByWeapon")] public bool CanBeDamagedByWeapon { get; set; } = false;
}

// ── HULL SERIES (серия корпуса) ───────────────────────────────────────────────

/// <summary>Серия корпуса — задаёт набор слотов и уязвимости к типам урона.</summary>
public class HullSeriesConfig
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("Description")] public string Description { get; set; }

    /// <summary>
    /// Уязвимость к типам урона. Ключ — DamageType (Kinetic/Energy/Missile).
    /// Дефолт для отсутствующего типа = 1.0.
    /// </summary>
    [JsonProperty("WeaponVulnerability")]
    public Dictionary<string, float> WeaponVulnerability { get; set; } = new();

    /// <summary>
    /// Число слотов по категориям для этой серии.
    /// Ключ — ID категории, значение — количество слотов (0 = слот заблокирован).
    /// </summary>
    [JsonProperty("Slots")]
    public Dictionary<string, int> Slots { get; set; } = new();

    /// <summary>Возвращает уязвимость к типу урона (1.0 если не задана).</summary>
    public float GetVulnerability(string damageType) =>
        WeaponVulnerability.TryGetValue(damageType, out var v) ? v : 1.0f;

    /// <summary>Количество слотов категории для этой серии (0 = нет слотов).</summary>
    public int GetSlotCount(string category) =>
        Slots.TryGetValue(category, out var n) ? n : 0;
}

// ── EQUIPMENT ITEM (конкретный предмет в конфиге) ─────────────────────────────

/// <summary>
/// Описание конкретного предмета оборудования в конфиге.
/// Это шаблон — из него создаются рантаймовые ItemInstance.
/// </summary>
public class EquipmentItemConfig
{
    [JsonProperty("Name")] public string Name { get; set; }
    [JsonProperty("Description")] public string Description { get; set; }

    /// <summary>Вес в единицах вместимости корабля.</summary>
    [JsonProperty("Weight")] public int Weight { get; set; }

    /// <summary>Базовая цена покупки (до применения множителей производителя).</summary>
    [JsonProperty("Price")] public int Price { get; set; }

    [JsonProperty("Durability")] public int Durability { get; set; }
    [JsonProperty("MaxDurability")] public int MaxDurability { get; set; }

    /// <summary>Минимальный технический уровень локации для появления предмета в продаже/луте.</summary>
    [JsonProperty("TechLevel")] public int TechLevel { get; set; } = 1;

    /// <summary>Если true — предмет не изнашивается пассивно (но может быть поврежден оружием).</summary>
    [JsonProperty("NoWear")] public bool NoWear { get; set; } = false;

    /// <summary>Разрешена ли установка модулей на этот предмет.</summary>
    [JsonProperty("AllowModules")] public bool AllowModules { get; set; } = true;

    [JsonProperty("Manufacturer")] public ManufacturerConfig Manufacturer { get; set; } = new();

    // ── Только для Hull ──────────────────────────────────────────────────────

    /// <summary>Точки орудийных портов [X, Y] в пикселях спрайта. Только для корпусов.</summary>
    [JsonProperty("WeaponPorts")] public List<float[]> WeaponPorts { get; set; }

    /// <summary>Точки следов двигателей [X, Y] в пикселях спрайта. Только для корпусов.</summary>
    [JsonProperty("Tails")] public List<float[]> Tails { get; set; }

    // ── Игровые параметры ────────────────────────────────────────────────────

    /// <summary>
    /// Параметры предмета. Набор ключей зависит от категории:
    ///   Hull:         HP, Armor, Series, SizeSmall, SizeLarge, TargetSizeK, AsteroidProtection
    ///   Engine:       Speed, JumpRange
    ///   FuelTank:     Capacity
    ///   Forsage:      EngineDurabilityBurnMult
    ///   Shield:       BlockPercent
    ///   Radar:        Range
    ///   Scaner:       Power
    ///   Droid:        HealPerTurn / Damage
    ///   CargoGrabber: Power, Range, Speed
    ///   Weapons:      MinDmg, MaxDmg, Range, DamageType, ArmorPierce,
    ///                 EquipmentHitChance, EquipmentDamage
    ///   Artefacts:    свободный набор (SpeedMult, HealPerTurn, …)
    ///
    /// Числовые значения хранятся как float (DamageType — строка, читается отдельно).
    /// AsteroidProtection [0..1] — доля поглощаемого урона от астероидов (только Hull).
    /// </summary>
    [JsonProperty("Params")] public Dictionary<string, JToken> Params { get; set; } = new();

    // ── HELPERS ───────────────────────────────────────────────────────────────

    /// <summary>Читает числовой параметр. Возвращает defaultValue если ключ отсутствует.</summary>
    public float GetParam(string key, float defaultValue = 0f)
    {
        if (Params != null && Params.TryGetValue(key, out var token))
        {
            try { return token.ToObject<float>(); } catch { }
        }
        return defaultValue;
    }

    public string GetParamString(string key, string defaultValue = null)
    {
        if (Params != null && Params.TryGetValue(key, out var token))
        {
            try { return token.ToObject<string>(); } catch { }
        }
        return defaultValue;
    }

    /// <summary>Ключ серии корпуса. Только для категории Hull.</summary>
    public string HullSeries => GetParamString("Series");
}

// ── MANUFACTURER ──────────────────────────────────────────────────────────────

/// <summary>Производитель предмета. Влияет на цену и MaxDurability через множители расы/фракции.</summary>
public class ManufacturerConfig
{
    [JsonProperty("Race")] public string Race { get; set; }
    [JsonProperty("Faction")] public string Faction { get; set; }
}