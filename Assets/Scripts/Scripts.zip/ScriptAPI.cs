using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// ── PARAMS-ОБЪЕКТЫ ────────────────────────────────────────────────────────────

// Незаполненные поля генерируются по правилам игры.
public class StarParams
{
    public string Name { get; set; }
    public string Type { get; set; }
    public string Color { get; set; }
    public int? GraphVar { get; set; }
    /// <summary>FactionId или RaceId (Race1 → Race1_Main). null = генерируется из планет.</summary>
    public string FactionId { get; set; }
    public List<PlanetData> Planets { get; set; } // если задан — случайные не генерируются
    public int? PlanetsCount { get; set; }        // null = по правилам галактики
}

// Незаполненные поля генерируются по правилам игры.
public class PlanetParams
{
    public string Name { get; set; }
    public string Size { get; set; }
    public string Type { get; set; }
    public string Race { get; set; }
    /// <summary>FactionId владельца. null = берётся из Race (Race1 → Race1_Main).</summary>
    public string FactionId { get; set; }
    public string Graphic { get; set; }
    public string Atmosphere { get; set; }
    public string OrbitalObjects { get; set; }
    public float? OrbitRadius { get; set; }
    public float? OrbitSpeed { get; set; }
    public int? OrbitIndex { get; set; }
    public int? DaySpeed { get; set; }
    public int? CloudsSpeed { get; set; }
    public int? SatellitesCount { get; set; }
}

// ── SCRIPT API ────────────────────────────────────────────────────────────────

// Публичный API для скриптового языка. Инициализируется один раз после генерации галактики.
// Вся логика генерации делегируется в GalaxyGenerator — дублирования нет.
public class ScriptAPI
{
    public static ScriptAPI Instance { get; private set; }

    public static void Initialize(GalaxyGenerationContext context, GalaxyData galaxy) =>
        Instance = new ScriptAPI(context, galaxy);

    private readonly GalaxyGenerationContext _ctx;
    private readonly GalaxyData _galaxy;
    private readonly GalaxyGenerator _gen;

    private ScriptAPI(GalaxyGenerationContext context, GalaxyData galaxy)
    {
        _ctx = context;
        _galaxy = galaxy;
        _gen = new GalaxyGenerator(context);
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    /// <summary>Создаёт звезду в секторе и добавляет её в галактику.</summary>
    public StarData UserCreateStar(ConstellationData constellation, StarParams p = null)
    {
        if (constellation == null)
            throw new System.ArgumentNullException(nameof(constellation), "UserCreateStar: сектор обязателен");

        var star = new StarData { ParentConstellation = constellation };
        ApplyStarParams(star, p, constellation);
        _gen.FinalizeStar(star);
        AttachStarToGalaxy(star, constellation);
        return star;
    }

    /// <summary>Создаёт планету и прикрепляет её к звезде.</summary>
    public PlanetData UserCreatePlanet(StarData star, PlanetParams p = null)
    {
        if (star == null)
            throw new System.ArgumentNullException(nameof(star), "UserCreatePlanet: звезда обязательна");

        string size = ResolveSize(p?.Size);
        var planet = new PlanetData();
        ApplyPlanetParams(planet, p, star, size);
        _gen.FinalizePlanet(planet, size);
        AssignOrbitToNewPlanet(planet, star, p?.OrbitRadius);
        AttachPlanetToStar(planet, star);
        return planet;
    }

    // ── ЗВЕЗДА ────────────────────────────────────────────────────────────────

    private void ApplyStarParams(StarData star, StarParams p, ConstellationData c)
    {
        star.Type = ResolveStarType(p?.Type);
        star.Color = p?.Color ?? GalaxyConstants.VAL_UNKNOWN;
        star.GraphVar = p?.GraphVar ?? 0;
        // Принимаем FactionId или RaceId (Race1 → Race1_Main автоматически).
        star.FactionId = ResolveFactionParam(p?.FactionId, c.Owner);
        star.Name = p?.Name ?? GalaxyConstants.VAL_UNKNOWN;
        star.Position = c.Center + Random.insideUnitCircle * GalaxyConstants.CONSTELLATION_RADIUS;

        if (p?.Planets != null && p.Planets.Count > 0)
        {
            star.Planets = new List<PlanetData>(p.Planets);
            foreach (var planet in star.Planets) planet.ParentStar = star;
        }
        else
        {
            star.Planets = GeneratePlanetsForNewStar(star, p?.PlanetsCount);
        }
    }

    // ── ПЛАНЕТА ───────────────────────────────────────────────────────────────

    private void ApplyPlanetParams(PlanetData planet, PlanetParams p, StarData star, string size)
    {
        if (p != null)
        {
            string race = !string.IsNullOrEmpty(p.Race) ? p.Race : GalaxyConstants.RACE_NONE_KEY;
            bool isNone = race == GalaxyConstants.RACE_NONE_KEY;

            planet.Race = race;
            // FactionId: явный из params → из Race → None
            string factionId = isNone ? GalaxyConstants.RACE_NONE_KEY
                : ResolveFactionParam(p.FactionId ?? race, GalaxyGenerator.ToRaceId(star.FactionId));
            planet.FactionId = factionId;
            planet.Name = p.Name ?? GalaxyConstants.VAL_UNKNOWN;
            planet.Type = !string.IsNullOrEmpty(p.Type) ? p.Type : RandomPlanetType();
            planet.Graphic = GenerationHelpers.CleanResourcePath(p.Graphic);
            planet.Atmosphere = GenerationHelpers.CleanResourcePath(p.Atmosphere);
            planet.OrbitalObjects = GenerationHelpers.CleanResourcePath(p.OrbitalObjects);
            planet.OrbitSpeed = p.OrbitSpeed ?? 0f;
            planet.DaySpeed = p.DaySpeed ?? 0;
            planet.CloudsSpeed = p.CloudsSpeed ?? 0;
            planet.SatellitesCount = p.SatellitesCount ?? -1;
            planet.OrbitIndex = p.OrbitIndex ?? 0;
        }
        else
        {
            // Случайная планета в системе — берём расу и FactionId из звезды
            string starRace = GalaxyGenerator.ToRaceId(star.FactionId);
            string race = OwnerResolver.IsFixed(starRace, _ctx.AvailableRaces)
                ? starRace : GetRandomRaceKey();
            bool isNone = Random.value < 0.2f;

            planet.Race = isNone ? GalaxyConstants.RACE_NONE_KEY : race;
            planet.FactionId = isNone ? GalaxyConstants.RACE_NONE_KEY : _gen.ToFactionId(race);
            planet.Name = GalaxyConstants.VAL_UNKNOWN;
            planet.Type = RandomPlanetType();
            planet.OrbitSpeed = 0f;
            planet.SatellitesCount = -1;
        }
    }

    // Назначает радиус орбиты новой планете — после существующих планет звезды.
    private void AssignOrbitToNewPlanet(PlanetData planet, StarData star, float? forcedRadius)
    {
        int mult = _ctx.Config.Settings?.SystemSizeMult ?? 1;

        if (forcedRadius.HasValue && forcedRadius.Value > 0f)
        {
            planet.OrbitRadius = forcedRadius.Value;
        }
        else
        {
            float maxExisting = star.Planets.Count > 0 ? star.Planets.Max(pl => pl.OrbitRadius) : 0f;
            float gap = Random.Range(500f, 700f) * mult;
            planet.OrbitRadius = maxExisting > 0f ? maxExisting + gap : Random.Range(600f, 1000f);
        }

        if (planet.OrbitIndex <= 0)
            planet.OrbitIndex = star.Planets.Count > 0 ? star.Planets.Max(pl => pl.OrbitIndex) + 1 : 1;

        star.SystemSize = Mathf.RoundToInt(
            star.Planets.Append(planet).Max(pl => pl.OrbitRadius) + GalaxyConstants.SYSTEM_PADDING * mult);
    }

    // ── ГЕНЕРАЦИЯ ПЛАНЕТ ДЛЯ НОВОЙ ЗВЕЗДЫ ────────────────────────────────────

    private List<PlanetData> GeneratePlanetsForNewStar(StarData star, int? forcedCount)
    {
        int min = Mathf.Max(1, _ctx.ActiveGalaxyConfig?.MinPlanetsPerStar ?? 1);
        int max = _ctx.ActiveGalaxyConfig?.MaxPlanetsPerStar ?? 8;
        int total = forcedCount ?? Random.Range(min, max + 1);

        var list = new List<PlanetData>(total);
        for (int i = 0; i < total; i++)
        {
            var planet = new PlanetData();
            string size = ResolveSize(null);
            ApplyPlanetParams(planet, null, star, size);
            _gen.FinalizePlanet(planet, size);
            _gen.GeneratePlanetSatellites(planet);
            planet.OrbitIndex = i + 1;
            list.Add(planet);
        }

        _gen.AssignOrbitRadiiToList(list);
        return list;
    }

    // ── ДОБАВЛЕНИЕ В ГАЛАКТИКУ ────────────────────────────────────────────────

    private void AttachStarToGalaxy(StarData star, ConstellationData c)
    {
        c.Stars.Add(star);
        _galaxy.StarsMap[star.Uid] = star;
        foreach (var planet in star.Planets)
        {
            planet.ParentStar = star;
            if (!_galaxy.PlanetsMap.ContainsKey(planet.Uid)) _galaxy.PlanetsMap[planet.Uid] = planet;
        }
    }

    private void AttachPlanetToStar(PlanetData planet, StarData star)
    {
        planet.ParentStar = star;
        star.Planets.Add(planet);
        _galaxy.PlanetsMap[planet.Uid] = planet;
    }

    // ── ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ────────────────────────────────────────────────

    /// <summary>
    /// Резолвит FactionId из запрошенного значения.
    /// Принимает FactionId ("Race1_Main") или RaceId ("Race1").
    /// parentOwner — raceId родителя (созвездия) для fallback.
    /// </summary>
    private string ResolveFactionParam(string requested, string parentOwner)
    {
        if (requested == GalaxyConstants.RACE_NONE_KEY) return GalaxyConstants.RACE_NONE_KEY;
        if (string.IsNullOrEmpty(requested) || requested == GalaxyConstants.RACE_UNRESOLVED_KEY)
        {
            string parentFaction = _gen.ToFactionId(parentOwner ?? GalaxyConstants.RACE_UNRESOLVED_KEY);
            return string.IsNullOrEmpty(parentFaction) ? GalaxyConstants.RACE_UNRESOLVED_KEY : parentFaction;
        }
        return _gen.ToFactionId(requested);
    }

    private string ResolveStarType(string requested) =>
        !string.IsNullOrEmpty(requested) && _ctx.AvailableStarTypes.Contains(requested)
            ? requested : _ctx.AvailableStarTypes[Random.Range(0, _ctx.AvailableStarTypes.Count)];

    private string ResolveSize(string requested) =>
        !string.IsNullOrEmpty(requested) && _ctx.AvailablePlanetSizes.Contains(requested)
            ? requested : _ctx.AvailablePlanetSizes[Random.Range(0, _ctx.AvailablePlanetSizes.Count)];

    private string RandomPlanetType() =>
        _ctx.AvailablePlanetTypes[Random.Range(0, _ctx.AvailablePlanetTypes.Count)];

    private string GetRandomRaceKey()
    {
        int count = _ctx.AvailableRaces.Count;
        return count > 0
            ? _ctx.AvailableRaces.Keys.ElementAt(Random.Range(0, count))
            : GalaxyConstants.RACE_NONE_KEY;
    }
}