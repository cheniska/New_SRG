﻿using System.Collections.Generic;
using UnityEngine;

// ── EQUIPMENT SYSTEM ──────────────────────────────────────────────────────────
//
// Статический класс. Вся логика работы со снаряжением корабля.
//
// Ответственности:
//   - Установка/снятие предметов (Install / Uninstall / Swap)
//   - Расчёт вместимости и freeSpace
//   - Износ оборудования от использования (не пассивный за ход):
//       ApplyMovementWear    — Engine/FuelTank/Radar/Scaner при движении
//       ApplyShieldHitWear   — Shield за каждый принятый удар
//       ApplyWeaponShotWear  — Weapons за каждый выстрел
//       AccumulateDroidHeal  — Droid: 1 ед. за WearThreshold HP вылечено
//       AccumulateCargoGrab  — CargoGrabber: 1 ед. за WearThreshold ед. груза
//   - Применение урона к кораблю (ApplyDamage)
//   - Применение эффектов оборудования на ход (ApplyTurnEffects)
//   - Расчёт ActualSpeed с учётом двигателя, форсажа, артефактов
//
// Вызывается из:
//   ShipData.ShipNextDay          — ApplyTurnEffects(ship, equipConfig, moved)
//   CombatSystem (будущее)        — ApplyDamage, ApplyWeaponShotWear
//   Cargo system (будущее)        — AccumulateCargoGrab
//   UI (будущее)                  — Install, Uninstall, GetFreeSpace

public static class EquipmentSystem
{
    // ── INSTALL / UNINSTALL ───────────────────────────────────────────────────

    /// <summary>
    /// Устанавливает предмет из инвентаря в слот.
    /// Если слот занят — предметы меняются местами (swap).
    ///
    /// Особый случай: установка корпуса (Hull) пересобирает слоты через RebuildForSeries.
    /// Выгнанные предметы автоматически отправляются в инвентарь.
    ///
    /// Возвращает EquipResult с описанием результата.
    /// </summary>
    public static EquipResult Install(
        ShipData ship,
        string slotKey,
        string itemUid,
        EquipmentConfig equipConfig,
        bool allowInSpace = false)
    {
        if (!allowInSpace)
            return EquipResult.Fail("Смена снаряжения в космосе запрещена настройками.");

        var item = ship.Inventory.TakeByUid(itemUid);
        if (item == null)
            return EquipResult.Fail($"Предмет {itemUid} не найден в инвентаре.");

        // Проверяем что слот существует и подходит по категории
        string expectedCategory = SlotCategory(slotKey);
        if (item.Category != expectedCategory)
        {
            ship.Inventory.Add(item); // вернуть
            return EquipResult.Fail($"Категория предмета '{item.Category}' не соответствует слоту '{slotKey}'.");
        }

        if (!ship.Equipment.Slots.ContainsKey(slotKey))
        {
            ship.Inventory.Add(item);
            return EquipResult.Fail($"Слот '{slotKey}' недоступен для текущего корпуса.");
        }

        // Корпус — особый случай: пересборка слотов
        if (item.Category == "Hull")
            return InstallHull(ship, slotKey, item, equipConfig);

        // Обычный предмет — swap
        string prevUid = ship.Equipment.Set(slotKey, item.Uid);
        ship.AllItems[item.Uid] = item;

        if (prevUid != null && ship.AllItems.TryGetValue(prevUid, out var prev))
        {
            ship.AllItems.Remove(prevUid);
            ship.Inventory.Add(prev);
        }

        return EquipResult.Ok($"Установлен: {item.Name}");
    }

    private static EquipResult InstallHull(
        ShipData ship, string slotKey, ItemInstance hull, EquipmentConfig equipConfig)
    {
        string seriesId = hull.GetParamString("Series");
        var series = equipConfig.GetSeries(seriesId);
        if (series == null)
        {
            ship.Inventory.Add(hull);
            return EquipResult.Fail($"Серия корпуса '{seriesId}' не найдена в конфиге.");
        }

        // Снять старый корпус если есть
        string oldHullUid = ship.Equipment.Clear(slotKey);
        if (oldHullUid != null && ship.AllItems.TryGetValue(oldHullUid, out var oldHull))
        {
            ship.AllItems.Remove(oldHullUid);
            ship.Inventory.Add(oldHull);
        }

        // Установить новый корпус
        ship.Equipment.Set(slotKey, hull.Uid);
        ship.AllItems[hull.Uid] = hull;

        // Пересобрать слоты; лишнее — в инвентарь
        var evicted = ship.Equipment.RebuildForSeries(series, equipConfig);
        foreach (var uid in evicted)
        {
            if (ship.AllItems.TryGetValue(uid, out var evictedItem))
            {
                ship.AllItems.Remove(uid);
                ship.Inventory.Add(evictedItem);
            }
        }

        // Обновить MaxHull из параметров корпуса
        int hullHp = Mathf.RoundToInt(hull.GetParam("HP", 100));
        ship.MaxHull = hullHp;
        ship.CurrentHull = Mathf.Min(ship.CurrentHull, ship.MaxHull);

        return EquipResult.Ok($"Корпус '{hull.Name}' установлен, серия: {seriesId}.");
    }

    /// <summary>
    /// Снимает предмет из слота в инвентарь.
    /// Корпус снять нельзя (только заменить через Install).
    /// </summary>
    public static EquipResult Uninstall(ShipData ship, string slotKey, bool allowInSpace = false)
    {
        if (!allowInSpace)
            return EquipResult.Fail("Смена снаряжения в космосе запрещена настройками.");

        if (SlotCategory(slotKey) == "Hull")
            return EquipResult.Fail("Корпус нельзя снять, только заменить.");

        string uid = ship.Equipment.Clear(slotKey);
        if (uid == null)
            return EquipResult.Fail($"Слот '{slotKey}' уже пуст.");

        if (ship.AllItems.TryGetValue(uid, out var item))
        {
            ship.AllItems.Remove(uid);
            ship.Inventory.Add(item);
            return EquipResult.Ok($"Снято: {item.Name}");
        }

        return EquipResult.Fail($"Предмет {uid} не найден в AllItems.");
    }

    // ── CAPACITY ──────────────────────────────────────────────────────────────

    /// <summary>
    /// Вместимость корпуса (Weight установленного корпуса).
    /// 0 если корпус не установлен.
    /// </summary>
    public static int GetHullCapacity(ShipData ship)
    {
        var hull = GetEquipped(ship, "Hull_0");
        return hull?.Weight ?? 0;
    }

    /// <summary>
    /// Суммарный вес установленного оборудования (все непустые слоты, кроме корпуса).
    /// Вес корпуса — это его вместимость, он не считается нагрузкой на себя.
    /// </summary>
    public static int GetEquippedWeight(ShipData ship)
    {
        int total = 0;
        foreach (var kv in ship.Equipment.Slots)
        {
            if (kv.Value == null) continue;
            // Корпус не учитывается — его Weight и есть вместимость корабля
            if (SlotCategory(kv.Key) == "Hull") continue;
            if (ship.AllItems.TryGetValue(kv.Value, out var item))
                total += item.Weight;
        }
        return total;
    }

    /// <summary>
    /// Свободное место в корпусе.
    /// freeSpace = hull.Weight - equippedWeight - inventoryWeight
    /// Может быть отрицательным.
    /// </summary>
    public static int GetFreeSpace(ShipData ship)
    {
        return GetHullCapacity(ship) - GetEquippedWeight(ship) - ship.Inventory.TotalWeight();
    }

    // ── SPEED CALCULATION ─────────────────────────────────────────────────────

    /// <summary>
    /// Рассчитывает ActualSpeed корабля с учётом:
    ///   - двигателя (Engine.Speed)
    ///   - форсажа (ForsageActive удваивает EngineSpeed)
    ///   - суммарного веса (веса всего оборудования + груза)
    ///   - артефактов (SpeedMult)
    ///
    /// FIX: Если двигатель не установлен в слоты (Equipment пуст/не инициализирован),
    ///      используем ship.EngineSpeed как fallback (берётся из ShipTypeConfig.DefaultEngineSpeed).
    ///      Если двигатель установлен но сломан (Durability=0) — скорость = 0.
    /// </summary>
    public static float CalculateSpeed(ShipData ship)
    {
        var engine = GetEquipped(ship, "Engine_0");

        float engineSpeed;

        if (engine == null)
        {
            // Двигатель не установлен в слот — используем базовую скорость из ShipData.
            // Это происходит когда EquipmentConfig не назначен или StarterKit не отработал.
            engineSpeed = ship.EngineSpeed > 0 ? ship.EngineSpeed : 0f;
            if (engineSpeed <= 0f)
            {
                Debug.LogWarning($"[EquipmentSystem] Ship '{ship.Name}': no engine in slot and EngineSpeed=0. Speed=0.");
                return 0f;
            }
        }
        else if (!engine.IsWorking)
        {
            // Двигатель установлен но сломан — корабль стоит.
            return 0f;
        }
        else
        {
            // Нормальный путь: берём Speed из предмета, fallback — EngineSpeed из ShipData.
            float fallbackSpeed = ship.EngineSpeed > 0 ? ship.EngineSpeed : 400f;
            engineSpeed = engine.GetParam("Speed", fallbackSpeed);
        }

        // Форсаж удваивает скорость двигателя
        if (ship.ForsageActive)
        {
            var forsage = GetEquipped(ship, "Forsage_0");
            if (forsage != null && forsage.IsWorking)
                engineSpeed *= 2f;
        }

        // Формула скорости: учитываем загрузку относительно вместимости корпуса
        int totalWeight = GetEquippedWeight(ship) + ship.Inventory.TotalWeight();
        int hullCapacity = GetHullCapacity(ship);

        // Перевес — корабль не может двигаться
        if (hullCapacity > 0 && totalWeight > hullCapacity)
            return 0f;

        // Штраф за вес: от 1.0 (пустой) до 0.33 (у предела вместимости)
        // При hullCapacity == 0 (нет корпуса) используем старую формулу как fallback
        float pct;
        if (hullCapacity > 0)
            pct = Mathf.Lerp(1.0f, 0.33f, (float)totalWeight / hullCapacity);
        else
            pct = Mathf.Max(0.33f, 1.22333f - 0.00045f * totalWeight);

        float speed = engineSpeed * pct;

        // Артефакты SpeedMult
        speed *= CollectSpeedMult(ship);

        return Mathf.Max(0f, speed);
    }

    private static float CollectSpeedMult(ShipData ship)
    {
        float mult = 1f;
        foreach (var kv in ship.Equipment.GetOccupiedSlotsOfCategory("Artefacts"))
        {
            string uid = ship.Equipment.GetItemUid(kv);
            if (uid != null && ship.AllItems.TryGetValue(uid, out var art) && art.IsWorking)
                mult *= art.GetParam("SpeedMult", 1f);
        }
        return mult;
    }

    // ── WEAR — ИСПОЛЬЗОВАНИЕ ─────────────────────────────────────────────────
    //
    // Износ больше не начисляется пассивно за каждый ход.
    // Каждый тип оборудования изнашивается от конкретного действия:
    //
    //   Engine, FuelTank, Radar, Scaner — 1 ед/ход если корабль двигался (ApplyMovementWear)
    //   Shield                          — 1 ед за каждый принятый удар    (ApplyShieldHitWear)
    //   Weapons                         — 1 ед за каждый выстрел           (ApplyWeaponShotWear)
    //   Droid                           — 1 ед за WearThreshold HP вылечено (AccumulateDroidHeal)
    //   CargoGrabber                    — 1 ед за WearThreshold ед. груза   (AccumulateCargoGrab)
    //
    // Форсаж по-прежнему применяет дополнительный износ к двигателю при движении.

    /// <summary>
    /// Вызывается в конце хода если корабль двигался (Position изменилась).
    /// Изнашивает Engine, FuelTank, Radar, Scaner на WearOnMove единиц.
    /// При активном форсаже двигатель изнашивается дополнительно (EngineDurabilityBurnMult).
    /// </summary>
    public static void ApplyMovementWear(ShipData ship, EquipmentConfig equipConfig)
    {
        float forsageMult = 1f;
        if (ship.ForsageActive)
        {
            var forsage = GetEquipped(ship, "Forsage_0");
            if (forsage != null && forsage.IsWorking)
                forsageMult = forsage.GetParam("EngineDurabilityBurnMult", 2f);
        }

        foreach (var kv in ship.Equipment.Slots)
        {
            if (kv.Value == null) continue;
            if (!ship.AllItems.TryGetValue(kv.Value, out var item)) continue;
            if (item.NoWear || item.MaxDurability <= 0) continue;

            string category = SlotCategory(kv.Key);
            var typeCfg = equipConfig.GetTypeConfig(category);
            if (typeCfg == null || typeCfg.WearOnMove <= 0) continue;

            int wear = typeCfg.WearOnMove;

            // Форсаж — дополнительный износ двигателя
            if (category == "Engine" && ship.ForsageActive)
                wear = Mathf.CeilToInt(wear * forsageMult);

            item.Durability = Mathf.Max(0, item.Durability - wear);
        }
    }

    /// <summary>
    /// Вызывается при каждом принятом ударе по кораблю (до расчёта урона).
    /// Изнашивает Shield на WearOnHit единиц.
    /// </summary>
    public static void ApplyShieldHitWear(ShipData ship, EquipmentConfig equipConfig)
    {
        var shield = GetEquipped(ship, "Shield_0");
        if (shield == null || !shield.IsWorking) return;

        var typeCfg = equipConfig.GetTypeConfig("Shield");
        if (typeCfg == null || typeCfg.WearOnHit <= 0) return;

        shield.Durability = Mathf.Max(0, shield.Durability - typeCfg.WearOnHit);
    }

    /// <summary>
    /// Вызывается при каждом выстреле из конкретного оружия.
    /// slotKey — ключ слота оружия ("Weapons_0", "Weapons_1", …).
    /// Изнашивает оружие на WearOnShot единиц.
    /// </summary>
    public static void ApplyWeaponShotWear(ShipData ship, string slotKey, EquipmentConfig equipConfig)
    {
        string uid = ship.Equipment.GetItemUid(slotKey);
        if (uid == null || !ship.AllItems.TryGetValue(uid, out var weapon)) return;
        if (!weapon.IsWorking) return;

        var typeCfg = equipConfig.GetTypeConfig("Weapons");
        if (typeCfg == null || typeCfg.WearOnShot <= 0) return;

        weapon.Durability = Mathf.Max(0, weapon.Durability - typeCfg.WearOnShot);
    }

    /// <summary>
    /// Вызывается когда дроид вылечил healAmount HP корабля.
    /// Накапливает в HealAccumulator; при достижении WearThreshold — списывает 1 прочность.
    /// </summary>
    public static void AccumulateDroidHeal(ItemInstance droid, float healAmount)
    {
        if (droid == null || !droid.IsWorking) return;
        float threshold = droid.GetParam("WearThreshold", 30f);
        if (threshold <= 0f) return;

        droid.HealAccumulator += healAmount;
        int wear = Mathf.FloorToInt(droid.HealAccumulator / threshold);
        if (wear <= 0) return;

        droid.HealAccumulator -= wear * threshold;
        droid.Durability = Mathf.Max(0, droid.Durability - wear);
    }

    /// <summary>
    /// Вызывается когда захват поднял cargoWeight единиц груза.
    /// Накапливает в CargoAccumulator; при достижении WearThreshold — списывает 1 прочность.
    /// </summary>
    public static void AccumulateCargoGrab(ItemInstance grabber, float cargoWeight)
    {
        if (grabber == null || !grabber.IsWorking) return;
        float threshold = grabber.GetParam("WearThreshold", 5000f);
        if (threshold <= 0f) return;

        grabber.CargoAccumulator += cargoWeight;
        int wear = Mathf.FloorToInt(grabber.CargoAccumulator / threshold);
        if (wear <= 0) return;

        grabber.CargoAccumulator -= wear * threshold;
        grabber.Durability = Mathf.Max(0, grabber.Durability - wear);
    }

    /// <summary>
    /// Устаревший метод — оставлен для совместимости.
    /// Вся логика пассивного износа перенесена в ApplyMovementWear и другие методы выше.
    /// Метод намеренно пуст: вызовы из старого кода не сломают компиляцию,
    /// но и лишнего износа не начислят.
    /// </summary>
    [System.Obsolete("Используйте ApplyMovementWear / ApplyShieldHitWear / ApplyWeaponShotWear вместо этого метода.")]
    public static void ApplyPassiveWear(ShipData ship, EquipmentConfig equipConfig)
    {
        // intentionally empty — wear is now usage-based
    }

    // ── TURN EFFECTS ──────────────────────────────────────────────────────────

    /// <summary>
    /// Применяет пассивные эффекты оборудования на ход:
    ///   - Ремонтный дроид: восстанавливает HP и накапливает износ через AccumulateDroidHeal
    ///   - Артефакт HealPerTurn: восстанавливает HP
    ///   - Форсаж: сбрасывается в false (действует один ход)
    ///
    /// moved — корабль двигался в этом ходу (Position изменилась).
    /// При moved == true вызывается ApplyMovementWear для Engine/FuelTank/Radar/Scaner.
    ///
    /// Вызывается из ShipData.ShipNextDay после движения.
    /// </summary>
    public static void ApplyTurnEffects(ShipData ship, EquipmentConfig equipConfig, bool moved)
    {
        // Износ от движения
        if (moved && equipConfig != null)
            ApplyMovementWear(ship, equipConfig);

        // Ремонтные дроиды
        foreach (var slotKey in ship.Equipment.GetOccupiedSlotsOfCategory("Droid"))
        {
            string uid = ship.Equipment.GetItemUid(slotKey);
            if (uid == null || !ship.AllItems.TryGetValue(uid, out var droid)) continue;
            if (!droid.IsWorking) continue;

            float heal = droid.GetParam("HealPerTurn", 0f);
            if (heal > 0)
            {
                int before = ship.CurrentHull;
                ship.CurrentHull = Mathf.Min(ship.MaxHull, ship.CurrentHull + Mathf.RoundToInt(heal));
                float actualHeal = ship.CurrentHull - before;
                if (actualHeal > 0)
                    AccumulateDroidHeal(droid, actualHeal);
            }
        }

        // Артефакты с HealPerTurn
        foreach (var slotKey in ship.Equipment.GetOccupiedSlotsOfCategory("Artefacts"))
        {
            string uid = ship.Equipment.GetItemUid(slotKey);
            if (uid == null || !ship.AllItems.TryGetValue(uid, out var art)) continue;
            if (!art.IsWorking) continue;

            float heal = art.GetParam("HealPerTurn", 0f);
            if (heal > 0)
                ship.CurrentHull = Mathf.Min(ship.MaxHull, ship.CurrentHull + Mathf.RoundToInt(heal));
        }

        // Форсаж — сбрасываем после хода
        ship.ForsageActive = false;
    }

    // ── DAMAGE ────────────────────────────────────────────────────────────────

    /// <summary>
    /// Применяет урон к кораблю согласно формуле:
    ///
    ///   1. effectiveDmg = rawDamage * WeaponVulnerability[damageType]
    ///   2. щит (если работает): afterShield = effective * (1 - BlockPercent/100)
    ///   3. броня: afterArmor = max(0, afterShield - max(0, Armor - ArmorPierce))
    ///   4. CurrentHull -= afterArmor
    ///   5. шанс попадания по оборудованию: случайный слот с CanBeDamagedByWeapon
    /// </summary>
    public static void ApplyDamage(
        ShipData ship,
        int rawDamage,
        string damageType,
        int armorPierce,
        float equipHitChance,
        int equipDamage,
        EquipmentConfig equipConfig)
    {
        // 1. Уязвимость корпуса
        float vuln = GetHullVulnerability(ship, damageType);
        float effective = rawDamage * vuln;

        // 2. Щит
        float afterShield = effective;
        var shield = GetEquipped(ship, "Shield_0");
        if (shield != null && shield.IsWorking)
        {
            float block = shield.GetParam("BlockPercent", 0f) / 100f;
            afterShield = effective * (1f - block);
            // Износ щита: 1 ед за каждый принятый удар
            if (equipConfig != null)
                ApplyShieldHitWear(ship, equipConfig);
        }

        // 3. Броня
        int armor = Mathf.RoundToInt(GetHullParam(ship, "Armor"));
        float afterArmor = Mathf.Max(0f, afterShield - Mathf.Max(0f, armor - armorPierce));

        // 4. Урон по HP
        ship.CurrentHull = Mathf.Max(0, ship.CurrentHull - Mathf.RoundToInt(afterArmor));

        // 5. Попадание по оборудованию
        if (equipDamage > 0 && Random.value < equipHitChance)
        {
            var target = GetRandomDamageableItem(ship, equipConfig);
            if (target != null)
                target.Durability = Mathf.Max(0, target.Durability - equipDamage);
        }
    }

    // ── FUEL ──────────────────────────────────────────────────────────────────

    /// <summary>Текущее топливо (из первого рабочего FuelTank).</summary>
    public static int GetCurrentFuel(ShipData ship)
    {
        var tank = GetEquipped(ship, "FuelTank_0");
        return tank?.CurrentFuel ?? 0;
    }

    /// <summary>Максимальная ёмкость топливного бака.</summary>
    public static int GetFuelCapacity(ShipData ship)
    {
        var tank = GetEquipped(ship, "FuelTank_0");
        return tank != null ? Mathf.RoundToInt(tank.GetParam("Capacity")) : 0;
    }

    /// <summary>Тратит топливо на прыжок. Возвращает false если топлива недостаточно.</summary>
    public static bool ConsumeFuel(ShipData ship, int amount)
    {
        var tank = GetEquipped(ship, "FuelTank_0");
        if (tank == null || tank.CurrentFuel < amount) return false;
        tank.CurrentFuel -= amount;
        return true;
    }

    /// <summary>Дальность прыжка (из двигателя). 0 = прыжки недоступны.</summary>
    public static int GetJumpRange(ShipData ship)
    {
        var engine = GetEquipped(ship, "Engine_0");
        return engine != null && engine.IsWorking ? Mathf.RoundToInt(engine.GetParam("JumpRange")) : 0;
    }

    /// <summary>
    /// Дальность радара в мировых единицах.
    /// Конфиговый параметр "Range" хранится в условных единицах (как скорость),
    /// делим на 100 для перевода в мировые (аналогично ActualSpeed / 100f).
    /// Возвращает 0 если радар не установлен или сломан.
    /// </summary>
    public static float GetRadarRange(ShipData ship)
    {
        var radar = GetEquipped(ship, "Radar_0");
        if (radar == null)
        {
            Debug.Log("[EquipmentSystem.GetRadarRange] radar == null (слот Radar_0 пуст или нет в AllItems)");
            return 0f;
        }
        if (!radar.IsWorking)
        {
            Debug.Log($"[EquipmentSystem.GetRadarRange] радар не работает: Durability={radar.Durability}");
            return 0f;
        }
        float rangeCfg = radar.GetParam("Range", 0f);
        float result = rangeCfg / 100f;
        return result;
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    /// <summary>Возвращает ItemInstance из слота, или null.</summary>
    public static ItemInstance GetEquipped(ShipData ship, string slotKey)
    {
        string uid = ship.Equipment.GetItemUid(slotKey);
        if (uid == null) return null;
        ship.AllItems.TryGetValue(uid, out var item);
        return item;
    }

    /// <summary>Числовой параметр из корпуса (Hull_0). 0 если нет.</summary>
    public static float GetHullParam(ShipData ship, string paramKey)
    {
        var hull = GetEquipped(ship, "Hull_0");
        return hull?.GetParam(paramKey) ?? 0f;
    }

    /// <summary>Уязвимость корпуса к типу урона (из WeaponVulnerability установленного корпуса).</summary>
    public static float GetHullVulnerability(ShipData ship, string damageType)
    {
        var hull = GetEquipped(ship, "Hull_0");
        return hull?.GetVulnerability(damageType) ?? 1f;
    }

    /// <summary>Выбирает случайный рабочий предмет подходящий под CanBeDamagedByWeapon.</summary>
    private static ItemInstance GetRandomDamageableItem(ShipData ship, EquipmentConfig equipConfig)
    {
        var candidates = new List<ItemInstance>();

        foreach (var kv in ship.Equipment.Slots)
        {
            if (kv.Value == null) continue;
            if (!ship.AllItems.TryGetValue(kv.Value, out var item)) continue;
            if (!item.IsWorking) continue;

            string cat = SlotCategory(kv.Key);
            var typeCfg = equipConfig.GetTypeConfig(cat);
            if (typeCfg != null && typeCfg.CanBeDamagedByWeapon)
                candidates.Add(item);
        }

        if (candidates.Count == 0) return null;
        return candidates[Random.Range(0, candidates.Count)];
    }

    /// <summary>Извлекает имя категории из ключа слота ("Weapon_0" → "Weapon").</summary>
    public static string SlotCategory(string slotKey)
    {
        int idx = slotKey.LastIndexOf('_');
        return idx > 0 ? slotKey.Substring(0, idx) : slotKey;
    }
}

// ── EQUIP RESULT ──────────────────────────────────────────────────────────────

/// <summary>Результат операции Install / Uninstall.</summary>
public readonly struct EquipResult
{
    public readonly bool Success;
    public readonly string Message;

    private EquipResult(bool success, string message) { Success = success; Message = message; }

    public static EquipResult Ok(string msg) => new EquipResult(true, msg);
    public static EquipResult Fail(string msg) => new EquipResult(false, msg);

    public override string ToString() => $"[{(Success ? "OK" : "FAIL")}] {Message}";
}