using UnityEngine;

[CreateAssetMenu(fileName = "GameSettings", menuName = "Game/Settings Config")]
public class GameSettingsConfig : ScriptableObject
{
    [Header("Input Controls")]
    public string HorizontalAxis = "Horizontal";
    public string VerticalAxis = "Vertical";
    public string ZoomAxis = "Mouse ScrollWheel";
    public KeyCode ResetCameraKey = KeyCode.Home;
    public KeyCode PausePlayKey = KeyCode.Space;
    public int DragMouseButton = 1; // 0=Left, 1=Right, 2=Middle

    [Tooltip("Клавиша открытия/закрытия панели снаряжения.")]
    public KeyCode InventoryKey = KeyCode.I;

    [Header("Camera Movement")]
    public float MoveSpeed = 20f;
    public float DragSpeed = 1f;
    public float EdgeThickness = 10f;
    public bool EnableEdgeScrolling = true;

    [Header("Camera Zoom")]
    public float MinZoom = 5f;
    public float MaxZoom = 20f;
    public float ZoomSpeed = 10f;

    [Header("Map Limits")]
    public Vector2 MapLimit = new Vector2(1024f, 1024f);

    [Header("Camera Centering")]
    public bool EnableCentering = true;
    public KeyCode CenterCameraKey = KeyCode.C;

    [Header("Route")]
    [Tooltip("Удерживать для добавления путевых точек вместо замены маршрута.")]
    public KeyCode MultiWaypointKey = KeyCode.LeftShift;

    [Header("Game Logic")]
    public float TurnDuration = 2.0f;
    [Tooltip("Останавливать авторежим когда игрок выполнил все действия маршрута.")]
    public bool MovieInterruptOnActionDone = true;

    [Header("Player Spawn")]
    [Tooltip("ShipType для корабля игрока при генерации новой галактики.")]
    public string PlayerShipTypeId = "Ranger";
    [Tooltip("Фракция игрока.")]
    public string PlayerFactionId = "Race3_Main";
    [Tooltip("Начальная позиция игрока внутри стартовой звёздной системы.")]
    public Vector2 PlayerSpawnPosition = new Vector2(1.5f, 0f);

    [Header("Display Fallbacks")]
    [Tooltip("Fallback-цвет иконок на миникарте если цвет не определён. Формат R,G,B (0-255).")]
    public string DefaultMinimapColor = "255,255,255";
    [Tooltip("Fallback-цвет названий звёзд. Формат R,G,B (0-255).")]
    public string DefaultStarNameColor = "200,200,200";

    // ── Asteroids ─────────────────────────────────────────────────────────────

    [Header("Asteroids")]
    [Tooltip("Дефолтное максимальное число астероидов одновременно в системе с игроком. " +
             "Может быть переопределено в StarData.MaxAsteroids или PremadeConfig.")]
    public int DefaultMaxAsteroids = 2;

    [Tooltip("Путь к папке со спрайтами астероидов (Resources). " +
             "Тип астероида добавляется как подпапка: {AsteroidSpritesPath}/{TypeId}/")]
    public string AsteroidSpritesPath = "Graphics/Asteroids";

    [Tooltip("Путь к спрайту иконки астероида на миникарте. " +
             "По умолчанию — тот же спрайт что у планет и игрока.")]
    public string AsteroidMinimapIconPath = "Graphics/Planets/Mask/minimap";

    // ── Explosion ─────────────────────────────────────────────────────────────

    [Header("Explosion")]
    [Tooltip("Путь к папке со спрайтами анимации взрыва (Resources). " +
             "Загружается как папка с пронумерованными спрайтами (0001.png, 0002.png…).")]
    public string ExplosionSpritePath = "Graphics/Effects/Explosions/Asteroids";

    [Tooltip("FPS воспроизведения анимации взрыва.")]
    public float ExplosionFPS = 12f;

    [Tooltip("Масштаб визуала взрыва в мировых единицах.")]
    public float ExplosionScale = 1.5f;

    // ── Dropped Items ─────────────────────────────────────────────────────────

    [Header("Dropped Items")]
    [Tooltip("Время жизни предмета на сцене в секундах. По истечении — исчезает.")]
    public float DroppedItemLifetime = 30f;

    [Tooltip("Базовый путь к спрайтам минералов (Resources). " +
             "Структура: {MineralSpritesPath}/{ItemId}/Tier_{1-5}.png")]
    public string MineralSpritesPath = "Graphics/Minerals";

    [Tooltip("Число визуальных тиров для минеральных спрайтов (по умолчанию 5). " +
             "Граница тира = TotalWeight / (DropWeightMax / TierCount), округлённая.")]
    public int MineralSpriteTierCount = 4;

    // ── GalaxyConstants overrides ─────────────────────────────────────────────

    [Header("Galaxy Constants — Galaxy")]
    public string DefaultGalaxyKey = "MilkyWay";
    public float ConstellationRadius = 5.0f;

    [Header("Galaxy Constants — Fallbacks")]
    public string FallbackStarColor = "White";
    public string FallbackSatelliteSize = "Mid";
    public string FallbackEmblemPath = "Empty";
    public string FallbackPlanetTexture = "Graphics/Planets/Textures/Unic/Solar_Earth";
    public string FallbackSatelliteTexture = "Graphics/Planets/Textures/Common/Moon";

    [Header("Galaxy Constants — Paths")]
    public string SatelliteTexturesPath = "Graphics/Planets/Textures/Satellites";
    public string CommonPlanetTexturesPath = "Graphics/Planets/Textures/Common";
    public string OrbitalObjectsPath = "Graphics/Planets/Orbital";
    public string PlanetMaskPath = "Graphics/Planets/Mask/160";
    public string CloudTexturesPath = "Graphics/Planets/Textures/Clouds";
    public int CloudTexturesCount = 3;

    [Header("Galaxy Constants — Orbits")]
    public float MinOrbitRadius = 500f;
    public float SystemPadding = 400f;
    public float OrbitGapMin = 500f;
    public float OrbitGapMax = 700f;
    public float FirstOrbitRadiusMin = 600f;
    public float FirstOrbitRadiusMax = 1000f;

    [Header("Galaxy Constants — Planet Generation")]
    public float PlanetOrbitSpeedMin = 50f;
    public float PlanetOrbitSpeedMax = 300f;
    public int PlanetDaySpeedMin = 20;
    public int PlanetDaySpeedMax = 60;
    public float CloudSpeedFactorMin = 0.6f;
    public float CloudSpeedFactorMax = 0.8f;
    public float OrbitalObjectChance = 0.3f;
    public float NoneOrbitMaxFraction = 0.4f;
    public int FallbackMaxPlanetsPerStar = 12;
    public float FallbackPlanetPixelRadius = 120f;

    [Header("Galaxy Constants — Satellites")]
    public float SatelliteOrbitBaseOffset = 35f;
    public float SatelliteOrbitSpacing = 25f;
    public float SatelliteOrbitSpeedMin = 40f;
    public float SatelliteOrbitSpeedMax = 120f;
    public int SatelliteDaySpeedMin = 10;
    public int SatelliteDaySpeedMax = 39;
    public float SatelliteCloudSpeedFactor = 0.7f;

    [Header("Galaxy Constants — Background")]
    public int BgStarCountFar = 250;
    public int BgStarCountMid = 150;
    public int BgStarCountNear = 80;
    public int BgTexSizeFar = 1024;
    public int BgTexSizeNear = 512;
    public float BgParallaxFar = 0.02f;
    public float BgParallaxMid = 0.05f;
    public float BgParallaxNear = 0.12f;
    public float BgLayerTileSize = 500f;
    public int BgVoidTextureWidth = 1920;
    public int BgVoidTextureHeight = 1080;
    public float BgVoidScaleFactor = 2.5f;

    [Header("Galaxy Constants — Log")]
    public string LogFallbackStarColor = "silver";
    public string LogNeutralOwnerLabel = "Neutral";
}