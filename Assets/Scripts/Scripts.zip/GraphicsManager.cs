using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

[System.Serializable]
public class SpriteSheetMeta
{
    public int FrameCount;
    public int Cols;
    public int Rows;
}

public class GraphicsManager : MonoBehaviour
{
    public static GraphicsManager Instance;

    [Header("Animation Settings")]
    public float GlobalStarFPS = 10f;

    private readonly Dictionary<string, Sprite[]> _spriteSheetCache = new Dictionary<string, Sprite[]>();
    private readonly Dictionary<string, Sprite> _singleSpriteCache = new Dictionary<string, Sprite>();
    private GalaxyGenerationContext _ctx;

    private void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    public void Init(GalaxyGenerationContext context)
    {
        _ctx = context;
        Debug.Log("[GraphicsManager] Initialized.");
    }

    public GalaxyConfig GetConfig() => _ctx?.Config;

    #region Star Visuals

    public float GetStarScale(string typeName)
    {
        if (_ctx?.Config?.Stars?.Types != null &&
            _ctx.Config.Stars.Types.TryGetValue(typeName, out var typeData))
            return typeData.GraphicSizeMult;

        Debug.LogWarning($"[GraphicsManager] Star type '{typeName}' not found, defaulting scale to 1.0");
        return 1f;
    }

    public (Sprite[] frames, float animSpeed) GetStarVisuals(string color, int graphVariant)
    {
        float speed = 1f / Mathf.Max(GlobalStarFPS, 0.0001f);
        var colors = _ctx?.Config?.Stars?.Colors;
        if (colors == null || !colors.TryGetValue(color, out var colorData)) return (null, 1f);

        string path = $"{colorData.Path}/Var{graphVariant}";
        return (LoadSpriteSheet(path), speed);
    }

    #endregion

    #region Planet / General Visuals

    public Sprite GetSprite(string path)
    {
        if (string.IsNullOrEmpty(path)) return null;

        string normalized = NormalizePath(path);

        if (_singleSpriteCache.TryGetValue(normalized, out Sprite cached)) return cached;

        var loaded = Resources.Load<Sprite>(normalized);
        if (loaded != null)
            _singleSpriteCache[normalized] = loaded;
        else
            Debug.LogError($"[GraphicsManager] Resource not found: {normalized}");

        return loaded;
    }

    public Sprite GetPlanetMask(string path) => GetSprite(path);
    public Sprite GetAtmosphereTexture(string path) => GetSprite(path);
    public Sprite GetOrbitalObjectTexture(string path) => GetSprite(path);

    /// <summary>
    /// Загружает спрайтлист астероида. path — путь до файла без расширения
    /// (например "Graphics/Asteroids/Rocky/001").
    /// Рядом должен лежать "001.png.json" с мета-данными (FrameCount, Cols, Rows).
    /// animFps — FPS анимации.
    /// </summary>
    public (Sprite[] frames, float secPerFrame) GetAsteroidVisuals(string path, float animFps = 12f)
    {
        float sec = animFps > 0f ? 1f / animFps : 1f / 12f;
        var frames = LoadSpriteSheet(path);
        if (frames == null || frames.Length == 0)
            Debug.LogWarning($"[GraphicsManager] Asteroid spritesheet not found: '{path}'");
        return (frames, sec);
    }

    #endregion

    public void ClearCache()
    {
        _spriteSheetCache.Clear();
        _singleSpriteCache.Clear();
        Resources.UnloadUnusedAssets();
    }

    private Sprite[] LoadSpriteSheet(string path)
    {
        if (string.IsNullOrEmpty(path)) return null;
        if (_spriteSheetCache.TryGetValue(path, out var cached)) return cached;

        // Попытка загрузить через мета-файл (spritesheet)
        var metaAsset = Resources.Load<TextAsset>(path + ".png");
        var sheetTexture = Resources.Load<Texture2D>(path);

        if (metaAsset != null && sheetTexture != null)
        {
            var frames = TryBuildFromSpriteSheet(metaAsset, sheetTexture, path);
            if (frames != null) return frames;
        }

        // Fallback: загрузить как набор спрайтов
        var sprites = Resources.LoadAll<Sprite>(path);
        if (sprites?.Length > 0)
        {
            var sorted = sprites.OrderBy(s => s.name).ToArray();
            _spriteSheetCache[path] = sorted;
            return sorted;
        }

        return null;
    }

    private Sprite[] TryBuildFromSpriteSheet(TextAsset metaAsset, Texture2D sheet, string path)
    {
        try
        {
            var meta = JsonConvert.DeserializeObject<SpriteSheetMeta>(metaAsset.text);
            float w = (float)sheet.width / meta.Cols;
            float h = (float)sheet.height / meta.Rows;
            var frames = new Sprite[meta.FrameCount];

            for (int i = 0; i < meta.FrameCount; i++)
            {
                int col = i % meta.Cols;
                int row = (meta.Rows - 1) - i / meta.Cols;
                frames[i] = Sprite.Create(sheet, new Rect(col * w, row * h, w, h), new Vector2(0.5f, 0.5f), 100f);
            }

            _spriteSheetCache[path] = frames;
            return frames;
        }
        catch
        {
            Debug.LogWarning($"[GraphicsManager] Failed to parse spritesheet meta for: {path}");
            return null;
        }
    }

    private static string NormalizePath(string path)
    {
        string normalized = path.Replace('\\', '/');
        if (normalized.EndsWith(".png", System.StringComparison.OrdinalIgnoreCase))
            normalized = normalized.Substring(0, normalized.Length - 4);
        return normalized;
    }
}