using UnityEngine;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

// Главный менеджер игровой логики. Singleton, DontDestroyOnLoad.
//
// Фазы хода:
//   Planning   — игрок планирует маршрут/приказы. Расчёта нет. Ждём StartTurn().
//   Animating  — movie-режим: тики 1..10, аниматоры интерполируют по TurnAnimationData.
//
// Авторежим:
//   IsAutoMode == true  → после анимации сразу запускается следующий ход.
//   IsAutoMode == false → возвращаемся в Planning и ждём игрока.
//
//   Авторежим прерывается через PauseRequests — любой код вызывает RequestPause(reason).
//   Space в Planning — снимает ВСЕ паузы и запускает ход.
//   Space в Animating — добавляет PlayerInput-паузу (сработает после анимации).

public class GalaxyManager : MonoBehaviour
{
    public static GalaxyManager Instance { get; private set; }

    // Вызывается после расчёта нового хода (данные уже обновлены).
    public static event Action<TurnAnimationData> OnTurnCalculate;
    // Вызывается каждый кадр в movie-режиме. progress: 0..1, currentTick: 1..10.
    public static event Action<float, int> OnTurnAnimate;
    // Вызывается когда анимация хода завершена (тик 10 отыгран).
    public static event Action<TurnAnimationData> OnTurnComplete;

    [Header("Configuration JSONs")]
    [SerializeField] private TextAsset galaxyConfigJson;
    [SerializeField] private TextAsset textConfigJson;
    [SerializeField] private TextAsset premadeConfigJson;
    [SerializeField] private TextAsset equipmentConfigJson;
    [SerializeField] private TextAsset itemsConfigJson;

    [Header("Settings")]
    public int GalaxySeed = 0;
    [Tooltip("UID стартовой звезды. Пусто — первая звезда.")]
    [SerializeField] private string startingStarUid;
    [SerializeField] private GameSettingsConfig settings;

    // ── PUBLIC STATE ──────────────────────────────────────────────────────────

    public GalaxyData GeneratedGalaxy { get; private set; }
    /// <summary>Публичный доступ к контексту генерации (конфиги, расы, типы кораблей).</summary>
    public GalaxyGenerationContext Context => _context;
    /// <summary>Публичный доступ к GameSettings для OwnershipDisplayResolver и других систем.</summary>
    public GameSettingsConfig Settings => settings;
    public StarData CurrentStar { get; private set; }
    public TurnPhase Phase { get; private set; } = TurnPhase.Planning;
    public bool IsAutoMode => _pauseRequests.Count == 0;

    // Данные последнего рассчитанного хода. Живут до следующего ExecuteTurnCalculation().
    public TurnAnimationData LastTurnData { get; private set; }

    // ── PRIVATE STATE ─────────────────────────────────────────────────────────

    private GalaxyGenerationContext _context;
    private float _movieTimer;
    private int _currentTick;                           // 1..10 во время анимации

    // Активные причины паузы. IsAutoMode == (_pauseRequests.Count == 0).
    private readonly HashSet<PauseReason> _pauseRequests = new();

    // Fix #19: MovieInterrupt теперь только для чтения снаружи.
    // PlayerShip вызывает SignalRouteComplete() вместо прямой записи в поле.
    // Это предотвращает случайный сброс флага сторонним кодом.
    private bool _movieInterrupt;

    private float MovieDuration => settings != null ? settings.TurnDuration : 2.0f;

    // ── UNITY LIFECYCLE ───────────────────────────────────────────────────────

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        EnsureContextInitialized();
        if (GeneratedGalaxy == null)
            GenerateNewGalaxy(GalaxySeed != 0 ? GalaxySeed : (int)DateTime.Now.Ticks);
    }

    private void Update()
    {
        HandleSpaceBarInput();
        if (Phase == TurnPhase.Animating) TickMovieMode();
    }

    // ── INPUT ─────────────────────────────────────────────────────────────────

    private void HandleSpaceBarInput()
    {
        if (!Input.GetKeyDown(KeyCode.Space)) return;

        if (Phase == TurnPhase.Animating)
        {
            // Во время анимации — запрашиваем паузу; она сработает после тика 10.
            RequestPause(PauseReason.PlayerInput);
        }
        else if (Phase == TurnPhase.Planning)
        {
            // В паузе — снимаем все причины и запускаем ход.
            ClearAllPauses();
            StartTurn();
        }
    }

    // ── PAUSE API ─────────────────────────────────────────────────────────────

    // Добавляет причину паузы. Авторежим остановится после текущей анимации.
    public void RequestPause(PauseReason reason)
    {
        _pauseRequests.Add(reason);
        UnityEngine.Debug.Log($"[GalaxyManager] Pause requested: {reason}. Total: {_pauseRequests.Count}");
    }

    // Снимает конкретную причину паузы.
    public void ClearPause(PauseReason reason) => _pauseRequests.Remove(reason);

    // Снимает все причины — используется при нажатии Space в Planning.
    public void ClearAllPauses() => _pauseRequests.Clear();

    // Fix #19: PlayerShip вызывает этот метод вместо прямой записи MovieInterrupt = true.
    // Метод идемпотентен — повторный вызов безопасен.
    public void SignalRouteComplete() => _movieInterrupt = true;

    // ── TURN FLOW ─────────────────────────────────────────────────────────────

    // Запускает ход. Игнорируется если анимация уже идёт.
    public void StartTurn()
    {
        if (Phase == TurnPhase.Animating) return;
        ExecuteTurnCalculation();
    }

    private void ExecuteTurnCalculation()
    {
        if (GeneratedGalaxy == null) return;

        // Расчёт хода — мгновенно, возвращает данные для аниматоров.
        var sw = Stopwatch.StartNew();
        LastTurnData = GeneratedGalaxy.GalaxyNextDay(_context);
        sw.Stop();
        UnityEngine.Debug.Log($"[GalaxyManager] Turn {GeneratedGalaxy.CurrentTurn} calc: {sw.ElapsedMilliseconds} ms");

        // Проверяем условия автопаузы (LowHull и др.) — логика UI живёт здесь, не в GalaxyData.
        CheckPlayerPauseConditions(LastTurnData);

        // Применяем PauseReasons из симуляции (события добавленные выше и самой симуляцией).
        foreach (var reason in LastTurnData.PauseReasons)
            RequestPause(reason);

        OnTurnCalculate?.Invoke(LastTurnData);

        // Запускаем анимацию.
        Phase = TurnPhase.Animating;
        _movieTimer = 0f;
        _currentTick = 0;
    }

    private void TickMovieMode()
    {
        _movieTimer += Time.deltaTime;
        float progress = Mathf.Clamp01(_movieTimer / MovieDuration);

        // Вычисляем текущий тик: 1..10 по мере роста progress.
        int newTick = Mathf.Clamp(Mathf.CeilToInt(progress * GalaxyData.TurnRounds), 1, GalaxyData.TurnRounds);
        _currentTick = newTick;

        SystemViewManager.Instance?.AnimateSystem(progress, _currentTick, LastTurnData);
        OnTurnAnimate?.Invoke(progress, _currentTick);

        if (_movieTimer >= MovieDuration) CompleteCurrentTurn();
    }

    private void CompleteCurrentTurn()
    {
        // Финализируем визуал — планеты и корабли снэпаются в конечные позиции.
        SystemViewManager.Instance?.UpdatePlanetPositions();

        // Смерти показываются в тике 10 — сигнал подписчикам.
        OnTurnComplete?.Invoke(LastTurnData);

        // Fix #19: используем приватный _movieInterrupt вместо публичного свойства.
        // PlayerShip сигнализирует через SignalRouteComplete().
        if (_movieInterrupt)
        {
            _movieInterrupt = false;
            RequestPause(PauseReason.RouteCompleted);
        }

        Phase = TurnPhase.Planning;
        _movieTimer = 0f;
        _currentTick = 0;

        if (IsAutoMode)
        {
            // Ни одной паузы — сразу следующий ход.
            ExecuteTurnCalculation();
        }
        else
        {
            UnityEngine.Debug.Log($"[GalaxyManager] Paused after turn {GeneratedGalaxy.CurrentTurn}. " +
                      $"Reasons: {string.Join(", ", _pauseRequests)}");
        }
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    public void GenerateNewGalaxy(int seed)
    {
        EnsureContextInitialized();
        if (_context == null) return;

        GalaxySeed = seed;
        GeneratedGalaxy = null;

        var generator = new GalaxyGenerator(_context);
        GeneratedGalaxy = generator.Generate(seed);
        GeneratedGalaxy.InitSimulation();

        GalaxyLogger.LogGalaxy(GeneratedGalaxy, GalaxySeed, _context.Config, _context.AvailableRaces);

        var star = ResolveStartingStar();
        SpawnPlayer(star);
        SetCurrentStar(star);
    }

    public void SetCurrentStar(StarData star)
    {
        if (star == null) return;

        // Очищаем астероиды предыдущей звезды — они не должны тикаться и отображаться
        // когда игрока там нет. При возврате в систему астероиды начнут спавниться заново.
        if (CurrentStar != null && CurrentStar != star && CurrentStar.Asteroids.Count > 0)
        {
            UnityEngine.Debug.Log($"[GalaxyManager] Clearing {CurrentStar.Asteroids.Count} asteroids from '{CurrentStar.Name}' on star switch");
            CurrentStar.Asteroids.Clear();
        }

        CurrentStar = star;
        SystemViewManager.Instance?.RenderSystem(star);
        UnityEngine.Debug.Log($"[GalaxyManager] Current star: {star.Name}");
    }

    public void SaveGame() => GalaxySaveManager.SaveGalaxy(GeneratedGalaxy);

    public void LoadGame()
    {
        var data = GalaxySaveManager.LoadGalaxy();
        if (data == null) return;
        GeneratedGalaxy = data;
        GeneratedGalaxy.InitSimulation();
        var playerStar = FindPlayerStar();
        SetCurrentStar(playerStar ?? ResolveStartingStar());
        UnityEngine.Debug.Log("[GalaxyManager] Game loaded.");
    }

    // Оставлено для обратной совместимости с GameConsoleController.
    public void StopAutoMode() => RequestPause(PauseReason.PlayerInput);

    // ── PLAYER SPAWN ──────────────────────────────────────────────────────────

    private void SpawnPlayer(StarData star)
    {
        if (star == null) return;
        foreach (var ship in star.Ships)
            if (ship.IsPlayer) return;

        string shipTypeId = settings != null ? settings.PlayerShipTypeId : "Ranger";
        string playerFaction = settings != null ? settings.PlayerFactionId : "Coalition";
        var spawnPos = settings != null ? settings.PlayerSpawnPosition : new Vector2(1.5f, 0f);

        var playerShip = ShipFactory.BuildShipData(shipTypeId, playerFaction, _context.AvailableShipTypes);
        if (playerShip == null)
        {
            UnityEngine.Debug.LogError($"[GalaxyManager] Не удалось создать ShipData для '{shipTypeId}'.");
            return;
        }

        playerShip.Name = "Player";
        playerShip.IsPlayer = true;

        // Экипируем стартовый набор из StarterKit конфига типа корабля.
        // Если StarterKit == null — корабль стартует без оборудования (MaxHull = BaseHull).
        if (_context.AvailableShipTypes.TryGetValue(shipTypeId, out var shipTypeCfg)
            && shipTypeCfg.StarterKit != null)
        {
            ItemFactory.EquipStarterKit(
                playerShip,
                shipTypeCfg.StarterKit,
                _context.Equipment,
                _context.Config);
        }

        playerShip.InitOnSpawn(star, spawnPos);
        star.Ships.Add(playerShip);
        UnityEngine.Debug.Log($"[GalaxyManager] Игрок создан в '{star.Name}' на {spawnPos}.");
    }

    // ── PAUSE CONDITIONS ──────────────────────────────────────────────────────

    // Проверяет условия автопаузы для корабля игрока после расчёта хода.
    // Живёт здесь, а не в GalaxyData — это UI-логика, не симуляция.
    private void CheckPlayerPauseConditions(TurnAnimationData anim)
    {
        foreach (var star in GeneratedGalaxy.StarsMap.Values)
        {
            foreach (var ship in star.Ships)
            {
                if (!ship.IsPlayer) continue;

                if (ship.MaxHull <= 0)
                {
                    UnityEngine.Debug.LogWarning($"[GalaxyManager] Player ship '{ship.Uid}' has MaxHull=0 — hull check skipped.");
                }
                else
                {
                    float hullPct = (float)ship.CurrentHull / ship.MaxHull;
                    if (hullPct < 0.25f)
                        anim.PauseReasons.Add(PauseReason.LowHull);
                }

                return; // игрок один — ранний выход
            }
        }
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private StarData ResolveStartingStar()
    {
        if (!string.IsNullOrEmpty(startingStarUid)
            && GeneratedGalaxy.StarsMap.TryGetValue(startingStarUid, out var star))
            return star;
        return GeneratedGalaxy.StarsMap.Values.FirstOrDefault();
    }

    private StarData FindPlayerStar()
    {
        foreach (var star in GeneratedGalaxy.StarsMap.Values)
            foreach (var ship in star.Ships)
                if (ship.IsPlayer) return star;
        return null;
    }

    private void EnsureContextInitialized()
    {
        if (_context != null) return;

        if (!GalaxyConfigLoader.TryLoadConfigs(
            galaxyConfigJson, textConfigJson, premadeConfigJson, equipmentConfigJson,
            out var cfg, out var txt, out var pre, out var equipment))
        {
            UnityEngine.Debug.LogError("[GalaxyManager] Config initialization failed.");
            return;
        }

        // ItemsConfig — опциональный; предупреждение если не назначен
        ItemsConfig itemsCfg = null;
        if (itemsConfigJson != null)
        {
            try { itemsCfg = Newtonsoft.Json.JsonConvert.DeserializeObject<ItemsConfig>(itemsConfigJson.text); }
            catch (System.Exception e)
            {
                UnityEngine.Debug.LogError($"[GalaxyManager] Failed to parse ItemsConfig: {e.Message}");
            }
        }
        else
        {
            UnityEngine.Debug.LogWarning("[GalaxyManager] ItemsConfig not assigned — minerals will not drop from asteroids.");
        }

        _context = new GalaxyGenerationContext(cfg, txt, pre, equipment, itemsCfg);
        GalaxyConstants.Initialize(settings);
        GalaxyConstants.InitializeFromGalaxyConfig(cfg); // применяем GalaxyConfig.Explosion поверх defaults
        GraphicsManager.Instance?.Init(_context);
        FactionRelationsManager.Instance?.Initialize(cfg.Ships);
    }
}

// ── TURN PHASE ────────────────────────────────────────────────────────────────

public enum TurnPhase
{
    Planning,    // игрок планирует — расчёта нет, ждём StartTurn()
    Animating,   // movie-режим — тики 1..10 идут
}