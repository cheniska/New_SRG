using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using System;

// ── ВСПОМОГАТЕЛЬНЫЕ ТИПЫ ──────────────────────────────────────────────────────

// Fixed — имена по ключу (для PremadeConfig), Pool — случайная раздача.
public class RaceNamePool
{
    public Dictionary<string, string> Fixed { get; } = new();
    public List<string> Pool { get; } = new();
}

public class SystemSizeDef { public int MaxPlanets; }

// ── GALAXY GENERATION CONTEXT ─────────────────────────────────────────────────

public class GalaxyGenerationContext
{
    // Конфиги (только чтение)
    public GalaxyConfig Config { get; }
    public TextConfig TextConfig { get; }
    public PremadeConfig PremadeConfig { get; }
    public EquipmentConfig Equipment { get; }
    /// <summary>Конфиг не-оборудовательных предметов (минералы и др.). Может быть null.</summary>
    public ItemsConfig ItemsConfig { get; set; }

    public GalaxyConfigData ActiveGalaxyConfig { get; set; }

    // Доступные ключи из конфига
    public List<string> AvailablePlanetSizes { get; private set; }
    public List<string> AvailablePlanetTypes { get; private set; }
    public List<string> AvailableStarTypes { get; private set; }
    public List<string> AvailableSatelliteSizes { get; private set; }

    public Dictionary<string, RaceInfo> AvailableRaces { get; } = new();
    public Dictionary<string, ShipTypeConfig> AvailableShipTypes { get; private set; } = new();
    public List<string> AvailableShipTypeKeys { get; private set; } = new();
    public Dictionary<string, List<string>> FactionLineups { get; private set; } = new();
    public Dictionary<string, EquipmentSlotConfig> EquipmentSlots { get; private set; } = new();

    public Dictionary<string, SystemSizeDef> SystemSizeRules { get; private set; } = new();
    public Dictionary<string, PlanetSizeData> PlanetSizeRules { get; private set; } = new();

    // Пулы имён
    public Dictionary<string, RaceNamePool> StarNamesByRace { get; } = new();
    public Dictionary<string, RaceNamePool> PlanetNamesByRace { get; } = new();
    public RaceNamePool CommonStarNames { get; private set; } = new();
    public RaceNamePool CommonPlanetNames { get; private set; } = new();
    public List<string> ConstNamePool { get; } = new();

    public HashSet<string> UsedStarNames { get; } = new();
    public HashSet<string> UsedPlanetNames { get; } = new();

    public int UnnamedConstCounter = 0;
    public int UnnamedStarCounter = 0;
    public int UnnamedPlanetCounter = 0;

    public GalaxyGenerationContext(GalaxyConfig cfg, TextConfig txt, PremadeConfig pre,
        EquipmentConfig equipment = null, ItemsConfig itemsConfig = null)
    {
        Config = cfg;
        TextConfig = txt;
        PremadeConfig = pre;
        Equipment = equipment;
        ItemsConfig = itemsConfig;
        RebuildPools();
    }

    public void Reset()
    {
        UnnamedConstCounter = UnnamedStarCounter = UnnamedPlanetCounter = 0;
        UsedStarNames.Clear();
        UsedPlanetNames.Clear();
        RebuildPools();
    }

    private void RebuildPools()
    {
        RebuildSizeLists();
        RebuildSystemSizeRules();
        RebuildRaces();
        RebuildNamePools();
        RebuildShips();
    }

    private void RebuildSizeLists()
    {
        // Планеты — размеры и правила в одном проходе (устранено дублирование цикла)
        PlanetSizeRules.Clear();
        if (Config.Planets?.Sizes == null)
            throw new InvalidOperationException("[GalaxyGenerationContext] Config missing Planets.Sizes.");

        AvailablePlanetSizes = new List<string>(Config.Planets.Sizes.Count);
        foreach (var kvp in Config.Planets.Sizes)
        {
            AvailablePlanetSizes.Add(kvp.Key);
            PlanetSizeRules[kvp.Key] = kvp.Value;
        }

        if (Config.Planets?.Types == null)
            throw new InvalidOperationException("[GalaxyGenerationContext] Config missing Planets.Types.");

        AvailablePlanetTypes = Config.Planets.Types;

        if (Config.Stars?.Types == null)
            throw new InvalidOperationException("[GalaxyGenerationContext] Config missing Stars.Types.");

        AvailableStarTypes = Config.Stars.Types.Keys.ToList();

        if (Config.Satellites?.Sizes == null)
            throw new InvalidOperationException("[GalaxyGenerationContext] Config missing Satellites.Sizes.");

        AvailableSatelliteSizes = Config.Satellites.Sizes.Keys.ToList();
    }

    private void RebuildSystemSizeRules()
    {
        SystemSizeRules.Clear();
        if (Config.Stars?.Types != null)
            foreach (var kvp in Config.Stars.Types)
                SystemSizeRules[kvp.Key] = new SystemSizeDef { MaxPlanets = kvp.Value.MaxPlanets };

        if (SystemSizeRules.Count == 0)
            throw new InvalidOperationException("[GalaxyGenerationContext] Stars.Types is empty — cannot build SystemSizeRules. Check GalaxyConfig.");
    }

    // None не попадает в AvailableRaces — специальный статус, не раса для генерации.
    private void RebuildRaces()
    {
        AvailableRaces.Clear();
        if (Config.Races == null) return;

        foreach (var kvp in Config.Races)
        {
            if (kvp.Key == GalaxyConstants.RACE_NONE_KEY) continue;
            string name = TextConfig?.RaceNames?.TryGetValue(kvp.Key, out string n) == true ? n : kvp.Key;
            string color = kvp.Value.Color ?? GalaxyConstants.DEFAULT_COLOR;
            AvailableRaces[kvp.Key] = new RaceInfo(name, color, kvp.Value.EmblemPath ?? GalaxyConstants.FALLBACK_EMBLEM_PATH);
        }
    }

    private void RebuildNamePools()
    {
        StarNamesByRace.Clear(); PlanetNamesByRace.Clear(); ConstNamePool.Clear();
        CommonStarNames = new RaceNamePool();
        CommonPlanetNames = new RaceNamePool();

        if (TextConfig.ConstNames != null) ConstNamePool.AddRange(TextConfig.ConstNames.Values);
        ParseNameSection(TextConfig.StarsNames, StarNamesByRace, CommonStarNames);
        ParseNameSection(TextConfig.PlanetsNames, PlanetNamesByRace, CommonPlanetNames);
    }

    private static void ParseNameSection(Dictionary<string, RaceNamesData> source,
        Dictionary<string, RaceNamePool> target, RaceNamePool commonPool)
    {
        if (source == null) return;
        foreach (var (race, data) in source)
        {
            var pool = new RaceNamePool();
            if (data.Fixed != null) foreach (var kv in data.Fixed) pool.Fixed[kv.Key] = kv.Value;
            if (data.Pool != null) pool.Pool.AddRange(data.Pool);

            if (race == GalaxyConstants.RACE_COMMON_KEY)
            {
                foreach (var kv in pool.Fixed) commonPool.Fixed[kv.Key] = kv.Value;
                commonPool.Pool.AddRange(pool.Pool);
            }
            else target[race] = pool;
        }
    }

    private void RebuildShips()
    {
        AvailableShipTypes.Clear(); AvailableShipTypeKeys.Clear(); FactionLineups.Clear(); EquipmentSlots.Clear();
        var ships = Config.Ships;
        if (ships == null) return;

        if (ships.ShipTypes != null) foreach (var kvp in ships.ShipTypes) { AvailableShipTypes[kvp.Key] = kvp.Value; AvailableShipTypeKeys.Add(kvp.Key); }
        if (ships.FactionLineups != null) foreach (var kvp in ships.FactionLineups) FactionLineups[kvp.Key] = kvp.Value;
        if (ships.Equipment != null) foreach (var kvp in ships.Equipment) EquipmentSlots[kvp.Key] = kvp.Value;
    }

    // ── ПУБЛИЧНЫЕ МЕТОДЫ ДЛЯ ScriptAPI ───────────────────────────────────────
    // Дублируют логику GalaxyGenerator, но работают через публичные пулы контекста.
    // Изменяют пулы имён (удаляют использованные) — как и генератор.

    /// <summary>Выбирает имя звезды из пула по расам планет системы.</summary>
    public string ResolveStarNameFromPlanets(StarData star)
    {
        string singleRace = null;
        bool multiple = false;
        foreach (var planet in star.Planets)
        {
            if (planet.Race == GalaxyConstants.RACE_NONE_KEY) continue;
            if (singleRace == null) singleRace = planet.Race;
            else if (planet.Race != singleRace) { multiple = true; break; }
        }
        string name = (!multiple && singleRace != null) ? PopStarName(singleRace) : null;
        return name ?? PopStarName(null);
    }

    private string PopStarName(string raceKey)
    {
        if (!string.IsNullOrEmpty(raceKey)
            && StarNamesByRace.TryGetValue(raceKey, out var racePool) && racePool.Pool.Count > 0)
        {
            string n = GenerationHelpers.PopRandomUnused(racePool.Pool, UsedStarNames);
            if (n != null) return n;
        }
        if (CommonStarNames.Pool.Count > 0)
        {
            string n = GenerationHelpers.PopRandomUnused(CommonStarNames.Pool, UsedStarNames);
            if (n != null) return n;
        }
        return $"UNNAMED_S_{++UnnamedStarCounter}";
    }

    /// <summary>Назначает имя планете из пула по расе.</summary>
    public void ResolvePlanetName(PlanetData planet)
    {
        if (planet.Name != GalaxyConstants.VAL_UNKNOWN && !planet.Name.StartsWith("UNNAMED")) return;

        string raceKey = planet.Race == GalaxyConstants.RACE_NONE_KEY
            ? GalaxyConstants.RACE_COMMON_KEY
            : planet.Race;

        string n = PopPlanetName(raceKey);
        planet.Name = n ?? $"UNNAMED_P_{++UnnamedPlanetCounter}";
    }

    private string PopPlanetName(string raceKey)
    {
        if (raceKey == GalaxyConstants.RACE_COMMON_KEY)
            return GenerationHelpers.PopRandomUnused(CommonPlanetNames.Pool, UsedPlanetNames);
        if (PlanetNamesByRace.TryGetValue(raceKey, out var pool) && pool.Pool.Count > 0)
            return GenerationHelpers.PopRandomUnused(pool.Pool, UsedPlanetNames);
        return null;
    }
}

// ── GALAXY GENERATOR ─────────────────────────────────────────────────────────

public class GalaxyGenerator
{
    private readonly GalaxyGenerationContext _ctx;
    private int _systemSizeMult = 1;
    private int _maxPlanetsPerStar = 12; // кэшируется один раз при генерации

    private const float NearZero = 0.001f;
    private const int MinPlanetsPerStarHardMin = 1;

    public GalaxyGenerator(GalaxyGenerationContext context) => _ctx = context;

    internal void FinalizeStar(StarData star) => FinalizeStarProps(star);
    internal void FinalizePlanet(PlanetData planet, string size) => FinalizePlanetVisuals(planet, size);
    internal void GeneratePlanetSatellites(PlanetData planet) => GenerateSatellites(planet, null);
    internal void AssignOrbitRadiiToList(List<PlanetData> list) => AssignOrbitRadii(list);
    internal string ToFactionId(string raceId) => RaceToFactionId(raceId, _ctx.FactionLineups);
    internal static string ToRaceId(string factionId) => FactionIdToRace(factionId);

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    public GalaxyData Generate(int seed, string galaxyKey = "MilkyWay")
    {
        UnityEngine.Random.InitState(seed);
        _ctx.Reset();

        var galaxyCfg = _ctx.Config.Galaxies?.GetValueOrDefault(galaxyKey)
            ?? throw new System.Exception($"Galaxy '{galaxyKey}' not found in config");

        _ctx.ActiveGalaxyConfig = galaxyCfg;
        _systemSizeMult = _ctx.Config.Settings?.SystemSizeMult ?? 1;
        _maxPlanetsPerStar = _ctx.SystemSizeRules.Count > 0
            ? _ctx.SystemSizeRules.Values.Max(r => r.MaxPlanets) : GalaxyConstants.FALLBACK_MAX_PLANETS;

        PreReserveFixedNames(galaxyKey);

        var galaxy = new GalaxyData
        {
            Width = galaxyCfg.GalaxySize[0],
            Height = galaxyCfg.GalaxySize[1],
            StartDateString = _ctx.Config.Settings?.InitialDate ?? "01.01.0001"
        };

        GenerateConstellations(galaxy, galaxyKey, galaxyCfg);
        GenerateStars(galaxy, galaxyCfg);
        ResolveAllOwners(galaxy);
        galaxy.InitializeLookups();
        return galaxy;
    }

    // ── ШАГ 1 — СОЗВЕЗДИЯ ────────────────────────────────────────────────────

    private void GenerateConstellations(GalaxyData galaxy, string galaxyKey, GalaxyConfigData cfg)
    {
        var premadeGalaxy = _ctx.PremadeConfig?.Galaxies?.GetValueOrDefault(galaxyKey);
        if (premadeGalaxy?.Constellations != null)
            foreach (var fc in premadeGalaxy.Constellations.Values)
                galaxy.Constellations.Add(CreateConstellation(galaxy, fc));

        int remaining = cfg.ConstCount - galaxy.Constellations.Count;
        for (int i = 0; i < remaining; i++)
            galaxy.Constellations.Add(CreateConstellation(galaxy, null));
    }

    private ConstellationData CreateConstellation(GalaxyData galaxy, FixedConstellationData fc)
    {
        var c = new ConstellationData(ResolveConstellationName(fc?.Name), GetRandomPos(galaxy.Width, galaxy.Height));

        if (fc != null)
        {
            c.Owner = fc.Owner ?? GalaxyConstants.RACE_UNRESOLVED_KEY;
            c.FixedStarsCount = fc.Stars?.Count ?? fc.StarsCount;
            if (fc.Stars != null)
                foreach (var fs in fc.Stars.Values)
                    TryAddStar(galaxy, c, CreateStar(galaxy, c, fs, c.Owner));
        }
        else c.Owner = GalaxyConstants.RACE_UNRESOLVED_KEY;

        return c;
    }

    // ── ШАГ 2 — ЗВЁЗДЫ ───────────────────────────────────────────────────────

    private void GenerateStars(GalaxyData galaxy, GalaxyConfigData cfg)
    {
        int budget = Mathf.Max(0, cfg.StarsCount - galaxy.StarsMap.Count);

        // Кэшируем вместимость каждого созвездия — GetConstellationCapacity вызывалась дважды
        var capacity = new Dictionary<ConstellationData, int>(galaxy.Constellations.Count);
        foreach (var c in galaxy.Constellations)
            capacity[c] = GetConstellationCapacity(c, cfg);

        foreach (var c in galaxy.Constellations)
        {
            int toAdd = Mathf.Min(Mathf.Max(0, cfg.MinStarsPerConstellation - c.Stars.Count), budget);
            for (int i = 0; i < toAdd; i++)
                if (TryAddStar(galaxy, c, CreateStar(galaxy, c))) budget--;
        }

        var available = galaxy.Constellations
            .Where(c => c.Stars.Count < capacity[c]).ToList();

        for (int attempts = 0; budget > 0 && available.Count > 0 && attempts < budget * 2 + 100; attempts++)
        {
            int idx = UnityEngine.Random.Range(0, available.Count);
            var c = available[idx];
            if (TryAddStar(galaxy, c, CreateStar(galaxy, c)))
            {
                budget--;
                attempts = -1; // сброс: после ++ станет 0
                if (c.Stars.Count >= capacity[c])
                {
                    // swap-remove: O(1) вместо O(n) List.Remove(value)
                    available[idx] = available[available.Count - 1];
                    available.RemoveAt(available.Count - 1);
                }
            }
        }
    }

    private StarData CreateStar(GalaxyData galaxy, ConstellationData parent,
        FixedStarData fs = null, string parentOwner = null)
    {
        var star = new StarData
        {
            ParentConstellation = parent,
            Position = GetRandomPos(galaxy.Width, galaxy.Height, parent.Center, GalaxyConstants.CONSTELLATION_RADIUS)
        };

        if (fs != null) ApplyFixedStarProps(star, fs, parentOwner);
        else ApplyRandomStarProps(star);

        FinalizeStarProps(star);
        return star;
    }

    private void ApplyFixedStarProps(StarData star, FixedStarData fs, string parentOwner)
    {
        string resolvedOwner = OwnerResolver.Resolve(fs.Owner ?? GalaxyConstants.RACE_NONE_KEY, parentOwner, _ctx.AvailableRaces);
        star.FactionId = RaceToFactionId(resolvedOwner, _ctx.FactionLineups);
        star.Type = fs.Type ?? GalaxyConstants.VAL_UNKNOWN;
        star.Color = fs.Color ?? GalaxyConstants.VAL_UNKNOWN;
        star.GraphVar = fs.GraphVar ?? 0;
        star.Name = ResolveStarFixedName(fs.Name, resolvedOwner);
        star.Planets = CreatePlanetsMixed(star, fs);
        // Максимальное число астероидов из PremadeConfig (если задано)
        if (fs.MaxAsteroids.HasValue)
            star.MaxAsteroids = fs.MaxAsteroids.Value;
    }

    private void ApplyRandomStarProps(StarData star)
    {
        star.FactionId = GalaxyConstants.RACE_UNRESOLVED_KEY;
        star.Type = GalaxyConstants.VAL_UNKNOWN;
        star.Color = GalaxyConstants.VAL_UNKNOWN;
        star.GraphVar = 0;
        star.Name = GalaxyConstants.VAL_UNKNOWN;
        star.Planets = CreatePlanetsRandom();
    }

    private void FinalizeStarProps(StarData star)
    {
        if (star.Type == GalaxyConstants.VAL_UNKNOWN)
            star.Type = _ctx.AvailableStarTypes[UnityEngine.Random.Range(0, _ctx.AvailableStarTypes.Count)];
        if (star.Color == GalaxyConstants.VAL_UNKNOWN) GenerationHelpers.ApplyWeightedStarColor(star, _ctx.Config);
        if (star.GraphVar == 0) star.GraphVar = GenerationHelpers.GetRandomColorVariant(star.Color, _ctx.Config);

        star.MapIcon = GenerationHelpers.BuildStarMapIcon(star.Color, star.GraphVar);
        star.BackgroundSeed = UnityEngine.Random.Range(int.MinValue, int.MaxValue);
        star.SystemSize = CalculateSystemSize(star.Planets);

        // Радиус звезды — базовый размер (0.5 ед) × GraphicSizeMult типа
        if (_ctx.Config?.Stars?.Types != null &&
            _ctx.Config.Stars.Types.TryGetValue(star.Type, out var typeData))
            star.StarRadius = 0.5f * typeData.GraphicSizeMult;
        else
            star.StarRadius = 0.5f;

        if (star.Name == GalaxyConstants.VAL_UNKNOWN)
            star.Name = ResolveStarNameFromPlanets(star);

        CustomPropertyResolver.ResolveAndApplyProperties(star, star.CustomProperties, "Stars", _ctx.Config);

        star.NameRenderData = OwnershipDisplayResolver.ResolveStarName(star, _ctx);
    }

    // ── ШАГ 3 — ПЛАНЕТЫ ──────────────────────────────────────────────────────

    private List<PlanetData> CreatePlanetsRandom()
    {
        int min = Mathf.Max(MinPlanetsPerStarHardMin, _ctx.ActiveGalaxyConfig.MinPlanetsPerStar);
        int total = Mathf.Min(UnityEngine.Random.Range(min, _ctx.ActiveGalaxyConfig.MaxPlanetsPerStar + 1), _maxPlanetsPerStar);

        var slots = new List<int>(total);
        for (int i = 1; i <= total; i++) slots.Add(i);
        int noneCount = CalculateNoneCount(total);

        var list = new List<PlanetData>(total);
        for (int i = 0; i < total; i++)
        {
            var planet = CreatePlanet(GalaxyConstants.RACE_UNRESOLVED_KEY, null, forceNone: i < noneCount);
            planet.OrbitIndex = PopRandom(slots);
            list.Add(planet);
        }

        AssignOrbitsAndNames(list, total, new HashSet<int>(), null);
        return list.OrderBy(p => p.OrbitIndex).ToList();
    }

    private List<PlanetData> CreatePlanetsMixed(StarData star, FixedStarData fs)
    {
        var (fixedPlanets, usedOrbits, fixedNoneCount) = CollectFixedPlanets(star, fs);

        int targetTotal = ResolveTargetPlanetCount(fs, fixedPlanets.Count);
        int noneNeeded = Mathf.Max(0, ParseNoneCount(fs.PlanetsNoneCount, targetTotal) - fixedNoneCount);
        int toGenerate = targetTotal - fixedPlanets.Count;

        for (int i = 0; i < toGenerate; i++)
            fixedPlanets.Add(CreatePlanet(FactionIdToRace(star.FactionId), null, forceNone: i < noneNeeded));

        AssignOrbitsAndNames(fixedPlanets, targetTotal, usedOrbits, star);
        return fixedPlanets.OrderBy(p => p.OrbitIndex).ToList();
    }

    private (List<PlanetData> planets, HashSet<int> usedOrbits, int noneCount) CollectFixedPlanets(
        StarData star, FixedStarData fs)
    {
        var list = new List<PlanetData>();
        var usedOrbits = new HashSet<int>();
        int noneCount = 0;

        if (fs.Planets == null) return (list, usedOrbits, noneCount);

        foreach (var fp in fs.Planets.Values)
        {
            string baseRace = fp.Race ?? GalaxyConstants.RACE_NONE_KEY;
            bool isNone = baseRace == GalaxyConstants.RACE_NONE_KEY;
            string resolvedOwner = isNone ? GalaxyConstants.RACE_NONE_KEY
                : OwnerResolver.Resolve(fp.CurOwner ?? baseRace, FactionIdToRace(star.FactionId) ?? GalaxyConstants.RACE_NONE_KEY, _ctx.AvailableRaces);

            if (isNone) noneCount++;

            string resolvedName = ResolveFixedPlanetName(fp.Name, fp.Race ?? GalaxyConstants.RACE_NONE_KEY, FactionIdToRace(star.FactionId));
            var planet = CreatePlanet(resolvedOwner, fp, forceNone: false);
            planet.Name = resolvedName;
            planet.Type = !string.IsNullOrEmpty(fp.Type)
                ? fp.Type : _ctx.AvailablePlanetTypes[UnityEngine.Random.Range(0, _ctx.AvailablePlanetTypes.Count)];

            if (!string.IsNullOrEmpty(planet.Name) && planet.Name != GalaxyConstants.VAL_UNKNOWN)
                _ctx.UsedPlanetNames.Add(planet.Name);

            if (fp.OrbitIndex.HasValue && fp.OrbitIndex > 0)
            {
                planet.OrbitIndex = fp.OrbitIndex.Value;
                usedOrbits.Add(planet.OrbitIndex);
            }
            list.Add(planet);
        }
        return (list, usedOrbits, noneCount);
    }

    private PlanetData CreatePlanet(string owner, FixedPlanetData fp, bool forceNone)
    {
        var planet = new PlanetData();
        string size = _ctx.AvailablePlanetSizes[UnityEngine.Random.Range(0, _ctx.AvailablePlanetSizes.Count)];

        if (fp != null) ApplyFixedPlanetProps(planet, fp, owner, ref size);
        else ApplyRandomPlanetProps(planet, owner, forceNone);

        FinalizePlanetVisuals(planet, size);
        return planet;
    }

    private void ApplyFixedPlanetProps(PlanetData planet, FixedPlanetData fp,
        string resolvedOwner, ref string size)
    {
        bool isNone = (fp.Race ?? GalaxyConstants.RACE_NONE_KEY) == GalaxyConstants.RACE_NONE_KEY;
        planet.Race = fp.Race ?? GalaxyConstants.RACE_NONE_KEY;
        string factionId = isNone ? GalaxyConstants.RACE_NONE_KEY
            : RaceToFactionId(resolvedOwner, _ctx.FactionLineups);
        planet.FactionId = factionId;
        planet.Name = string.IsNullOrEmpty(fp.Name) ? GalaxyConstants.VAL_UNKNOWN : fp.Name;

        if (!string.IsNullOrEmpty(fp.Size) && _ctx.AvailablePlanetSizes.Contains(fp.Size)) size = fp.Size;

        planet.Graphic = GenerationHelpers.CleanResourcePath(fp.Graphic);
        planet.OrbitalObjects = GenerationHelpers.CleanResourcePath(fp.OrbitalObjects);
        planet.Atmosphere = GenerationHelpers.CleanResourcePath(fp.Atmosphere);
        planet.OrbitSpeed = fp.OrbitSpeed ?? 0f;
        planet.DaySpeed = fp.DaySpeed ?? 0;
        planet.CloudsSpeed = fp.CloudsSpeed ?? 0;
        planet.OrbitRadius = fp.OrbitRadius ?? 0f;
        planet.SatellitesCount = fp.SatellitesCount ?? -1;
    }

    private void ApplyRandomPlanetProps(PlanetData planet, string owner, bool forceNone)
    {
        bool isNone = forceNone || owner == GalaxyConstants.RACE_NONE_KEY;
        string race = isNone ? GalaxyConstants.RACE_NONE_KEY : ResolveRandomRace(owner);
        planet.Race = race;
        planet.FactionId = isNone ? GalaxyConstants.RACE_NONE_KEY : RaceToFactionId(race, _ctx.FactionLineups);
        planet.Name = GalaxyConstants.VAL_UNKNOWN;
        planet.Type = _ctx.AvailablePlanetTypes[UnityEngine.Random.Range(0, _ctx.AvailablePlanetTypes.Count)];
        planet.OrbitSpeed = 0f;
        planet.SatellitesCount = -1;
    }

    private void FinalizePlanetVisuals(PlanetData planet, string size)
    {
        planet.Size = size;
        planet.CurrentColor = GenerationHelpers.GetRaceColor(planet.Race, _ctx.AvailableRaces);

        if (string.IsNullOrEmpty(planet.Graphic)) planet.Graphic = GenerationHelpers.GetRandomPlanetGraphic(size);
        if (string.IsNullOrEmpty(planet.MaskGraphic)) planet.MaskGraphic = GenerationHelpers.GetMaskPath(size);
        if (string.IsNullOrEmpty(planet.Atmosphere)) planet.Atmosphere = GenerationHelpers.GenerateAtmosphere(size, _ctx.PlanetSizeRules);

        if (Mathf.Abs(planet.OrbitSpeed) < NearZero)
            planet.OrbitSpeed = UnityEngine.Random.Range(GalaxyConstants.PLANET_ORBIT_SPEED_MIN, GalaxyConstants.PLANET_ORBIT_SPEED_MAX)
                * (UnityEngine.Random.value > 0.5f ? 1f : -1f);

        if (planet.DaySpeed <= 0) planet.DaySpeed = UnityEngine.Random.Range(GalaxyConstants.PLANET_DAY_SPEED_MIN, GalaxyConstants.PLANET_DAY_SPEED_MAX + 1);
        if (planet.CloudsSpeed <= 0) planet.CloudsSpeed = Mathf.RoundToInt(
            planet.DaySpeed * UnityEngine.Random.Range(GalaxyConstants.CLOUD_SPEED_FACTOR_MIN, GalaxyConstants.CLOUD_SPEED_FACTOR_MAX));

        planet.InitialAngle = planet.CurrentAngle = UnityEngine.Random.Range(0f, 360f);

        if (string.IsNullOrEmpty(planet.OrbitalObjects)
            && planet.Race != GalaxyConstants.RACE_NONE_KEY
            && UnityEngine.Random.value < GalaxyConstants.ORBITAL_OBJ_CHANCE)
            planet.OrbitalObjects = GenerationHelpers.GetRandomOrbitalPath();

        if (planet.SatellitesCount == -1) planet.SatellitesCount = GenerationHelpers.CalculateSatelliteCount(size, _ctx.PlanetSizeRules);

        var cfg = _ctx.Config.Planets;
        planet.OrbitEccentricity = UnityEngine.Random.Range(cfg.EccentricityMin, cfg.EccentricityMax);
        planet.OrbitTiltDeg = UnityEngine.Random.Range(0f, 360f);
    }

    // Второй проход: назначает орбитные индексы, имена, кастомные свойства и радиусы орбит.
    private void AssignOrbitsAndNames(List<PlanetData> list, int total,
        HashSet<int> usedOrbits, StarData star)
    {
        var freeSlots = new List<int>(total);
        for (int i = 1; i <= total; i++)
            if (!usedOrbits.Contains(i)) freeSlots.Add(i);

        foreach (var planet in list)
        {
            planet.CurrentAngle = UnityEngine.Random.Range(0f, 360f);
            if (planet.OrbitIndex <= 0)
                planet.OrbitIndex = freeSlots.Count > 0 ? PopRandom(freeSlots) : GalaxyConstants.ORBIT_FALLBACK;

            ResolvePlanetName(planet, star);
            GenerateSatellites(planet, null);
            CustomPropertyResolver.ResolveAndApplyProperties(planet, planet.CustomProperties, "Planets", _ctx.Config);
        }

        AssignOrbitRadii(list);
    }

    private void AssignOrbitRadii(List<PlanetData> list)
    {
        list.Sort((a, b) => a.OrbitIndex.CompareTo(b.OrbitIndex));
        float prevApocenter = 0f;

        for (int i = 0; i < list.Count; i++)
        {
            var planet = list[i];
            float e = Mathf.Clamp(planet.OrbitEccentricity, 0f, 0.99f);

            if (planet.OrbitRadius > GalaxyConstants.MIN_ORBIT_RADIUS)
            {
                // Фиксированный радиус интерпретируется как перицентр: a = peri / (1 - e)
                planet.OrbitRadius = planet.OrbitRadius / Mathf.Max(1f - e, 0.01f);
            }
            else
            {
                float gap = UnityEngine.Random.Range(GalaxyConstants.ORBIT_GAP_MIN, GalaxyConstants.ORBIT_GAP_MAX) * _systemSizeMult;
                float peri = prevApocenter + gap;
                float minPeri = i == 0
                    ? UnityEngine.Random.Range(_systemSizeMult * GalaxyConstants.FIRST_ORBIT_MIN, _systemSizeMult * GalaxyConstants.FIRST_ORBIT_MAX)
                    : peri;
                peri = Mathf.Max(peri, minPeri);
                planet.OrbitRadius = peri / Mathf.Max(1f - e, 0.01f);
            }

            prevApocenter = planet.OrbitRadius * (1f + e);
        }
    }

    // ── ШАГ 4 — СПУТНИКИ ─────────────────────────────────────────────────────

    private void GenerateSatellites(PlanetData parent, Dictionary<string, FixedSatelliteData> fixedSats)
    {
        parent.Satellites = new List<SatelliteData>();
        int idx = 0;

        if (fixedSats != null)
            foreach (var (key, fs) in fixedSats)
            {
                var sat = CreateSatellite(parent, fs, idx);
                if (string.IsNullOrEmpty(sat.Name)) sat.Name = key;
                parent.Satellites.Add(sat);
                idx++;
            }

        int target = Mathf.Max(parent.Satellites.Count, parent.SatellitesCount);
        for (int i = parent.Satellites.Count; i < target; i++)
            parent.Satellites.Add(CreateSatellite(parent, null, i));
    }

    private SatelliteData CreateSatellite(PlanetData parent, FixedSatelliteData fs, int index)
    {
        var sat = new SatelliteData();
        if (fs != null) ApplyFixedSatelliteProps(sat, fs, parent);
        else ApplyRandomSatelliteProps(sat, parent, index);
        FinalizeSatelliteProps(sat, parent, index);
        return sat;
    }

    private void ApplyFixedSatelliteProps(SatelliteData sat, FixedSatelliteData fs, PlanetData parent)
    {
        sat.Size = ResolveValidSize(fs.Size, _ctx.AvailableSatelliteSizes, GalaxyConstants.FALLBACK_SAT_SIZE);
        sat.Name = fs.Name ?? string.Empty;
        sat.Graphic = GenerationHelpers.CleanResourcePath(fs.Graphic);
        sat.Atmosphere = GenerationHelpers.CleanResourcePath(fs.Atmosphere);
        sat.OrbitRadius = fs.OrbitRadius ?? 0f;
        sat.OrbitSpeed = fs.OrbitSpeed ?? 0f;
        sat.DaySpeed = fs.DaySpeed ?? 0;
        sat.CloudsSpeed = fs.CloudsSpeed ?? 0;
        sat.FactionId = !string.IsNullOrEmpty(fs.CurOwner)
            ? RaceToFactionId(fs.CurOwner, _ctx.FactionLineups)
            : parent.FactionId;
        sat.Race = parent.Race;
    }

    private void ApplyRandomSatelliteProps(SatelliteData sat, PlanetData parent, int index)
    {
        sat.Size = ResolveValidSize(null, _ctx.AvailableSatelliteSizes, GalaxyConstants.FALLBACK_SAT_SIZE);
        sat.Name = $"{parent.Name} {ToRoman(index + 1)}";
        sat.FactionId = parent.FactionId;
        sat.Race = parent.Race;
    }

    private void FinalizeSatelliteProps(SatelliteData sat, PlanetData parent, int index)
    {
        if (string.IsNullOrEmpty(sat.Graphic)) sat.Graphic = GenerationHelpers.GetRandomSatelliteGraphic();

        float baseR = GenerationHelpers.GetPlanetRadiusInPixels(parent.Size, _ctx.PlanetSizeRules) + GalaxyConstants.SAT_ORBIT_BASE_OFFSET;
        if (sat.OrbitRadius <= 0f) sat.OrbitRadius = baseR + index * GalaxyConstants.SAT_ORBIT_SPACING;

        if (Mathf.Abs(sat.OrbitSpeed) < NearZero)
            sat.OrbitSpeed = UnityEngine.Random.Range(GalaxyConstants.SAT_ORBIT_SPEED_MIN, GalaxyConstants.SAT_ORBIT_SPEED_MAX)
                * (UnityEngine.Random.value > 0.5f ? 1f : -1f);

        if (sat.DaySpeed <= 0) sat.DaySpeed = UnityEngine.Random.Range(GalaxyConstants.SAT_DAY_SPEED_MIN, GalaxyConstants.SAT_DAY_SPEED_MAX + 1);
        if (sat.CloudsSpeed <= 0) sat.CloudsSpeed = Mathf.RoundToInt(sat.DaySpeed * GalaxyConstants.SAT_CLOUD_SPEED_FACTOR);

        sat.CurrentAngle = UnityEngine.Random.Range(0f, 360f);
        sat.CurrentRotationAngle = UnityEngine.Random.Range(0f, 360f);
    }

    // ── ШАГ 5 — РАЗРЕШЕНИЕ ВЛАДЕЛЬЦЕВ ────────────────────────────────────────
    // Этап 1 (сверху вниз): фиксированный владелец родителя перекрывает Unresolved детей.
    // Этап 2 (снизу вверх): агрегируем владельца из заселённых детей. None не перезаписывается.

    // ResolveAllOwners работает в два прохода:
    //   1. Внутри звезды/созвездия агрегируем Race-ключи (старый Owner) как промежуточное значение
    //      в c.Owner / star._resolvedRace (временно через star.FactionId как raceKey до финализации).
    //   2. В конце финализируем: конвертируем race → factionId для всех звёзд.
    private void ResolveAllOwners(GalaxyData galaxy)
    {
        foreach (var c in galaxy.Constellations)
        {
            // c.Owner — Race-ключ (из PremadeConfig). Конвертируем для проверки.
            string constRace = FactionIdToRace(c.Owner);
            bool constFixed = OwnerResolver.IsFixed(constRace, _ctx.AvailableRaces);

            foreach (var star in c.Stars)
            {
                // star.FactionId хранит либо RACE_UNRESOLVED_KEY либо уже FactionId.
                // Переведём в race для резолвинга.
                string starRace = FactionIdToRace(star.FactionId);

                // Если созвездие зафиксировано — перекрываем Unresolved звёзды.
                if (constFixed && starRace != GalaxyConstants.RACE_NONE_KEY)
                    starRace = constRace;

                bool starFixed = OwnerResolver.IsFixed(starRace, _ctx.AvailableRaces);
                if (starFixed)
                {
                    foreach (var planet in star.Planets)
                        PropagateStarOwnerToPlanet(planet, starRace);
                }
                else
                {
                    // Агрегируем из планет: используем Race планеты как промежуточное значение.
                    starRace = OwnerResolver.ComputeFromChildren(star.Planets.Select(p => p.Race));
                }

                // Финализируем FactionId звезды из race.
                star.FactionId = RaceToFactionId(starRace, _ctx.FactionLineups);
            }

            if (!constFixed)
                c.Owner = OwnerResolver.ComputeFromChildren(c.Stars.Select(s => FactionIdToRace(s.FactionId)));
        }
    }

    private void PropagateStarOwnerToPlanet(PlanetData planet, string starRace)
    {
        if (planet.Race == GalaxyConstants.RACE_NONE_KEY) return;
        // Не перезаписываем если у планеты уже есть явный FactionId (не Unresolved).
        if (planet.FactionId != GalaxyConstants.RACE_UNRESOLVED_KEY
            && !string.IsNullOrEmpty(planet.FactionId)
            && planet.FactionId != GalaxyConstants.RACE_NONE_KEY
            && FactionIdToRace(planet.FactionId) != GalaxyConstants.RACE_UNRESOLVED_KEY) return;
        planet.FactionId = RaceToFactionId(starRace, _ctx.FactionLineups);
        planet.CurrentColor = GenerationHelpers.GetRaceColor(planet.Race, _ctx.AvailableRaces);
    }

    /// <summary>
    /// Маппинг RaceId → FactionId: ищем первую фракцию с данным RaceId в конфиге.
    /// Fallback: Race_Main pattern, иначе RACE_NONE_KEY.
    /// </summary>
    private static string RaceToFactionId(string raceId, Dictionary<string, List<string>> factionLineups)
    {
        if (string.IsNullOrEmpty(raceId)
            || raceId == GalaxyConstants.RACE_NONE_KEY
            || raceId == GalaxyConstants.RACE_UNRESOLVED_KEY
            || raceId == GalaxyConstants.RACE_COMMON_KEY)
            return raceId;

        // Прямая конвенция: Race1 → Race1_Main
        string conventional = $"{raceId}_Main";
        if (factionLineups.ContainsKey(conventional)) return conventional;

        // Ключ уже является FactionId (например "DomA") — вернуть как есть.
        if (factionLineups.ContainsKey(raceId)) return raceId;

        return raceId; // оставляем как есть, если маппинг не найден
    }

    /// <summary>
    /// Обратный маппинг FactionId → RaceId для логики резолвинга.
    /// Конвенция: Race1_Main → Race1. Для остальных возвращает factionId как есть.
    /// </summary>
    private static string FactionIdToRace(string factionId)
    {
        if (string.IsNullOrEmpty(factionId)) return GalaxyConstants.RACE_NONE_KEY;
        if (factionId.EndsWith("_Main"))
            return factionId.Substring(0, factionId.Length - 5);
        return factionId;
    }

    // ── ИМЕНА ─────────────────────────────────────────────────────────────────

    // Заранее резервирует имена фиксированных объектов, чтобы они не попали в случайную раздачу.
    // Использует HashSet для отслеживания зарезервированных имён перед фильтрацией пула.
    private void PreReserveFixedNames(string galaxyKey)
    {
        var premadeGalaxy = _ctx.PremadeConfig?.Galaxies?.GetValueOrDefault(galaxyKey);
        if (premadeGalaxy?.Constellations == null) return;

        // Собираем все зарезервированные имена созвездий за один проход
        var reservedConstNames = new HashSet<string>();

        foreach (var fc in premadeGalaxy.Constellations.Values)
        {
            if (!string.IsNullOrEmpty(fc.Name)
                && _ctx.TextConfig.ConstNames?.TryGetValue(fc.Name, out string constName) == true)
                reservedConstNames.Add(constName);

            if (fc.Stars == null) continue;

            foreach (var fs in fc.Stars.Values)
            {
                string owner = OwnerResolver.Resolve(fs.Owner ?? GalaxyConstants.RACE_NONE_KEY, fc.Owner, _ctx.AvailableRaces);
                string starName = ResolveStarFixedName(fs.Name, owner);
                if (!string.IsNullOrEmpty(starName)) _ctx.UsedStarNames.Add(starName);

                if (fs.Planets == null) continue;
                foreach (var fp in fs.Planets.Values)
                {
                    string pName = ResolveFixedPlanetName(fp.Name, fp.Race, owner);
                    if (!string.IsNullOrEmpty(pName) && pName != GalaxyConstants.VAL_UNKNOWN)
                        _ctx.UsedPlanetNames.Add(pName);
                }
            }
        }

        // Удаляем зарезервированные имена из пула созвездий за один проход
        _ctx.ConstNamePool.RemoveAll(name => reservedConstNames.Contains(name));
    }

    private string ResolveConstellationName(string key)
    {
        if (string.IsNullOrEmpty(key)) return PopConstellationName();
        if (_ctx.TextConfig.ConstNames?.TryGetValue(key, out string resolved) == true) return resolved;
        return key;
    }

    private string PopConstellationName()
    {
        string name = PopRandom(_ctx.ConstNamePool);
        return name ?? $"UNNAMED_C_{++_ctx.UnnamedConstCounter}";
    }

    // Ищет имя звезды: Fixed-пул расы → Common → все расы → ключ как есть.
    private string ResolveStarFixedName(string key, string race)
    {
        if (string.IsNullOrEmpty(key)) return null;
        if (!string.IsNullOrEmpty(race) && _ctx.StarNamesByRace.TryGetValue(race, out var racePool)
            && racePool.Fixed.TryGetValue(key, out string byRace)) return byRace;
        if (_ctx.CommonStarNames.Fixed.TryGetValue(key, out string common)) return common;
        foreach (var pool in _ctx.StarNamesByRace.Values)
            if (pool.Fixed.TryGetValue(key, out string any)) return any;
        return key;
    }

    // Делегируем в GalaxyGenerationContext — единственная реализация для всего проекта.
    private string ResolveStarNameFromPlanets(StarData star) => _ctx.ResolveStarNameFromPlanets(star);

    // Приоритет: Fixed владельца звезды → Fixed расы планеты → ключ как есть.
    private string ResolveFixedPlanetName(string key, string race, string starOwner)
    {
        if (string.IsNullOrEmpty(key)) return GalaxyConstants.VAL_UNKNOWN;
        return TryGetFixedPlanetName(key, starOwner) ?? TryGetFixedPlanetName(key, race) ?? key;
    }

    private string TryGetFixedPlanetName(string key, string race)
    {
        if (string.IsNullOrEmpty(race) || race == GalaxyConstants.RACE_NONE_KEY) return null;
        return _ctx.PlanetNamesByRace.TryGetValue(race, out var pool)
            && pool.Fixed.TryGetValue(key, out string name) ? name : null;
    }

    // Делегируем в GalaxyGenerationContext — единственная реализация для всего проекта.
    private void ResolvePlanetName(PlanetData planet, StarData star) => _ctx.ResolvePlanetName(planet);

    // ── ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ────────────────────────────────────────────────

    private int CalculateSystemSize(List<PlanetData> planets) =>
        GenerationHelpers.CalculateSystemSize(planets, _systemSizeMult);

    private static int CalculateNoneCount(int total) =>
        Mathf.RoundToInt(total * UnityEngine.Random.Range(0f, GalaxyConstants.NONE_ORBIT_MAX_FRACTION));

    private int ParseNoneCount(string planetsNone, int total)
    {
        if (string.IsNullOrEmpty(planetsNone)) return CalculateNoneCount(total);
        if (planetsNone.Contains("%") && float.TryParse(planetsNone.Replace("%", ""), out float pct))
            return Mathf.RoundToInt(total * (pct / 100f));
        return int.TryParse(planetsNone, out int n) ? n : 0;
    }

    private int ResolveTargetPlanetCount(FixedStarData fs, int alreadyCreated)
    {
        int min = Mathf.Max(MinPlanetsPerStarHardMin, _ctx.ActiveGalaxyConfig.MinPlanetsPerStar);
        int fromConfig = fs.PlanetsCount ?? UnityEngine.Random.Range(min, _ctx.ActiveGalaxyConfig.MaxPlanetsPerStar + 1);
        return Mathf.Max(fromConfig, alreadyCreated);
    }

    private string ResolveRandomRace(string fallback)
    {
        if (OwnerResolver.IsFixed(fallback, _ctx.AvailableRaces)) return fallback;
        int count = _ctx.AvailableRaces.Count;
        if (count == 0)
            Debug.LogWarning("[GalaxyGenerator] ResolveRandomRace: AvailableRaces is empty — returning RACE_NONE_KEY. Galaxy generation may be broken.");
        return count > 0 ? _ctx.AvailableRaces.Keys.ElementAt(UnityEngine.Random.Range(0, count)) : GalaxyConstants.RACE_NONE_KEY;
    }

    private int GetConstellationCapacity(ConstellationData c, GalaxyConfigData cfg) =>
        (c.FixedStarsCount ?? 0) > 0 ? c.FixedStarsCount.Value : cfg.MaxStarsPerConstellation;

    private bool TryAddStar(GalaxyData galaxy, ConstellationData c, StarData star)
    {
        if (galaxy.StarsMap.ContainsKey(star.Uid)) return false;
        c.Stars.Add(star);
        galaxy.StarsMap[star.Uid] = star;
        foreach (var planet in star.Planets)
            if (!galaxy.PlanetsMap.ContainsKey(planet.Uid))
                galaxy.PlanetsMap[planet.Uid] = planet;
        return true;
    }

    private Vector2 GetRandomPos(int w, int h, Vector2? center = null, float radius = 0f)
    {
        if (center.HasValue && radius > 0)
        {
            Vector2 p = center.Value + UnityEngine.Random.insideUnitCircle * radius;
            return new Vector2(Mathf.Clamp(p.x, 0, w), Mathf.Clamp(p.y, 0, h));
        }
        return new Vector2(UnityEngine.Random.Range(0f, w), UnityEngine.Random.Range(0f, h));
    }

    private string ResolveValidSize(string candidate, List<string> valid, string fallback)
    {
        if (!string.IsNullOrEmpty(candidate) && valid.Contains(candidate)) return candidate;
        return valid.Count > 0 ? valid[UnityEngine.Random.Range(0, valid.Count)] : fallback;
    }

    private T PopRandom<T>(List<T> list)
    {
        if (list.Count == 0) return default;
        int i = UnityEngine.Random.Range(0, list.Count);
        T val = list[i]; list.RemoveAt(i);
        return val;
    }

    private static string ToRoman(int n)
    {
        if (n < 1) return string.Empty;
        // Таблица покрывает до 20 спутников. При n > 20 возвращаем число как строку.
        string[] table = { "I","II","III","IV","V","VI","VII","VIII","IX","X",
                            "XI","XII","XIII","XIV","XV","XVI","XVII","XVIII","XIX","XX" };
        return n <= table.Length ? table[n - 1] : n.ToString();
    }
}