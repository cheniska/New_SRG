﻿using UnityEngine;
using System.Linq;

// ── ITEM FACTORY ──────────────────────────────────────────────────────────────
//
// Создаёт ItemInstance из конфига с учётом множителей производителя расы/фракции.
// Используется при экипировке стартового набора (SpawnPlayer) и магазинах.

public static class ItemFactory
{
    /// <summary>
    /// Создаёт ItemInstance с учётом множителей производителя.
    /// Ищет PriceMult и DurabilityMult в конфиге расы и фракции производителя.
    /// </summary>
    public static ItemInstance Create(
        string category,
        string itemId,
        EquipmentConfig equipConfig,
        GalaxyConfig galaxyConfig)
    {
        var cfg = equipConfig?.GetItem(category, itemId);
        if (cfg == null)
        {
            UnityEngine.Debug.LogError($"[ItemFactory] Item '{category}/{itemId}' not found in EquipmentConfig.");
            return null;
        }

        float priceMult = 1f, durMult = 1f;

        // Множитель расы производителя
        if (cfg.Manufacturer?.Race != null &&
            galaxyConfig?.Races != null &&
            galaxyConfig.Races.TryGetValue(cfg.Manufacturer.Race, out var raceCfg) &&
            raceCfg.EquipmentManufacturing != null)
        {
            priceMult *= raceCfg.EquipmentManufacturing.PriceMult;
            durMult *= raceCfg.EquipmentManufacturing.DurabilityMult;
        }

        // Множитель фракции производителя (поверх расового)
        if (cfg.Manufacturer?.Faction != null &&
            galaxyConfig?.Ships?.Factions != null &&
            galaxyConfig.Ships.Factions.TryGetValue(cfg.Manufacturer.Faction, out var factionCfg) &&
            factionCfg.EquipmentManufacturing != null)
        {
            priceMult *= factionCfg.EquipmentManufacturing.PriceMult;
            durMult *= factionCfg.EquipmentManufacturing.DurabilityMult;
        }

        return ItemInstance.FromConfig(category, itemId, cfg, equipConfig, priceMult, durMult);
    }

    /// <summary>
    /// Создаёт и устанавливает стартовый набор снаряжения для корабля.
    /// kit — словарь "Category" → "ItemId" (из ShipTypeConfig.StarterKit).
    ///
    /// Порядок важен: Hull устанавливается первым — он инициализирует слоты.
    /// Остальные предметы раскладываются по первым свободным слотам своей категории.
    /// Если слот для категории недоступен в серии корпуса — предмет уходит в инвентарь.
    /// </summary>
    public static void EquipStarterKit(
        ShipData ship,
        System.Collections.Generic.Dictionary<string, string> kit,
        EquipmentConfig equipConfig,
        GalaxyConfig galaxyConfig)
    {
        if (kit == null || equipConfig == null)
        {
            UnityEngine.Debug.LogError($"[ItemFactory.EquipStarterKit] kit={kit == null} equipConfig={equipConfig == null} — выход");
            return;
        }

        UnityEngine.Debug.Log($"[ItemFactory.EquipStarterKit] Начало. Kit: {string.Join(", ", kit.Select(k => k.Key + "=" + k.Value))}");

        // Шаг 1: устанавливаем корпус — он инициализирует слоты через HullSeries
        if (kit.TryGetValue("Hull", out var hullId))
        {
            var hullInst = Create("Hull", hullId, equipConfig, galaxyConfig);
            if (hullInst == null)
            {
                UnityEngine.Debug.LogError($"[ItemFactory.EquipStarterKit] Create('Hull', '{hullId}') вернул null! Проверь EquipmentConfig.");
            }
            else
            {
                ship.AllItems[hullInst.Uid] = hullInst;

                string seriesId = hullInst.GetParamString("Series");
                var series = equipConfig.GetSeries(seriesId);
                if (series == null)
                    UnityEngine.Debug.LogError($"[ItemFactory.EquipStarterKit] HullSeries '{seriesId}' не найдена в EquipmentConfig.HullSeries! " +
                                               $"Доступные серии: {string.Join(", ", equipConfig.HullSeries.Keys)}");
                else
                {
                    ship.Equipment.InitForSeries(series, equipConfig);
                    UnityEngine.Debug.Log($"[ItemFactory.EquipStarterKit] Корпус '{hullId}' серия '{seriesId}' — слоты инициализированы: " +
                                          $"{string.Join(", ", ship.Equipment.Slots.Keys)}");
                }

                ship.Equipment.Set("Hull_0", hullInst.Uid);
                ship.MaxHull = UnityEngine.Mathf.RoundToInt(hullInst.GetParam("HP", ship.BaseHull > 0 ? ship.BaseHull : 100f));
                ship.CurrentHull = ship.MaxHull;
            }
        }
        else
        {
            UnityEngine.Debug.LogError("[ItemFactory.EquipStarterKit] В StarterKit нет ключа 'Hull'! Слоты не будут инициализированы.");
        }

        // Шаг 2: устанавливаем остальное оборудование
        foreach (var kv in kit)
        {
            if (kv.Key == "Hull") continue;

            var inst = Create(kv.Key, kv.Value, equipConfig, galaxyConfig);
            if (inst == null)
            {
                UnityEngine.Debug.LogError($"[ItemFactory.EquipStarterKit] Create('{kv.Key}', '{kv.Value}') вернул null!");
                continue;
            }

            ship.AllItems[inst.Uid] = inst;

            string slotKey = FindFreeSlot(ship, kv.Key);
            if (slotKey != null)
            {
                ship.Equipment.Set(slotKey, inst.Uid);
                UnityEngine.Debug.Log($"[ItemFactory.EquipStarterKit] '{kv.Key}'='{kv.Value}' -> слот '{slotKey}' OK");
            }
            else
            {
                ship.Inventory.Add(inst);
                UnityEngine.Debug.LogWarning(
                    $"[ItemFactory.EquipStarterKit] Нет слота для '{kv.Key}' (серия не поддерживает). Отправлен в инвентарь. " +
                    $"Текущие слоты: {string.Join(", ", ship.Equipment.Slots.Keys)}");
            }
        }

        UnityEngine.Debug.Log($"[ItemFactory.EquipStarterKit] Готово. Слотов: {ship.Equipment.Slots.Count}, " +
                              $"AllItems: {ship.AllItems.Count}, Инвентарь: {ship.Inventory.Count}");
    }

    private static string FindFreeSlot(ShipData ship, string category)
    {
        foreach (var kv in ship.Equipment.Slots)
            if (kv.Key.StartsWith(category + "_", System.StringComparison.Ordinal) && kv.Value == null)
                return kv.Key;
        return null;
    }
}