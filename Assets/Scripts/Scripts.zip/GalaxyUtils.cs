using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

// Все игровые константы. Неизменяемые логические ключи — compile-time const.
// Настраиваемые значения — runtime-поля, инициализируемые из GameSettingsConfig
// через Initialize(). До вызова Initialize() действуют встроенные дефолты.

#region Save / Load


#endregion

#region Custom Property Resolver

public static class OwnerResolver
{
    // None у потомка — явный сигнал «пусто», родитель не перекрывает.
    public static string Resolve(string child, string parent,
        IReadOnlyDictionary<string, RaceInfo> races)
    {
        if (child == GalaxyConstants.RACE_NONE_KEY) return GalaxyConstants.RACE_NONE_KEY;
        if (IsFixed(parent, races)) return parent;
        return IsFixed(child, races) ? child : GalaxyConstants.RACE_NONE_KEY;
    }

    public static bool IsFixed(string owner, IReadOnlyDictionary<string, RaceInfo> races) =>
        !string.IsNullOrEmpty(owner)
        && owner != GalaxyConstants.RACE_NONE_KEY
        && owner != GalaxyConstants.RACE_COMMON_KEY
        && races.ContainsKey(owner);

    // None-дети игнорируются. Один уникальный → он; несколько/Common → Common; все None → None.
    // Реализован без LINQ и аллокаций — один проход по коллекции.
    public static string ComputeFromChildren(IEnumerable<string> childOwners)
    {
        string single = null;
        bool multiple = false;

        foreach (var o in childOwners)
        {
            if (string.IsNullOrEmpty(o) || o == GalaxyConstants.RACE_NONE_KEY) continue;

            if (single == null)
            {
                single = o;
            }
            else if (o != single)
            {
                multiple = true;
                break;
            }
        }

        if (single == null) return GalaxyConstants.RACE_NONE_KEY;
        if (multiple || single == GalaxyConstants.RACE_COMMON_KEY) return GalaxyConstants.RACE_COMMON_KEY;
        return single;
    }
}


public static class CustomPropertyResolver
{
    private static readonly Dictionary<Type, Dictionary<string, Func<object, string>>> _cache = new();
    public static void ResolveAndApplyProperties(
        object entity,
        Dictionary<string, string> customProperties,
        string category,
        GalaxyConfig config)
    {
        if (config.CustomProperties == null ||
            !config.CustomProperties.TryGetValue(category, out var props)) return;

        foreach (var pair in props)
            customProperties[pair.Key] = ResolveValue(entity, pair.Value);
    }

    private static string ResolveValue(object entity, CustomPropertyConfig propDef)
    {
        if (propDef.Default == null) return GetFallbackValue(propDef);

        // Формат 1: просто строка — "Default": "No"
        if (propDef.Default.Type == JTokenType.String)
            return propDef.Default.ToString();

        // Формат 2: объект с зависимостью от одного поля (старый)
        // "Default": { "Type": { "Dwarf": "Yes" } }
        if (propDef.Default.Type == JTokenType.Object)
        {
            var mappingObject = (JObject)propDef.Default;
            foreach (var dependency in mappingObject)
            {
                string entityValue = GetEntityValue(entity, dependency.Key);
                if (dependency.Value is JObject map &&
                    map.TryGetValue(entityValue, StringComparison.OrdinalIgnoreCase, out var result))
                    return result.ToString();
            }
            return GetFallbackValue(propDef);
        }

        // Формат 3: массив правил с множественными условиями (новый)
        // "Default": [ { "Conditions": { "Color": ["Red"], "Type": ["Dwarf"] }, "Result": "Yes" } ]
        if (propDef.Default.Type == JTokenType.Array)
        {
            var rules = propDef.Default.ToObject<List<CustomPropertyRule>>();
            if (rules == null) return GetFallbackValue(propDef);

            foreach (var rule in rules)
            {
                if (!MatchesConditions(entity, rule.Conditions)) continue;

                if (string.Equals(rule.Result, "Random", StringComparison.OrdinalIgnoreCase))
                    return GetRandomValue(propDef);

                return rule.Result;
            }
        }

        return GetFallbackValue(propDef);
    }

    /// <summary>
    /// Все условия — AND. Значения внутри одного условия — OR.
    /// Пустой словарь условий — всегда true (fallback-правило).
    /// </summary>
    private static bool MatchesConditions(object entity,
        Dictionary<string, List<string>> conditions)
    {
        if (conditions == null || conditions.Count == 0) return true;

        foreach (var condition in conditions)
        {
            string entityValue = GetEntityValue(entity, condition.Key);
            bool anyMatch = condition.Value.Any(v =>
                string.Equals(v, entityValue, StringComparison.OrdinalIgnoreCase));
            if (!anyMatch) return false;
        }
        return true;
    }

    private static string GetEntityValue(object entity, string fieldName)
    {
        var accessors = GetAccessors(entity.GetType());
        return accessors.TryGetValue(fieldName.ToLowerInvariant(), out var getter)
            ? getter(entity) ?? string.Empty
            : string.Empty;
    }

    private static Dictionary<string, Func<object, string>> GetAccessors(Type type)
    {
        if (_cache.TryGetValue(type, out var cached)) return cached;

        var map = new Dictionary<string, Func<object, string>>();

        foreach (var prop in type.GetProperties(
            System.Reflection.BindingFlags.Public |
            System.Reflection.BindingFlags.Instance))
        {
            if (prop.GetIndexParameters().Length > 0) continue;
            var p = prop;
            map[p.Name.ToLowerInvariant()] = obj =>
                p.GetValue(obj)?.ToString() ?? string.Empty;
        }

        foreach (var field in type.GetFields(
            System.Reflection.BindingFlags.Public |
            System.Reflection.BindingFlags.Instance))
        {
            var f = field;
            map[f.Name.ToLowerInvariant()] = obj =>
                f.GetValue(obj)?.ToString() ?? string.Empty;
        }

        _cache[type] = map;
        return map;
    }

    private static string GetFallbackValue(CustomPropertyConfig propDef)
    {
        if (propDef.Values == null || propDef.Values.Count == 0)
            return GalaxyConstants.VAL_UNKNOWN;
        if (propDef.Values.Contains("No")) return "No";
        if (propDef.Values.Contains("None")) return "None";
        return propDef.Values.FirstOrDefault() ?? GalaxyConstants.VAL_UNKNOWN;
    }

    private static string GetRandomValue(CustomPropertyConfig propDef)
    {
        if (propDef.Values == null || propDef.Values.Count == 0)
            return GalaxyConstants.VAL_UNKNOWN;
        return propDef.Values[UnityEngine.Random.Range(0, propDef.Values.Count)];
    }
}

#endregion

#region Logger

public static class GalaxyLogger
{
    private const int MaxConsoleChunk = 15000;
    private static readonly string LogDirectory = Path.Combine(Application.dataPath, "..", "Logs");
    private static readonly Regex RichTagRegex = new Regex("<.*?>", RegexOptions.Compiled);

    public static void LogGalaxy(GalaxyData galaxy, int seed, GalaxyConfig config, Dictionary<string, RaceInfo> races)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<color=cyan><b>=== ОТЧЕТ О ГЕНЕРАЦИИ ГАЛАКТИКИ ===</b></color>");
        sb.AppendLine($"<color=white>Seed: {seed} | Секторов: {galaxy.Constellations.Count} | Звезд: {galaxy.StarsMap.Count}</color>");
        sb.AppendLine(new string('-', 50));

        foreach (var c in galaxy.Constellations.OrderBy(x => x.Name))
            AppendConstellationBlock(sb, c, races);

        string log = sb.ToString();
        PrintToConsole(log);
        SaveLogToFile(log, seed);
    }

    private static void AppendConstellationBlock(StringBuilder sb, ConstellationData c, Dictionary<string, RaceInfo> races)
    {
        string owner = string.IsNullOrEmpty(c.Owner) ? GalaxyConstants.LOG_NEUTRAL_OWNER_LABEL : c.Owner;
        sb.AppendLine($"\n<color=yellow>Сектор: {GetColoredName(c.Name, c.Owner, races)}</color> (Владелец: {owner})");

        foreach (var star in c.Stars.OrderBy(x => x.Name))
        {
            string starOwner = string.IsNullOrEmpty(star.FactionId) ? GalaxyConstants.LOG_NEUTRAL_OWNER_LABEL : star.FactionId;
            // Используем предвычисленное цветное имя из StarData.NameRenderData.
            string starNameColored = star.NameRenderData?.ToRichText() ?? star.Name;

            sb.AppendLine($"  <color=white>[Звезда]</color> {starNameColored} " +
                          $"(Тип: {star.Type}, Цвет: {star.Color}, Var: {star.GraphVar}, Фракция: {starOwner})" +
                          FormatProperties(star.CustomProperties));

            foreach (var planet in star.Planets.OrderBy(x => x.OrbitIndex))
            {
                string planetNameColored = GetColoredPlanetName(planet, races);

                sb.AppendLine($"    <color=silver>></color> Планета: {planetNameColored} " +
                              $"(Орбита: {planet.OrbitIndex}, Радиус: {planet.OrbitRadius:F2}, " +
                              $"Размер: {planet.Size}, Раса: {planet.Race}, Фракция: {planet.FactionId})" +
                              FormatProperties(planet.CustomProperties));
            }
        }
    }

    private static string GetColoredPlanetName(PlanetData planet, Dictionary<string, RaceInfo> races)
    {
        string color;
        if (planet.Race == GalaxyConstants.RACE_NONE_KEY || string.IsNullOrEmpty(planet.Race))
            color = GalaxyConstants.LOG_FALLBACK_STAR_COLOR; // нет расы → приглушённый цвет
        else
            color = races.TryGetValue(planet.Race, out var info) ? info.Color : GalaxyConstants.DEFAULT_COLOR;

        return $"<b><color={color}>{planet.Name}</color></b>";
    }

    private static string FormatProperties(Dictionary<string, string> props)
    {
        if (props == null || props.Count == 0) return string.Empty;
        return " | Свойства: " + string.Join(", ", props.Select(kv => $"{kv.Key}={kv.Value}"));
    }

    private static void PrintToConsole(string log)
    {
        for (int i = 0; i < log.Length; i += MaxConsoleChunk)
            Debug.Log(log.Substring(i, Math.Min(MaxConsoleChunk, log.Length - i)));
    }

    private static void SaveLogToFile(string content, int seed)
    {
        try
        {
            if (!Directory.Exists(LogDirectory)) Directory.CreateDirectory(LogDirectory);

            string clean = RichTagRegex.Replace(content, string.Empty);
            string fileName = $"GalaxyLog_Seed_{seed}_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.txt";
            File.WriteAllText(Path.Combine(LogDirectory, fileName), clean);
            Debug.Log($"<color=green>Лог сохранён: {fileName}</color>");
        }
        catch (Exception e)
        {
            Debug.LogError($"[GalaxyLogger] Не удалось сохранить лог: {e.Message}");
        }
    }

    public static string GetColoredStarName(StarData star, Dictionary<string, RaceInfo> races)
    {
        if (string.IsNullOrEmpty(star.Name)) return $"{GalaxyConstants.VAL_UNKNOWN} Star";

        // Считаем количество заселённых планет по расам без LINQ-аллокаций.
        var groupCounts = new Dictionary<string, int>();
        int settledCount = 0;
        foreach (var p in star.Planets)
        {
            if (p.Race == GalaxyConstants.RACE_NONE_KEY) continue;
            groupCounts.TryGetValue(p.Race, out int cur);
            groupCounts[p.Race] = cur + 1;
            settledCount++;
        }

        if (groupCounts.Count == 0)
        {
            string fallbackColor = races.TryGetValue(GalaxyConstants.RACE_NONE_KEY, out var rNone)
                ? rNone.Color : GalaxyConstants.LOG_FALLBACK_STAR_COLOR;
            return $"<color={fallbackColor}>{star.Name}</color>";
        }

        // Сортируем по убыванию count (без LINQ — ручная сортировка через List).
        var sorted = new List<KeyValuePair<string, int>>(groupCounts);
        sorted.Sort((a, b) => b.Value.CompareTo(a.Value));

        var sb = new StringBuilder(star.Name.Length * 2);
        int nameLength = star.Name.Length;
        int charIndex = 0;

        for (int i = 0; i < sorted.Count; i++)
        {
            var kv = sorted[i];
            int charCount = i == sorted.Count - 1
                ? nameLength - charIndex
                : Mathf.RoundToInt((float)kv.Value / settledCount * nameLength);

            charCount = Mathf.Clamp(charCount, 0, nameLength - charIndex);
            if (charCount <= 0) continue;

            string color = races.TryGetValue(kv.Key, out var info) ? info.Color : GalaxyConstants.DEFAULT_COLOR;
            sb.Append($"<color={color}>{star.Name.Substring(charIndex, charCount)}</color>");
            charIndex += charCount;
        }

        return sb.ToString();
    }

    private static string GetColoredName(string name, string owner, Dictionary<string, RaceInfo> races)
    {
        if (!string.IsNullOrEmpty(owner) && races.TryGetValue(owner, out var info))
            return $"<color={info.Color}>{name}</color>";
        return name;
    }
}
#endregion
#region GenerationHelpers

public static class GenerationHelpers
{
    // Perf-A: кеш имён ресурсов. Хранит только string[], не текстуры.
    // Заполняется при первом обращении, переиспользуется при последующих.
    private static readonly Dictionary<string, string[]> _resourceNameCache = new();

    private static string[] GetResourceNames(string path)
    {
        if (_resourceNameCache.TryGetValue(path, out var cached)) return cached;
        var textures = Resources.LoadAll<Texture2D>(path);
        var names = System.Array.ConvertAll(textures, t => t.name);
        _resourceNameCache[path] = names;
        return names;
    }

    // Вызвать при перезагрузке сцены/проекта если ресурсы меняются в рантайме.
    public static void ClearResourceCache() => _resourceNameCache.Clear();

    public static string GetRandomPlanetGraphic(string size)
    {
        string p1 = $"Graphics/Planets/Textures/{size}";
        var names1 = GetResourceNames(p1);
        if (names1.Length > 0) return $"{p1}/{names1[UnityEngine.Random.Range(0, names1.Length)]}";
        var names2 = GetResourceNames(GalaxyConstants.PATH_COMMON_TEXTURES);
        if (names2.Length > 0) return $"{GalaxyConstants.PATH_COMMON_TEXTURES}/{names2[UnityEngine.Random.Range(0, names2.Length)]}";
        return GalaxyConstants.PATH_PLANET_FALLBACK;
    }

    public static string GetRandomSatelliteGraphic()
    {
        var names1 = GetResourceNames(GalaxyConstants.PATH_SAT_TEXTURES);
        if (names1.Length > 0) return $"{GalaxyConstants.PATH_SAT_TEXTURES}/{names1[UnityEngine.Random.Range(0, names1.Length)]}";
        var names2 = GetResourceNames(GalaxyConstants.PATH_COMMON_TEXTURES);
        if (names2.Length > 0) return $"{GalaxyConstants.PATH_COMMON_TEXTURES}/{names2[UnityEngine.Random.Range(0, names2.Length)]}";
        return GalaxyConstants.PATH_SATELLITE_FALLBACK;
    }

    public static string GetRandomOrbitalPath()
    {
        var names = GetResourceNames(GalaxyConstants.PATH_ORBITAL);
        return names.Length > 0 ? $"{GalaxyConstants.PATH_ORBITAL}/{names[UnityEngine.Random.Range(0, names.Length)]}" : null;
    }

    public static string BuildStarMapIcon(string color, int variant)
    {
        string basePath = $"Graphics/Stars/{color}";
        string variantPath = $"{basePath}/Var{variant}_minimap";
        return Resources.Load(variantPath) != null ? variantPath : $"{basePath}/minimap";
    }

    public static void ApplyWeightedStarColor(StarData star, GalaxyConfig config)
    {
        var colors = config.Stars.Colors;
        if (colors == null || colors.Count == 0)
        {
            star.Color = GalaxyConstants.FALLBACK_STAR_COLOR;
            star.GraphVar = 1;
            return;
        }

        int total = colors.Values.Sum(d => d?.VariantsCount ?? 1);
        int roll = UnityEngine.Random.Range(0, total), sum = 0;

        foreach (var (key, data) in colors)
        {
            sum += data?.VariantsCount ?? 1;
            if (roll >= sum) continue;
            star.Color = key;
            star.GraphVar = UnityEngine.Random.Range(1, (data?.VariantsCount ?? 1) + 1);
            return;
        }
    }

    public static int GetRandomColorVariant(string color, GalaxyConfig config)
    {
        var colors = config.Stars?.Colors;
        if (colors != null && colors.TryGetValue(color, out var d) && d != null)
            return UnityEngine.Random.Range(1, Mathf.Max(1, d.VariantsCount) + 1);
        return 1;
    }

    public static string GenerateAtmosphere(string size, Dictionary<string, PlanetSizeData> sizeRules)
    {
        if (string.IsNullOrEmpty(size)) return null;
        if (sizeRules.TryGetValue(size, out var rule))
            return UnityEngine.Random.Range(0, 100) < rule.AtmosphereChance
                ? $"{GalaxyConstants.PATH_CLOUDS}/{UnityEngine.Random.Range(1, GalaxyConstants.CLOUD_VARIANTS_COUNT + 1)}" : null;
        Debug.LogWarning($"[GenerationHelpers] Planet size '{size}' not found in PlanetSizeRules — no atmosphere generated.");
        return null;
    }

    public static float GetPlanetRadiusInPixels(string size, Dictionary<string, PlanetSizeData> sizeRules)
    {
        return sizeRules.TryGetValue(size, out var rule) && rule.PixelRadius > 0
            ? rule.PixelRadius : GalaxyConstants.FALLBACK_PLANET_RADIUS;
    }

    public static int CalculateSatelliteCount(string size, Dictionary<string, PlanetSizeData> sizeRules)
    {
        if (string.IsNullOrEmpty(size)) return 0;
        if (sizeRules.TryGetValue(size, out var rule))
            return rule.MaxSatellites > 0 ? UnityEngine.Random.Range(0, rule.MaxSatellites + 1) : 0;
        Debug.LogWarning($"[GenerationHelpers] Planet size '{size}' not found in PlanetSizeRules — 0 satellites.");
        return 0;
    }

    public static int CalculateSystemSize(List<PlanetData> planets, int systemSizeMult)
    {
        if (planets == null || planets.Count == 0) return (int)(GalaxyConstants.SYSTEM_PADDING * systemSizeMult);
        float maxExtent = 0f;
        foreach (var p in planets)
        {
            float e = Mathf.Clamp(p.OrbitEccentricity, 0f, 0.99f);
            float apocenter = p.OrbitRadius * (1f + e);
            if (apocenter > maxExtent) maxExtent = apocenter;
        }
        return Mathf.RoundToInt(maxExtent + GalaxyConstants.SYSTEM_PADDING * systemSizeMult);
    }

    public static string GetMaskPath(string size) => GalaxyConstants.PATH_PLANET_MASK;

    public static string CleanResourcePath(string path)
    {
        if (string.IsNullOrEmpty(path)) return null;
        return path.Replace(".png", "").Replace(".jpg", "");
    }

    public static string PopRandomUnused(List<string> pool, HashSet<string> used)
    {
        int count = pool.Count;
        while (count > 0)
        {
            int idx = UnityEngine.Random.Range(0, count);
            string candidate = pool[idx];
            pool[idx] = pool[count - 1];
            pool.RemoveAt(count - 1);
            count--;
            if (used.Add(candidate)) return candidate;
        }
        return null;
    }

    public static string GetRaceColor(string key, Dictionary<string, RaceInfo> races) =>
        races.TryGetValue(key, out var race) ? race.Color : GalaxyConstants.DEFAULT_COLOR;
}

#endregion

[System.Serializable]
public class StarNameSegment
{
    public string Text;
    public Color Color;

    public StarNameSegment(string text, Color color) { Text = text; Color = color; }
}

[System.Serializable]
public class StarNameRenderData
{
    public List<StarNameSegment> Segments = new();
    public bool HasIcon;
    public string IconPath; // путь к спрайту расы/фракции (null = нет)

    // Собирает plain-string с rich-text тегами Unity (для TextMesh / лога).
    // Формат: <color=#RRGGBB>text</color>
    public string ToRichText()
    {
        if (Segments == null || Segments.Count == 0) return string.Empty;
        var sb = new System.Text.StringBuilder();
        foreach (var seg in Segments)
            sb.Append($"<color=#{ColorUtility.ToHtmlStringRGB(seg.Color)}>{seg.Text}</color>");
        return sb.ToString();
    }

    // Собирает plain-текст без тегов (для поиска, сохранений).
    public string ToPlainText()
    {
        if (Segments == null || Segments.Count == 0) return string.Empty;
        var sb = new System.Text.StringBuilder();
        foreach (var seg in Segments) sb.Append(seg.Text);
        return sb.ToString();
    }
}

public static class OwnershipDisplayResolver
{
    // ── PARSE ─────────────────────────────────────────────────────────────────

    /// <summary>Парсит "R,G,B" (0–255) → Color. Возвращает fallback при ошибке.</summary>
    public static Color ParseRgbString(string rgb, Color fallback)
    {
        if (string.IsNullOrEmpty(rgb)) return fallback;
        var parts = rgb.Split(',');
        if (parts.Length < 3) return fallback;
        if (float.TryParse(parts[0].Trim(), out float r) &&
            float.TryParse(parts[1].Trim(), out float g) &&
            float.TryParse(parts[2].Trim(), out float b))
            return new Color(r / 255f, g / 255f, b / 255f);
        return fallback;
    }

    // ── MINIMAP: SHIPS ────────────────────────────────────────────────────────

    /// <summary>
    /// Цвет иконки NPC-корабля на миникарте.
    /// Приоритет: ConflictSide.Color → Faction.Color → Race.Color → DefaultMinimapColor
    /// </summary>
    public static Color ResolveShipMinimapColor(ShipData ship, GalaxyGenerationContext ctx)
    {
        Color fallback = GetDefaultMinimapColor(ctx);
        if (ship == null || ctx?.Config?.Ships == null) return fallback;
        var ships = ctx.Config.Ships;

        // 1. Цвет стороны
        string sideId = FactionRelationsManager.Instance?.GetSide(ship.FactionId);
        if (TryGetSideColor(sideId, ships, fallback, out Color sideColor))
            return sideColor;

        // 2. Цвет фракции
        if (TryGetFactionColor(ship.FactionId, ships, fallback, out Color factionColor))
            return factionColor;

        // 3. Цвет расы фракции
        string raceId = GetRaceForFaction(ship.FactionId, ships);
        if (TryGetRaceColor(raceId, ctx, fallback, out Color raceColor))
            return raceColor;

        return fallback;
    }

    // ── MINIMAP: PLANETS ──────────────────────────────────────────────────────

    /// <summary>
    /// Цвет иконки планеты на миникарте.
    /// Приоритет: Race.Color → Side(owner).Color → Faction(owner).Color → DefaultMinimapColor
    /// </summary>
    public static Color ResolvePlanetMinimapColor(PlanetData planet, GalaxyGenerationContext ctx)
    {
        Color fallback = GetDefaultMinimapColor(ctx);
        if (planet == null || ctx?.Config == null) return fallback;

        // 1. Цвет расы населения
        if (TryGetRaceColor(planet.Race, ctx, fallback, out Color raceColor))
            return raceColor;

        var ships = ctx.Config.Ships;
        if (ships == null) return fallback;

        // 2. Цвет стороны владельца
        string sideId = FactionRelationsManager.Instance?.GetSide(planet.FactionId);
        if (TryGetSideColor(sideId, ships, fallback, out Color sideColor))
            return sideColor;

        // 3. Цвет фракции владельца
        if (TryGetFactionColor(planet.FactionId, ships, fallback, out Color factionColor))
            return factionColor;

        return fallback;
    }

    // ── STAR NAME ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Строит StarNameRenderData для звезды по StarNameStyle её стороны.
    /// Результат сохраняется в StarData.NameRenderData при генерации.
    /// </summary>
    public static StarNameRenderData ResolveStarName(StarData star, GalaxyGenerationContext ctx)
    {
        var result = new StarNameRenderData();
        if (star == null || ctx?.Config?.Ships == null) return result;

        string name = star.Name ?? string.Empty;
        if (name.Length == 0) return result;

        Color defaultColor = GetDefaultStarNameColor(ctx);
        var ships = ctx.Config.Ships;

        // Получаем сторону владельца
        string sideId = FactionRelationsManager.Instance?.GetSide(star.FactionId);
        ConflictSideConfig sideCfg = null;
        ships.ConflictSides?.TryGetValue(sideId ?? string.Empty, out sideCfg);

        // Парсим StarNameStyle
        StarNameStyle style = StarNameStyle.RaceGradient; // дефолт
        if (sideCfg != null && !string.IsNullOrEmpty(sideCfg.StarNameStyle))
            System.Enum.TryParse(sideCfg.StarNameStyle, out style);

        // Резолвим цвет стороны (с fallback-цепочкой)
        Color sideColor = ResolveSideDisplayColor(sideId, star.FactionId, ships, ctx, defaultColor);

        switch (style)
        {
            // ── 1. SolidSide — весь текст в цвете стороны ─────────────────────
            case StarNameStyle.SolidSide:
                result.Segments.Add(new StarNameSegment(name, sideColor));
                break;

            // ── 2. SideWithFactionAccent — первая буква в цвете фракции ───────
            case StarNameStyle.SideWithFactionAccent:
                {
                    Color factionColor = sideColor;
                    TryGetFactionColor(star.FactionId, ships, sideColor, out factionColor);
                    result.Segments.Add(new StarNameSegment(name.Substring(0, 1), factionColor));
                    if (name.Length > 1)
                        result.Segments.Add(new StarNameSegment(name.Substring(1), sideColor));
                    break;
                }

            // ── 3. SideWithFactionIcon — цвет стороны + значок фракции ────────
            case StarNameStyle.SideWithFactionIcon:
                {
                    result.Segments.Add(new StarNameSegment(name, sideColor));
                    string factionIcon = GetFactionIconPath(star.FactionId, ships);
                    result.HasIcon = true;
                    result.IconPath = factionIcon;
                    break;
                }

            // ── 4. FactionSolid — цвет фракции (fallback: цвет стороны) ───────
            case StarNameStyle.FactionSolid:
                {
                    Color factionColor = sideColor;
                    TryGetFactionColor(star.FactionId, ships, sideColor, out factionColor);
                    result.Segments.Add(new StarNameSegment(name, factionColor));
                    break;
                }

            // ── 5. RaceGradient — N сегментов по расам системы ────────────────
            case StarNameStyle.RaceGradient:
                BuildRaceGradientSegments(result, name, star, ctx, defaultColor);
                break;

            // ── 6. RaceGradientWithIcon — то же + значок фракции ──────────────
            case StarNameStyle.RaceGradientWithIcon:
                BuildRaceGradientSegments(result, name, star, ctx, defaultColor);
                result.HasIcon = true;
                result.IconPath = GetFactionIconPath(star.FactionId, ships);
                break;

            // ── 7. SideWithRaceIcon — цвет стороны + значок расы системы ──────
            case StarNameStyle.SideWithRaceIcon:
                {
                    result.Segments.Add(new StarNameSegment(name, sideColor));
                    result.HasIcon = true;
                    result.IconPath = GetDominantRaceIconPath(star, ships, ctx);
                    break;
                }

            default:
                result.Segments.Add(new StarNameSegment(name, defaultColor));
                break;
        }

        // Гарантируем хотя бы один сегмент
        if (result.Segments.Count == 0)
            result.Segments.Add(new StarNameSegment(name, defaultColor));

        return result;
    }

    // ── PRIVATE HELPERS ───────────────────────────────────────────────────────

    private static Color GetDefaultMinimapColor(GalaxyGenerationContext ctx)
    {
        var settings = GetSettings();
        return ParseRgbString(settings?.DefaultMinimapColor, Color.white);
    }

    private static Color GetDefaultStarNameColor(GalaxyGenerationContext ctx)
    {
        var settings = GetSettings();
        return ParseRgbString(settings?.DefaultStarNameColor, new Color(0.78f, 0.78f, 0.78f));
    }

    private static GameSettingsConfig GetSettings()
    {
        // GalaxyManager хранит настройки как SerializedField — достаём через публичное свойство
        return GalaxyManager.Instance?.Settings;
    }

    private static bool TryGetSideColor(string sideId, ShipConfigSection ships,
        Color fallback, out Color color)
    {
        color = fallback;
        if (string.IsNullOrEmpty(sideId) || ships.ConflictSides == null) return false;
        if (!ships.ConflictSides.TryGetValue(sideId, out var cfg)) return false;
        if (string.IsNullOrEmpty(cfg.Color)) return false;
        color = ParseRgbString(cfg.Color, fallback);
        return true;
    }

    private static bool TryGetFactionColor(string factionId, ShipConfigSection ships,
        Color fallback, out Color color)
    {
        color = fallback;
        if (string.IsNullOrEmpty(factionId) || ships.Factions == null) return false;
        if (!ships.Factions.TryGetValue(factionId, out var cfg)) return false;
        if (string.IsNullOrEmpty(cfg.Color)) return false;
        color = ParseRgbString(cfg.Color, fallback);
        return true;
    }

    private static bool TryGetRaceColor(string raceId, GalaxyGenerationContext ctx,
        Color fallback, out Color color)
    {
        color = fallback;
        if (string.IsNullOrEmpty(raceId)
            || raceId == GalaxyConstants.RACE_NONE_KEY
            || ctx.Config?.Races == null) return false;
        if (!ctx.Config.Races.TryGetValue(raceId, out var cfg)) return false;
        if (string.IsNullOrEmpty(cfg.Color)) return false;
        color = ParseRgbString(cfg.Color, fallback);
        return true;
    }

    /// <summary>
    /// Резолвит "цвет стороны" с fallback-цепочкой:
    /// Side.Color → Faction.Color → Race.Color → defaultColor
    /// </summary>
    private static Color ResolveSideDisplayColor(string sideId, string factionId,
        ShipConfigSection ships, GalaxyGenerationContext ctx, Color defaultColor)
    {
        // 1. Цвет стороны
        if (TryGetSideColor(sideId, ships, defaultColor, out Color sideColor))
            return sideColor;

        // 2. Цвет фракции
        if (TryGetFactionColor(factionId, ships, defaultColor, out Color factionColor))
            return factionColor;

        // 3. Цвет расы фракции
        string raceId = GetRaceForFaction(factionId, ships);
        if (TryGetRaceColor(raceId, ctx, defaultColor, out Color raceColor))
            return raceColor;

        return defaultColor;
    }

    private static string GetRaceForFaction(string factionId, ShipConfigSection ships)
    {
        if (string.IsNullOrEmpty(factionId) || ships?.Factions == null) return null;
        return ships.Factions.TryGetValue(factionId, out var cfg) ? cfg.RaceId : null;
    }

    private static string GetFactionIconPath(string factionId, ShipConfigSection ships)
    {
        if (string.IsNullOrEmpty(factionId) || ships?.Factions == null) return null;
        return ships.Factions.TryGetValue(factionId, out var cfg) ? cfg.EmblemPath : null;
    }

    private static string GetDominantRaceIconPath(StarData star, ShipConfigSection ships,
        GalaxyGenerationContext ctx)
    {
        // Собираем уникальные расы планет системы
        string dominantRace = null;
        int maxCount = 0;
        var counts = new Dictionary<string, int>();
        foreach (var planet in star.Planets)
        {
            if (string.IsNullOrEmpty(planet.Race) || planet.Race == GalaxyConstants.RACE_NONE_KEY) continue;
            counts.TryGetValue(planet.Race, out int cur);
            int next = cur + 1;
            counts[planet.Race] = next;
            if (next > maxCount) { maxCount = next; dominantRace = planet.Race; }
        }

        if (string.IsNullOrEmpty(dominantRace) || ctx.Config?.Races == null) return null;
        return ctx.Config.Races.TryGetValue(dominantRace, out var raceCfg) ? raceCfg.EmblemPath : null;
    }

    private static void BuildRaceGradientSegments(StarNameRenderData result, string name,
        StarData star, GalaxyGenerationContext ctx, Color defaultColor)
    {
        // Собираем уникальные расы в порядке первого появления
        var orderedRaces = new List<string>();
        var seen = new HashSet<string>();
        foreach (var planet in star.Planets)
        {
            if (string.IsNullOrEmpty(planet.Race) || planet.Race == GalaxyConstants.RACE_NONE_KEY) continue;
            if (seen.Add(planet.Race)) orderedRaces.Add(planet.Race);
        }

        if (orderedRaces.Count == 0)
        {
            result.Segments.Add(new StarNameSegment(name, defaultColor));
            return;
        }

        int n = orderedRaces.Count;
        int nameLen = name.Length;
        int charIndex = 0;

        for (int i = 0; i < n; i++)
        {
            int charCount = i == n - 1
                ? nameLen - charIndex
                : Mathf.RoundToInt((float)(i + 1) / n * nameLen) - charIndex;

            charCount = Mathf.Clamp(charCount, 0, nameLen - charIndex);
            if (charCount <= 0) continue;

            Color raceColor = defaultColor;
            TryGetRaceColor(orderedRaces[i], ctx, defaultColor, out raceColor);

            result.Segments.Add(new StarNameSegment(name.Substring(charIndex, charCount), raceColor));
            charIndex += charCount;
        }
    }
}

public class StarLabelRenderer : MonoBehaviour
{
    [Header("Label Settings")]
    [SerializeField] private int fontSize = 14;
    [SerializeField] private float characterSize = 0.1f;
    [SerializeField] private Vector3 labelOffset = new Vector3(0f, -0.8f, 0f); // смещение под звездой
    [SerializeField] private string sortingLayerName = "Default";
    [SerializeField] private int sortingOrder = 50;

    [Header("Icon Settings")]
    [SerializeField] private float iconSize = 0.3f;       // размер значка в мировых единицах
    [SerializeField] private Vector3 iconOffset = new Vector3(0.4f, 0f, 0f); // смещение от конца текста

    private readonly List<GameObject> _segmentObjects = new();
    private GameObject _iconObject;

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Отображает название звезды по данным StarData.NameRenderData.
    /// Если NameRenderData не задан — рендерит имя белым цветом.
    /// </summary>
    public void Setup(StarData star)
    {
        Clear();
        if (star == null) return;

        var renderData = star.NameRenderData;

        // Fallback: нет данных → показываем имя белым
        if (renderData == null || renderData.Segments == null || renderData.Segments.Count == 0)
        {
            RenderFallback(star.Name ?? string.Empty);
            return;
        }

        RenderSegments(renderData);

        if (renderData.HasIcon && !string.IsNullOrEmpty(renderData.IconPath))
            RenderIcon(renderData.IconPath, renderData.Segments.Count);
    }

    /// <summary>Принудительно обновляет рендер (например, после смены владельца системы).</summary>
    public void Refresh(StarData star) => Setup(star);

    /// <summary>Удаляет все дочерние объекты лейбла.</summary>
    public void Clear()
    {
        foreach (var obj in _segmentObjects)
            if (obj != null) Destroy(obj);
        _segmentObjects.Clear();

        if (_iconObject != null) { Destroy(_iconObject); _iconObject = null; }
    }

    // ── RENDERING ─────────────────────────────────────────────────────────────

    private void RenderFallback(string name)
    {
        var obj = CreateSegmentObject("Label_Fallback", 0f);
        var mesh = obj.GetComponent<TextMesh>();
        mesh.text = name;
        mesh.color = Color.white;
        _segmentObjects.Add(obj);
    }

    private void RenderSegments(StarNameRenderData data)
    {
        // Для корректного горизонтального выравнивания вычисляем суммарную ширину заранее.
        // Приближённый расчёт: каждый символ занимает characterSize единиц.
        // Точный расчёт возможен только после создания меша — для TextMesh это нормальная аппроксимация.
        float totalWidth = 0f;
        foreach (var seg in data.Segments)
            totalWidth += (seg.Text?.Length ?? 0) * characterSize * fontSize * 0.1f;

        float currentX = -totalWidth * 0.5f; // центрируем относительно звезды

        for (int i = 0; i < data.Segments.Count; i++)
        {
            var seg = data.Segments[i];
            if (string.IsNullOrEmpty(seg.Text)) continue;

            var obj = CreateSegmentObject($"Label_Seg{i}", currentX);
            var mesh = obj.GetComponent<TextMesh>();
            mesh.text = seg.Text;
            mesh.color = seg.Color;
            mesh.anchor = TextAnchor.MiddleLeft; // выравниваем по левому краю для стыковки

            float segWidth = seg.Text.Length * characterSize * fontSize * 0.1f;
            currentX += segWidth;

            _segmentObjects.Add(obj);
        }
    }

    private void RenderIcon(string iconPath, int segmentCount)
    {
        // Вычисляем позицию иконки — правее последнего сегмента
        float totalWidth = 0f;
        foreach (var obj in _segmentObjects)
        {
            var mesh = obj.GetComponent<TextMesh>();
            if (mesh != null) totalWidth += (mesh.text?.Length ?? 0) * characterSize * fontSize * 0.1f;
        }

        var iconObj = new GameObject("Label_Icon");
        iconObj.transform.SetParent(transform, false);
        iconObj.transform.localPosition = labelOffset
            + new Vector3(totalWidth * 0.5f + iconOffset.x, iconOffset.y, iconOffset.z);

        var sr = iconObj.AddComponent<SpriteRenderer>();
        var sprite = Resources.Load<Sprite>(iconPath);
        if (sprite != null)
        {
            sr.sprite = sprite;
            sr.sortingLayerName = sortingLayerName;
            sr.sortingOrder = sortingOrder;
            iconObj.transform.localScale = Vector3.one * iconSize;
        }
        else
        {
            // Иконка не найдена — скрываем объект чтобы не занимал место
            iconObj.SetActive(false);
        }

        _iconObject = iconObj;
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private GameObject CreateSegmentObject(string name, float localX)
    {
        var obj = new GameObject(name);
        obj.transform.SetParent(transform, false);
        obj.transform.localPosition = labelOffset + new Vector3(localX, 0f, 0f);

        var mesh = obj.AddComponent<TextMesh>();
        mesh.fontSize = fontSize;
        mesh.characterSize = characterSize;
        mesh.anchor = TextAnchor.MiddleCenter;
        mesh.alignment = TextAlignment.Center;

        var mr = obj.GetComponent<MeshRenderer>();
        mr.sortingLayerName = sortingLayerName;
        mr.sortingOrder = sortingOrder;

        return obj;
    }

    private void OnDestroy() => Clear();
}

public class FactionRelationsManager : MonoBehaviour
{
    public static FactionRelationsManager Instance { get; private set; }

    // ── ВНУТРЕННИЕ ДАННЫЕ ─────────────────────────────────────────────────────

    // FactionId → ConflictSideId
    private readonly Dictionary<string, string> _factionToSide = new();

    // ConflictSideId → DefaultInternalRelation
    private readonly Dictionary<string, int> _sideInternalRelation = new();

    // "SideA-SideB" → int (нормализованный: меньший ключ всегда первый)
    private readonly Dictionary<string, int> _sideRelations = new();

    // "FactionA-FactionB" → int (нормализованный: меньший ключ всегда первый)
    private readonly Dictionary<string, int> _factionRelations = new();

    private bool _initialized = false;

    // ── UNITY LIFECYCLE ───────────────────────────────────────────────────────

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // ── ИНИЦИАЛИЗАЦИЯ ─────────────────────────────────────────────────────────

    /// <summary>
    /// Строит все три словаря из конфига.
    /// Вызывается из GalaxyManager.EnsureContextInitialized().
    /// </summary>
    public void Initialize(ShipConfigSection cfg)
    {
        _factionToSide.Clear();
        _sideInternalRelation.Clear();
        _sideRelations.Clear();
        _factionRelations.Clear();

        if (cfg == null)
        {
            Debug.LogWarning("[FactionRelationsManager] ShipConfigSection is null — инициализация пропущена.");
            return;
        }

        // 1. ConflictSides → DefaultInternalRelation
        int sidesCount = 0;
        if (cfg.ConflictSides != null)
            foreach (var (sideId, sideCfg) in cfg.ConflictSides)
            {
                _sideInternalRelation[sideId] = sideCfg.DefaultInternalRelation;
                sidesCount++;
            }

        // 2. Factions → _factionToSide
        int factionsCount = 0;
        if (cfg.Factions != null)
            foreach (var (factionId, factionCfg) in cfg.Factions)
            {
                if (!string.IsNullOrEmpty(factionCfg.ConflictSideId))
                    _factionToSide[factionId] = factionCfg.ConflictSideId;
                factionsCount++;
            }

        // 3. SideRelations
        int sideRelCount = 0;
        if (cfg.SideRelations != null)
            foreach (var (key, value) in cfg.SideRelations)
            {
                string normalizedKey = NormalizeKey(key);
                _sideRelations[normalizedKey] = value;
                sideRelCount++;
            }

        // 4. FactionRelations (явные переопределения)
        int factionRelCount = 0;
        if (cfg.FactionRelations != null)
            foreach (var (key, value) in cfg.FactionRelations)
            {
                string normalizedKey = NormalizeKey(key);
                _factionRelations[normalizedKey] = value;
                factionRelCount++;
            }

        _initialized = true;

        Debug.Log($"[FactionRelationsManager] Инициализировано: " +
                  $"{factionsCount} фракций, {sidesCount} сторон, " +
                  $"{sideRelCount} пар отношений, {factionRelCount} явных переопределений");
    }

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    /// <summary>Возвращает ConflictSideId для фракции. Null если фракция неизвестна.</summary>
    public string GetSide(string factionId)
    {
        if (string.IsNullOrEmpty(factionId)) return null;
        return _factionToSide.TryGetValue(factionId, out string side) ? side : null;
    }

    /// <summary>
    /// Резолвит отношение между двумя фракциями (0..100).
    /// 0 = враги, 100 = союзники.
    /// </summary>
    public int GetRelation(string factionA, string factionB)
    {
        if (!_initialized) return 0;
        if (string.IsNullOrEmpty(factionA) || string.IsNullOrEmpty(factionB)) return 0;

        // 1. Явное переопределение пары фракций
        string fKey = NormalizeKey(factionA, factionB);
        if (_factionRelations.TryGetValue(fKey, out int explicitRel))
            return explicitRel;

        string sideA = GetSide(factionA);
        string sideB = GetSide(factionB);

        // 2. Одна сторона → DefaultInternalRelation
        if (!string.IsNullOrEmpty(sideA) && sideA == sideB)
        {
            if (_sideInternalRelation.TryGetValue(sideA, out int internalRel))
                return internalRel;
            return 100; // внутри одной стороны — союзники по умолчанию
        }

        // 3. SideRelations между разными сторонами
        if (!string.IsNullOrEmpty(sideA) && !string.IsNullOrEmpty(sideB))
        {
            string sKey = NormalizeKey(sideA, sideB);
            if (_sideRelations.TryGetValue(sKey, out int sideRel))
                return sideRel;
        }

        // 4. Нет данных → враги
        return 0;
    }

    /// <summary>Враждебны ли две фракции (отношение &lt; 50).</summary>
    public bool AreHostile(string factionA, string factionB)
        => GetRelation(factionA, factionB) < 50;

    /// <summary>Переопределяет отношение между конкретной парой фракций.</summary>
    public void SetFactionRelation(string factionA, string factionB, int value)
    {
        string key = NormalizeKey(factionA, factionB);
        _factionRelations[key] = Mathf.Clamp(value, 0, 100);
    }

    /// <summary>Изменяет дефолтное отношение между двумя сторонами конфликта.</summary>
    public void SetSideRelation(string sideA, string sideB, int value)
    {
        string key = NormalizeKey(sideA, sideB);
        _sideRelations[key] = Mathf.Clamp(value, 0, 100);
    }

    // ── СОХРАНЕНИЕ / ЗАГРУЗКА ─────────────────────────────────────────────────

    /// <summary>
    /// Возвращает словарь только явных переопределений пар фракций для сохранения.
    /// SideRelations не сохраняются — восстанавливаются из конфига.
    /// </summary>
    public Dictionary<string, int> GetSaveData()
    {
        var result = new Dictionary<string, int>(_factionRelations);
        return result;
    }

    /// <summary>Загружает сохранённые явные переопределения пар фракций.</summary>
    public void LoadSaveData(Dictionary<string, int> data)
    {
        if (data == null) return;
        foreach (var (key, value) in data)
            _factionRelations[NormalizeKey(key)] = Mathf.Clamp(value, 0, 100);
    }

    // ── ВСПОМОГАТЕЛЬНЫЕ ───────────────────────────────────────────────────────

    /// <summary>
    /// Нормализует ключ "A-B": меньший по алфавиту всегда первый.
    /// Гарантирует, что ("DomA","DomB") и ("DomB","DomA") дают одинаковый ключ.
    /// </summary>
    private static string NormalizeKey(string a, string b)
        => string.CompareOrdinal(a, b) <= 0 ? $"{a}-{b}" : $"{b}-{a}";

    /// <summary>
    /// Нормализует уже готовый строковый ключ вида "A-B".
    /// Разбивает по первому дефису — остальная часть b может содержать дефисы.
    /// </summary>
    private static string NormalizeKey(string key)
    {
        if (string.IsNullOrEmpty(key)) return key;
        int dashIdx = key.IndexOf('-');
        if (dashIdx < 0) return key;
        string a = key.Substring(0, dashIdx);
        string b = key.Substring(dashIdx + 1);
        return NormalizeKey(a, b);
    }
}