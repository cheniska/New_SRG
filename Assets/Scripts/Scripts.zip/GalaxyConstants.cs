﻿using UnityEngine;

public static class GalaxyConstants
{
    // ── ЛОГИЧЕСКИЕ КЛЮЧИ (не меняются, используются в if/switch) ─────────────
    public const string RACE_NONE_KEY = "None";
    public const string RACE_COMMON_KEY = "Common";
    public const string RACE_UNRESOLVED_KEY = "Unresolved";
    public const string VAL_UNKNOWN = "Unknown";
    public const int ORBIT_FALLBACK = 99;

    // ── КОНФИГУРИРУЕМЫЕ КОНСТАНТЫ ─────────────────────────────────────────────
    // Геометрия галактики
    public static float CONSTELLATION_RADIUS = 5.0f;

    // Строковые fallback-значения
    public static string DEFAULT_COLOR = "white";
    public static string FALLBACK_STAR_COLOR = "White";
    public static string FALLBACK_SAT_SIZE = "Mid";
    public static string FALLBACK_EMBLEM_PATH = "Empty";
    public static string DEFAULT_GALAXY_KEY = "MilkyWay";

    // Пути к графике — fallback-файлы
    public static string PATH_PLANET_FALLBACK = "Graphics/Planets/Textures/Unic/Solar_Earth";
    public static string PATH_SATELLITE_FALLBACK = "Graphics/Planets/Textures/Common/Moon";
    public static string PATH_SAT_TEXTURES = "Graphics/Planets/Textures/Satellites";
    public static string PATH_COMMON_TEXTURES = "Graphics/Planets/Textures/Common";
    public static string PATH_ORBITAL = "Graphics/Planets/Orbital";
    public static string PATH_PLANET_MASK = "Graphics/Planets/Mask/160";
    public static string PATH_CLOUDS = "Graphics/Planets/Textures/Clouds";
    public static int CLOUD_VARIANTS_COUNT = 3;

    // Орбиты — радиусы и разрывы
    public static float MIN_ORBIT_RADIUS = 500f;
    public static float SYSTEM_PADDING = 400f;
    public static float ORBIT_GAP_MIN = 500f;
    public static float ORBIT_GAP_MAX = 700f;
    public static float FIRST_ORBIT_MIN = 600f;
    public static float FIRST_ORBIT_MAX = 1000f;

    // Планеты — скорости вращения и генерация
    public static float PLANET_ORBIT_SPEED_MIN = 50f;
    public static float PLANET_ORBIT_SPEED_MAX = 300f;
    public static int PLANET_DAY_SPEED_MIN = 20;
    public static int PLANET_DAY_SPEED_MAX = 60;
    public static float CLOUD_SPEED_FACTOR_MIN = 0.6f;
    public static float CLOUD_SPEED_FACTOR_MAX = 0.8f;
    public static float ORBITAL_OBJ_CHANCE = 0.3f;
    public static float NONE_ORBIT_MAX_FRACTION = 0.4f;
    public static int FALLBACK_MAX_PLANETS = 12;

    // Планеты — радиус для орбит спутников
    public static float FALLBACK_PLANET_RADIUS = 120f;

    // Спутники
    public static float SAT_ORBIT_BASE_OFFSET = 35f;
    public static float SAT_ORBIT_SPACING = 25f;
    public static float SAT_ORBIT_SPEED_MIN = 40f;
    public static float SAT_ORBIT_SPEED_MAX = 120f;
    public static int SAT_DAY_SPEED_MIN = 10;
    public static int SAT_DAY_SPEED_MAX = 39;
    public static float SAT_CLOUD_SPEED_FACTOR = 0.7f;

    // Астероиды
    public static int DEFAULT_MAX_ASTEROIDS = 2;
    public static float ASTEROID_GRAVITY_CONST = 500f;
    public static float ASTEROID_DAMPING_CONST = 10000f;
    public static string ASTEROID_SPRITES_PATH = "Graphics/Asteroids";
    /// <summary>
    /// Путь к спрайту иконки астероида на миникарте.
    /// По умолчанию — тот же спрайт что у планет и игрока.
    /// Можно переопределить в GameSettingsConfig.AsteroidMinimapIconPath.
    /// </summary>
    public static string ASTEROID_MINIMAP_ICON_PATH = "Graphics/Planets/Mask/minimap";

    // ── Взрыв астероида ───────────────────────────────────────────────────────
    // Все значения инициализируются из GameSettingsConfig в Initialize().

    /// <summary>Путь к папке со спрайтами взрыва (Resources). Папка с пронумерованными спрайтами.</summary>
    /// <summary>
    /// Путь к папке со спрайтами взрыва (Resources).
    /// Устанавливается из GameSettingsConfig.ExplosionSpritePath в Initialize().
    /// Не имеет захардкоженного дефолта — путь к графике принадлежит только конфигу.
    /// </summary>
    public static string EXPLOSION_SPRITE_PATH = string.Empty;
    public static float EXPLOSION_FPS = 12f;
    public static float EXPLOSION_SCALE = 1.5f;

    // ── Предметы на сцене (дроп из астероидов) ────────────────────────────────
    // Все значения инициализируются из GameSettingsConfig в Initialize().

    /// <summary>Время жизни дроп-объекта на сцене (секунд).</summary>
    public static float DROPPED_ITEM_LIFETIME = 30f;
    /// <summary>Базовый путь к папке спрайтов минералов: {path}/{ItemId}/Tier_{1..N}.png</summary>
    public static string MINERAL_SPRITES_PATH = "Graphics/Minerals";
    /// <summary>Количество визуальных тиров для минеральных спрайтов.</summary>
    public static int MINERAL_SPRITE_TIER_COUNT = 5;

    // Фон — параллакс-слои
    public static int BG_STAR_COUNT_FAR = 250;
    public static int BG_STAR_COUNT_MID = 150;
    public static int BG_STAR_COUNT_NEAR = 80;
    public static int BG_TEX_SIZE_FAR = 1024;
    public static int BG_TEX_SIZE_NEAR = 512;
    public static float BG_PARALLAX_FAR = 0.02f;
    public static float BG_PARALLAX_MID = 0.05f;
    public static float BG_PARALLAX_NEAR = 0.12f;
    public static float BG_LAYER_TILE_SIZE = 500f;

    // Фон — чёрный void
    public static float BG_VOID_SCALE_FACTOR = 2.5f;

    // Лог
    public static string LOG_FALLBACK_STAR_COLOR = "silver";
    public static string LOG_NEUTRAL_OWNER_LABEL = "Neutral";

    // ── ИНИЦИАЛИЗАЦИЯ ─────────────────────────────────────────────────────────
    // Вызывается один раз из GalaxyManager после загрузки GameSettingsConfig.
    // Все поля выше получают значения из конфига; при отсутствии конфига
    // продолжают использоваться встроенные дефолты.
    public static void Initialize(GameSettingsConfig cfg)
    {
        if (cfg == null) return;

        DEFAULT_GALAXY_KEY = cfg.DefaultGalaxyKey;
        CONSTELLATION_RADIUS = cfg.ConstellationRadius;

        FALLBACK_STAR_COLOR = cfg.FallbackStarColor;
        FALLBACK_SAT_SIZE = cfg.FallbackSatelliteSize;
        FALLBACK_EMBLEM_PATH = cfg.FallbackEmblemPath;

        PATH_PLANET_FALLBACK = cfg.FallbackPlanetTexture;
        PATH_SATELLITE_FALLBACK = cfg.FallbackSatelliteTexture;
        PATH_SAT_TEXTURES = cfg.SatelliteTexturesPath;
        PATH_COMMON_TEXTURES = cfg.CommonPlanetTexturesPath;
        PATH_ORBITAL = cfg.OrbitalObjectsPath;
        PATH_PLANET_MASK = cfg.PlanetMaskPath;
        PATH_CLOUDS = cfg.CloudTexturesPath;
        CLOUD_VARIANTS_COUNT = cfg.CloudTexturesCount;

        MIN_ORBIT_RADIUS = cfg.MinOrbitRadius;
        SYSTEM_PADDING = cfg.SystemPadding;
        ORBIT_GAP_MIN = cfg.OrbitGapMin;
        ORBIT_GAP_MAX = cfg.OrbitGapMax;
        FIRST_ORBIT_MIN = cfg.FirstOrbitRadiusMin;
        FIRST_ORBIT_MAX = cfg.FirstOrbitRadiusMax;

        PLANET_ORBIT_SPEED_MIN = cfg.PlanetOrbitSpeedMin;
        PLANET_ORBIT_SPEED_MAX = cfg.PlanetOrbitSpeedMax;
        PLANET_DAY_SPEED_MIN = cfg.PlanetDaySpeedMin;
        PLANET_DAY_SPEED_MAX = cfg.PlanetDaySpeedMax;
        CLOUD_SPEED_FACTOR_MIN = cfg.CloudSpeedFactorMin;
        CLOUD_SPEED_FACTOR_MAX = cfg.CloudSpeedFactorMax;
        ORBITAL_OBJ_CHANCE = cfg.OrbitalObjectChance;
        NONE_ORBIT_MAX_FRACTION = cfg.NoneOrbitMaxFraction;
        FALLBACK_MAX_PLANETS = cfg.FallbackMaxPlanetsPerStar;

        FALLBACK_PLANET_RADIUS = cfg.FallbackPlanetPixelRadius;

        SAT_ORBIT_BASE_OFFSET = cfg.SatelliteOrbitBaseOffset;
        SAT_ORBIT_SPACING = cfg.SatelliteOrbitSpacing;
        SAT_ORBIT_SPEED_MIN = cfg.SatelliteOrbitSpeedMin;
        SAT_ORBIT_SPEED_MAX = cfg.SatelliteOrbitSpeedMax;
        SAT_DAY_SPEED_MIN = cfg.SatelliteDaySpeedMin;
        SAT_DAY_SPEED_MAX = cfg.SatelliteDaySpeedMax;
        SAT_CLOUD_SPEED_FACTOR = cfg.SatelliteCloudSpeedFactor;

        DEFAULT_MAX_ASTEROIDS = cfg.DefaultMaxAsteroids;
        ASTEROID_SPRITES_PATH = cfg.AsteroidSpritesPath;
        ASTEROID_MINIMAP_ICON_PATH = cfg.AsteroidMinimapIconPath;
        // ASTEROID_GRAVITY_CONST и ASTEROID_DAMPING_CONST берутся из GalaxyConfig.Asteroids

        EXPLOSION_SPRITE_PATH = cfg.ExplosionSpritePath ?? string.Empty;
        if (cfg.ExplosionFPS > 0f) EXPLOSION_FPS = cfg.ExplosionFPS;
        if (cfg.ExplosionScale > 0f) EXPLOSION_SCALE = cfg.ExplosionScale;

        if (cfg.DroppedItemLifetime > 0f) DROPPED_ITEM_LIFETIME = cfg.DroppedItemLifetime;
        if (!string.IsNullOrEmpty(cfg.MineralSpritesPath)) MINERAL_SPRITES_PATH = cfg.MineralSpritesPath;
        if (cfg.MineralSpriteTierCount > 0) MINERAL_SPRITE_TIER_COUNT = cfg.MineralSpriteTierCount;

        BG_STAR_COUNT_FAR = cfg.BgStarCountFar;
        BG_STAR_COUNT_MID = cfg.BgStarCountMid;
        BG_STAR_COUNT_NEAR = cfg.BgStarCountNear;
        BG_TEX_SIZE_FAR = cfg.BgTexSizeFar;
        BG_TEX_SIZE_NEAR = cfg.BgTexSizeNear;
        BG_PARALLAX_FAR = cfg.BgParallaxFar;
        BG_PARALLAX_MID = cfg.BgParallaxMid;
        BG_PARALLAX_NEAR = cfg.BgParallaxNear;
        BG_LAYER_TILE_SIZE = cfg.BgLayerTileSize;

        BG_VOID_SCALE_FACTOR = cfg.BgVoidScaleFactor;

        LOG_FALLBACK_STAR_COLOR = cfg.LogFallbackStarColor;
        LOG_NEUTRAL_OWNER_LABEL = cfg.LogNeutralOwnerLabel;
    }

    /// <summary>
    /// Применяет переопределения из GalaxyConfig (вызывается после Initialize(GameSettingsConfig)).
    /// Секция GalaxyConfig.Explosion может уточнить FPS/Scale взрыва.
    /// Вызывается из GalaxyManager.EnsureContextInitialized() сразу после TryLoadConfigs().
    /// </summary>
    public static void InitializeFromGalaxyConfig(GalaxyConfig galaxyCfg)
    {
        if (galaxyCfg?.Explosion == null) return;
        var exp = galaxyCfg.Explosion;
        if (exp.FPS > 0f) EXPLOSION_FPS = exp.FPS;
        if (exp.Scale > 0f) EXPLOSION_SCALE = exp.Scale;
    }
}

