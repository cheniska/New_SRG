using System.Collections.Generic;
using Newtonsoft.Json;

// ── ITEMS CONFIG MODELS ───────────────────────────────────────────────────────
//
// Модели для десериализации ItemsConfig.json.
// Содержит не-оборудовательные предметы: минералы, мусор, квестовые предметы.
//
// Загружается через GalaxyConfigLoader, хранится в GalaxyGenerationContext.ItemsConfig.

public class ItemsConfig
{
    /// <summary>Минералы — стакаемые ресурсы добываемые из астероидов.</summary>
    [JsonProperty("Minerals")]
    public Dictionary<string, MineralConfig> Minerals { get; set; } = new();

    // ── HELPERS ───────────────────────────────────────────────────────────────

    public MineralConfig GetMineral(string mineralId) =>
        Minerals.TryGetValue(mineralId, out var m) ? m : null;
}

/// <summary>
/// Конфигурация одного типа минерала.
/// Stackable-предметы хранятся в ShipInventory.Stacks, не в Items.
/// TotalWeight стопки = количество единиц (каждая единица = 1 вес).
/// </summary>
public class MineralConfig
{
    [JsonProperty("Name")]
    public string Name { get; set; }

    /// <summary>Базовая цена за единицу веса.</summary>
    [JsonProperty("BasePrice")]
    public int BasePrice { get; set; }

    /// <summary>Может ли стаковаться в инвентаре.</summary>
    [JsonProperty("Stackable")]
    public bool Stackable { get; set; } = true;

    /// <summary>Минимальный вес одного дропа (единиц минерала).</summary>
    [JsonProperty("DropWeightMin")]
    public int DropWeightMin { get; set; } = 1;

    /// <summary>Максимальный вес одного дропа (единиц минерала).</summary>
    [JsonProperty("DropWeightMax")]
    public int DropWeightMax { get; set; } = 50;

    /// <summary>
    /// Базовый путь к папке со спрайтами (Resources).
    /// Конкретный спрайт выбирается по тиру: {SpritePath}/Tier_{1..N}
    /// где N = GalaxyConstants.MINERAL_SPRITE_TIER_COUNT.
    /// Если null — используется GalaxyConstants.MINERAL_SPRITES_PATH/{ItemId}.
    /// </summary>
    [JsonProperty("SpritePath")]
    public string SpritePath { get; set; }
}