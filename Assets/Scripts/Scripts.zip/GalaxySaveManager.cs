using UnityEngine;
using Newtonsoft.Json;
using System;
using System.IO;

public static class GalaxySaveManager
{
    private static string SavePath => Path.Combine(Application.persistentDataPath, "galaxy_save.json");

    private static readonly JsonSerializerSettings SaveSettings = new JsonSerializerSettings
    {
        ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
        TypeNameHandling = TypeNameHandling.Auto
    };

    public static void SaveGalaxy(GalaxyData data)
    {
        if (data == null)
        {
            Debug.LogWarning("[GalaxySaveManager] Nothing to save."); return;
        }

        string json = JsonConvert.SerializeObject(data, Formatting.Indented, SaveSettings);
        File.WriteAllText(SavePath, json);
        Debug.Log($"[GalaxySaveManager] Saved to: {SavePath}");
    }

    public static GalaxyData LoadGalaxy()
    {
        if (!File.Exists(SavePath))
        {
            Debug.LogError("[GalaxySaveManager] Save file not found.");
            return null;
        }

        try
        {
            var data = JsonConvert.DeserializeObject<GalaxyData>(File.ReadAllText(SavePath));
            data?.InitializeLookups();
            return data;
        }
        catch (Exception e)
        {
            Debug.LogError($"[GalaxySaveManager] Load failed: {e.Message}");
            return null;
        }
    }
}

