using System.Collections.Generic;
using UnityEngine;

// ── ASTEROID SYSTEM ───────────────────────────────────────────────────────────
//
// Статический класс. Вся игровая логика астероидов — генерация, физика, коллизии, дроп.
// Аналог EquipmentSystem по архитектуре.
//
// Вызывается из StarData.StarNextDay:
//   1. TrySpawnAsteroid   — перед циклом раундов, один раз за ход
//   2. TickAsteroids       — внутри цикла раундов (round = 1..TurnRounds)
//
// Физика (упрощённая реалистичная):
//   - Астероид входит в систему с границы (radius = SystemSize / 100)
//   - Каждый раунд ApplyGravity изменяет Velocity: притяжение к звезде
//     пропорционально 1/distance², умноженное на GravityConst
//   - Скорость нарастает при сближении со звездой, убывает при удалении
//   - Траектория получается параболической/гиперболической в зависимости от
//     начального импульса — визуально похоже на реальные транзитные тела

public static class AsteroidSystem
{
    // ── PUBLIC API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Пытается заспawnить новый астероид в системе.
    /// Вызывается один раз в начале хода только если в системе есть игрок.
    /// Спавн не происходит если астероидов уже MaxAsteroids.
    /// </summary>
    /// <summary>
    /// Пытается заспавнить новый астероид в системе.
    /// Вызывается один раз в начале хода только если в системе есть игрок.
    /// При успешном спавне добавляет AsteroidSpawnEvent в anim для визуала.
    /// </summary>
    public static void TrySpawnAsteroid(StarData star, GalaxyGenerationContext ctx,
        TurnAnimationData anim = null)
    {
        var cfg = ctx?.Config?.Asteroids;
        if (cfg == null) return;

        int maxAsteroids = ResolveMaxAsteroids(star);
        if (star.Asteroids.Count >= maxAsteroids) return;
        if (Random.value > cfg.SpawnChancePerTurn) return;

        string typeId = cfg.RollRandomTypeId();
        if (typeId == null || !cfg.Types.TryGetValue(typeId, out var typeCfg)) return;

        var asteroid = CreateAsteroid(typeId, typeCfg, star);
        star.Asteroids.Add(asteroid);

        anim?.AsteroidSpawns.Add(new AsteroidSpawnEvent { AsteroidUid = asteroid.Uid });

        Debug.Log($"[AsteroidSystem] Spawned '{typeCfg.Name}' in '{star.Name}' | " +
                  $"pos=({asteroid.Position.x:F1},{asteroid.Position.y:F1}) " +
                  $"vel=({asteroid.Velocity.x:F2},{asteroid.Velocity.y:F2}) " +
                  $"graphic='{asteroid.GraphicPath}' | " +
                  $"total: {star.Asteroids.Count}/{maxAsteroids}");
    }

    /// <summary>
    /// Тикает все астероиды системы за один раунд:
    ///   1. Сохраняет PreviousPosition
    ///   2. Применяет гравитацию звезды к Velocity
    ///   3. Двигает астероид на Velocity / TurnRounds
    ///   4. Проверяет коллизии
    ///   5. Проверяет выход за границу системы
    ///   6. Удаляет уничтоженные астероиды (в последнем раунде)
    /// </summary>
    public static void TickAsteroids(StarData star, int round,
        TurnAnimationData anim, GalaxyGenerationContext ctx)
    {
        if (star.Asteroids.Count == 0) return;

        var cfg = ctx?.Config?.Asteroids;
        float gravityConst = cfg?.GravityConst ?? GalaxyConstants.ASTEROID_GRAVITY_CONST;
        float systemRadius = star.SystemSize / 100f;

        for (int i = star.Asteroids.Count - 1; i >= 0; i--)
        {
            var asteroid = star.Asteroids[i];
            if (asteroid.IsDestroyed) continue;

            asteroid.PreviousPosition = asteroid.Position;

            ApplyGravity(asteroid, gravityConst);
            asteroid.Position += asteroid.Velocity / GalaxyData.TurnRounds;

            // Фиксируем позицию раунда для интерполяции визуала
            if (anim != null && anim.AsteroidFrames.TryGetValue(asteroid.Uid, out var frames))
                frames.Rounds[round] = asteroid.Position;

            // Коллизии
            if (!asteroid.IsDestroyed)
                CheckCollisions(asteroid, star, anim, ctx, round);

            // Уничтожаем при выходе за границу системы
            if (!asteroid.IsDestroyed && asteroid.Position.magnitude > systemRadius * 1.5f)
            {
                DestroyAsteroid(asteroid, anim,
                    new List<ItemInstance>(),
                    new List<ItemStack>(),
                    hitPlayer: false,
                    collisionType: AsteroidCollisionType.None,
                    round: round, tHit: 1f);
                Debug.Log($"[AsteroidSystem] Asteroid '{asteroid.Uid[..8]}' left system '{star.Name}'");
            }
        }

        if (round == GalaxyData.TurnRounds)
            star.Asteroids.RemoveAll(a => a.IsDestroyed);
    }

    // ── ФИЗИКА ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Применяет гравитационное притяжение звезды к вектору скорости астероида.
    /// Звезда находится в (0, 0) мировых координат системы.
    ///
    /// Формула: acceleration = GravityConst / distance² × направление к звезде
    /// За один раунд изменение скорости: ΔV = acceleration / TurnRounds
    ///
    /// При очень малой дистанции (астероид внутри звезды) — клампим чтобы не было NaN.
    /// </summary>
    private static void ApplyGravity(AsteroidData asteroid, float gravityConst)
    {
        Vector2 toStar = -asteroid.Position; // звезда в (0,0)
        float distSq = toStar.sqrMagnitude;

        // Минимальный порог: не позволяем делить на ~0
        const float minDistSq = 0.01f;
        if (distSq < minDistSq) return;

        float acceleration = gravityConst / distSq;
        Vector2 gravityDelta = toStar.normalized * acceleration / GalaxyData.TurnRounds;
        asteroid.Velocity += gravityDelta;
    }

    // ── КОЛЛИЗИИ ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Swept circle-vs-circle коллизия по отрезкам движения обоих объектов.
    ///
    /// Решает задачу в системе отсчёта objectA — вычитает движение objectB,
    /// что позволяет корректно обрабатывать случай когда оба объекта движутся.
    ///
    /// Возвращает (hit, t) где t ∈ [0..1] — момент первого касания.
    /// hit = false если пересечения нет или оба объекта уже перекрывались
    /// (t1 < 0 означает что они расходятся, считаем это не-коллизией).
    /// </summary>
    private static (bool hit, float t) SweptCircleHit(
        Vector2 aFrom, Vector2 aTo,
        Vector2 bFrom, Vector2 bTo,
        float combinedRadius)
    {
        // Относительное движение A относительно B
        Vector2 relFrom = aFrom - bFrom;
        Vector2 relVel = (aTo - aFrom) - (bTo - bFrom);

        float rSq = combinedRadius * combinedRadius;
        float a = Vector2.Dot(relVel, relVel);

        // Объекты не движутся друг относительно друга — статичная проверка
        if (a < 1e-10f)
        {
            bool inside = relFrom.sqrMagnitude <= rSq;
            return (inside, 0f);
        }

        float b = 2f * Vector2.Dot(relFrom, relVel);
        float c = Vector2.Dot(relFrom, relFrom) - rSq;
        float disc = b * b - 4f * a * c;

        if (disc < 0f) return (false, 0f); // нет пересечения

        float sqrtD = Mathf.Sqrt(disc);
        float t1 = (-b - sqrtD) / (2f * a); // момент первого касания
        float t2 = (-b + sqrtD) / (2f * a); // момент выхода

        // t2 < 0: оба объекта уже разошлись до начала шага
        if (t2 < 0f) return (false, 0f);
        // t1 > 1: пересечение произошло бы только после конца шага
        if (t1 > 1f) return (false, 0f);

        // Если t1 < 0 — объекты уже перекрывались в начале шага.
        // Считаем это коллизией только если они сближаются (b < 0),
        // иначе они расходятся и это старое перекрытие — игнорируем.
        if (t1 < 0f && b >= 0f) return (false, 0f);

        float tHit = Mathf.Max(0f, t1);
        return (true, tHit);
    }

    /// <summary>
    /// Возвращает мировую позицию планеты для заданного раунда (1..TurnRounds).
    /// Интерполирует угол между PreviousAngle и CurrentAngle по прогрессу раунда,
    /// чтобы коллизия проверялась в правильной точке орбиты, а не в финальной.
    /// </summary>
    private static Vector2 GetPlanetPositionAtRound(PlanetData planet, int round)
    {
        float t = (float)round / GalaxyData.TurnRounds;
        float angle = Mathf.LerpAngle(planet.PreviousAngle, planet.CurrentAngle, t);

        float a = planet.OrbitRadius / 100f;
        float e = Mathf.Clamp(planet.OrbitEccentricity, 0f, 0.99f);
        float b = a * Mathf.Sqrt(1f - e * e);
        float c = a * e;
        float rad = angle * Mathf.Deg2Rad;
        float tiltRad = planet.OrbitTiltDeg * Mathf.Deg2Rad;
        float lx = Mathf.Cos(rad) * a - c;
        float ly = Mathf.Sin(rad) * b;
        float cosT = Mathf.Cos(tiltRad), sinT = Mathf.Sin(tiltRad);
        return new Vector2(lx * cosT - ly * sinT, lx * sinT + ly * cosT);
    }

    /// <summary>
    /// Получает радиус коллизии корабля в мировых единицах из параметров корпуса.
    /// SizeSmall — размер корпуса в пикселях при PPU=100 → делим на 100 → мировые единицы.
    /// Fallback — 0.35 (примерно средний корабль).
    /// </summary>
    private static float GetShipCollisionRadius(ShipData ship)
    {
        var hull = EquipmentSystem.GetEquipped(ship, "Hull_0");
        if (hull != null)
        {
            float sizeSmall = hull.GetParam("SizeSmall", 0f);
            if (sizeSmall > 0f) return sizeSmall / 100f * 0.5f; // радиус = полразмера
        }
        return 0.35f;
    }

    /// <summary>
    /// Проверяет коллизии астероида за один раунд.
    /// Позиции корабля берутся из ShipFrames[round-1]/[round] — точные позиции за данный раунд.
    /// Передаёт round и tHit в обработчики столкновений для точного вычисления момента удара.
    /// </summary>
    private static void CheckCollisions(AsteroidData asteroid, StarData star,
        TurnAnimationData anim, GalaxyGenerationContext ctx, int round)
    {
        Vector2 aFrom = asteroid.PreviousPosition;
        Vector2 aTo = asteroid.Position;
        float ar = asteroid.CollisionRadius;

        // ── Звезда (статична, в центре 0,0) ──────────────────────────────────
        float starRadius = star.StarRadius > 0f ? star.StarRadius : 0.6f;
        {
            var (hit, t) = SweptCircleHit(aFrom, aTo, Vector2.zero, Vector2.zero, ar + starRadius);
            if (hit) { OnCollisionWithStar(asteroid, anim, ctx, round, t); return; }
        }

        // ── Корабли ───────────────────────────────────────────────────────────
        foreach (var ship in star.Ships)
        {
            if (ship.CurrentHull <= 0) continue;
            float shipRadius = GetShipCollisionRadius(ship);

            Vector2 shipFrom = ship.Position;
            Vector2 shipTo = ship.Position;
            if (anim != null && anim.ShipFrames.TryGetValue(ship.Uid, out var shipFrames))
            {
                shipFrom = shipFrames.Rounds[round - 1];
                shipTo = shipFrames.Rounds[round];
            }

            var (hit, t) = SweptCircleHit(aFrom, aTo, shipFrom, shipTo, ar + shipRadius);
            if (hit) { OnCollisionWithShip(asteroid, ship, anim, ctx, round, t); return; }
        }

        // ── Планеты и спутники ────────────────────────────────────────────────
        foreach (var planet in star.Planets)
        {
            float planetRadius = GetPlanetCollisionRadius(planet, ctx);
            Vector2 pFrom = GetPlanetPositionAtRound(planet, round - 1);
            Vector2 pTo = GetPlanetPositionAtRound(planet, round);

            var (hit, t) = SweptCircleHit(aFrom, aTo, pFrom, pTo, ar + planetRadius);
            if (hit) { OnCollisionWithPlanet(asteroid, planet, anim, ctx, round, t); return; }

            foreach (var sat in planet.Satellites)
            {
                Vector2 sFrom = GetSatelliteWorldPosition(sat, planet, round - 1);
                Vector2 sTo = GetSatelliteWorldPosition(sat, planet, round);
                var (satHit, satT) = SweptCircleHit(aFrom, aTo, sFrom, sTo, ar + 0.1f);
                if (satHit) { OnCollisionWithPlanet(asteroid, planet, anim, ctx, round, satT); return; }
            }
        }
    }

    // ── Столкновение со звездой ───────────────────────────────────────────────

    private static void OnCollisionWithStar(AsteroidData asteroid,
        TurnAnimationData anim, GalaxyGenerationContext ctx, int round, float tHit)
    {
        Debug.Log($"[AsteroidSystem] Asteroid '{asteroid.Uid[..8]}' hit star — burned up.");
        DestroyAsteroid(asteroid, anim,
            new List<ItemInstance>(),
            new List<ItemStack>(),
            hitPlayer: false,
            collisionType: AsteroidCollisionType.Star,
            round: round, tHit: tHit);
    }

    // ── Столкновение с кораблём ───────────────────────────────────────────────

    private static void OnCollisionWithShip(AsteroidData asteroid, ShipData ship,
        TurnAnimationData anim, GalaxyGenerationContext ctx, int round, float tHit)
    {
        float damage = CalculateDamage(asteroid,
            ctx?.Config?.Asteroids?.DampingConstant ?? GalaxyConstants.ASTEROID_DAMPING_CONST,
            GetShipAsteroidProtection(ship));

        int dmgInt = Mathf.Max(1, Mathf.RoundToInt(damage));
        ship.CurrentHull = Mathf.Max(0, ship.CurrentHull - dmgInt);

        Debug.Log($"[AsteroidSystem] Asteroid hit ship '{ship.Name}': -{dmgInt} HP " +
                  $"(hull={ship.CurrentHull}/{ship.MaxHull})");

        var (droppedItems, droppedStacks) = RollDrop(asteroid, ctx);

        if (ship.IsPlayer)
        {
            foreach (var item in droppedItems)
            {
                ship.AllItems[item.Uid] = item;
                ship.Inventory.Add(item);
            }
            anim.PauseReasons.Add(PauseReason.AsteroidImpact);
        }

        DestroyAsteroid(asteroid, anim, droppedItems, droppedStacks,
            hitPlayer: ship.IsPlayer,
            collisionType: AsteroidCollisionType.Ship,
            round: round, tHit: tHit);
    }

    // ── Столкновение с планетой / спутником ───────────────────────────────────

    private static void OnCollisionWithPlanet(AsteroidData asteroid, PlanetData planet,
        TurnAnimationData anim, GalaxyGenerationContext ctx, int round, float tHit)
    {
        Debug.Log($"[AsteroidSystem] Asteroid hit planet '{planet.Name}'.");
        var (droppedItems, droppedStacks) = RollDrop(asteroid, ctx);
        DestroyAsteroid(asteroid, anim, droppedItems, droppedStacks,
            hitPlayer: false,
            collisionType: AsteroidCollisionType.Planet,
            round: round, tHit: tHit);
    }

    // ── Уничтожение ───────────────────────────────────────────────────────────

    /// <summary>
    /// Помечает астероид уничтоженным и формирует AsteroidDestroyEvent.
    ///
    /// round — раунд столкновения (1..10).
    /// tHit  — момент внутри раунда [0..1] в который произошло касание (из SweptCircleHit).
    ///
    /// Позиция взрыва = Lerp(PreviousPosition, Position, tHit) — точка касания.
    /// Rounds[round] НЕ перезаписывается — он содержит реальную позицию конца движения
    /// и используется AnimateSystem для интерполяции до момента tHit.
    /// Rounds[round+1..10] фиксируются на contactPoint — астероид не движется после удара.
    /// </summary>
    private static void DestroyAsteroid(AsteroidData asteroid, TurnAnimationData anim,
        List<ItemInstance> droppedItems, List<ItemStack> droppedStacks,
        bool hitPlayer, AsteroidCollisionType collisionType,
        int round, float tHit)
    {
        asteroid.IsDestroyed = true;

        // Точка касания: интерполяция между позицией ДО раунда и ПОСЛЕ раунда
        Vector2 contactPoint = Vector2.Lerp(asteroid.PreviousPosition, asteroid.Position, tHit);

        // Rounds[round] оставляем как есть (реальный конец движения — нужен для Lerp до tHit).
        // Заполняем только раунды ПОСЛЕ столкновения — астероид стоит на месте взрыва.
        if (anim != null && anim.AsteroidFrames.TryGetValue(asteroid.Uid, out var frames))
        {
            for (int r = round + 1; r <= GalaxyData.TurnRounds; r++)
                frames.Rounds[r] = contactPoint;
        }

        anim?.AsteroidDestroys.Add(new AsteroidDestroyEvent
        {
            AsteroidUid = asteroid.Uid,
            Position = contactPoint,
            DroppedItems = droppedItems,
            DroppedStacks = droppedStacks,
            HitPlayer = hitPlayer,
            CollisionType = collisionType,
            CollisionRound = round,
            CollisionT = tHit,
        });
    }

    // ── ДОП ──────────────────────────────────────────────────────────────────

    /// <summary>
    /// Рассчитывает урон от столкновения.
    /// damage = (Mass × Speed²) / DampingConstant × (1 - AsteroidProtection)
    /// AsteroidProtection берётся из параметра корпуса корабля (0..1).
    /// </summary>
    public static float CalculateDamage(AsteroidData asteroid,
        float dampingConstant, float asteroidProtection)
    {
        float speed = asteroid.Velocity.magnitude;
        float rawDamage = (asteroid.Mass * speed * speed) / Mathf.Max(1f, dampingConstant);
        return rawDamage * Mathf.Clamp01(1f - asteroidProtection);
    }

    // ── ДРОП ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Рассчитывает дроп при уничтожении астероида.
    /// Каждый тип лута проверяется независимо — может выпасть несколько одновременно.
    /// Возвращает (оборудование, минералы).
    /// </summary>
    public static (List<ItemInstance> items, List<ItemStack> stacks) RollDrop(
        AsteroidData asteroid, GalaxyGenerationContext ctx)
    {
        var items = new List<ItemInstance>();
        var stacks = new List<ItemStack>();

        var cfg = ctx?.Config?.Asteroids;
        if (cfg == null || !cfg.Types.TryGetValue(asteroid.TypeId, out var typeCfg))
            return (items, stacks);

        var itemsCfg = ctx.ItemsConfig;

        // ── Обычный минерал ───────────────────────────────────────────────────
        if (itemsCfg?.GetMineral("CommonMineral") != null &&
            Random.value < typeCfg.CommonMineralChance)
        {
            var mineralCfg = itemsCfg.GetMineral("CommonMineral");
            int amount = Random.Range(mineralCfg.DropWeightMin, mineralCfg.DropWeightMax + 1);
            stacks.Add(new ItemStack
            {
                ItemId = "CommonMineral",
                Category = "Mineral",
                Name = mineralCfg.Name,
                TotalWeight = amount,
                BasePrice = mineralCfg.BasePrice
            });
        }

        // ── Драгоценный минерал ───────────────────────────────────────────────
        if (itemsCfg?.GetMineral("PreciousMineral") != null &&
            Random.value < typeCfg.PreciousMineralChance)
        {
            var mineralCfg = itemsCfg.GetMineral("PreciousMineral");
            int amount = Random.Range(mineralCfg.DropWeightMin, mineralCfg.DropWeightMax + 1);
            stacks.Add(new ItemStack
            {
                ItemId = "PreciousMineral",
                Category = "Mineral",
                Name = mineralCfg.Name,
                TotalWeight = amount,
                BasePrice = mineralCfg.BasePrice
            });
        }

        // ── Оборудование ──────────────────────────────────────────────────────
        if (ctx.Equipment != null && Random.value < typeCfg.EquipmentDropChance)
        {
            var picked = ctx.Equipment.GetRandomItem();
            if (picked.HasValue)
            {
                var inst = ItemFactory.Create(
                    picked.Value.category,
                    picked.Value.itemId,
                    ctx.Equipment,
                    ctx.Config);
                if (inst != null)
                {
                    // Дроп оборудования: Durability случайная от 30% до 80%
                    inst.Durability = Mathf.RoundToInt(
                        inst.MaxDurability * Random.Range(0.3f, 0.8f));
                    items.Add(inst);
                }
            }
        }

        return (items, stacks);
    }

    // ── СПАВН ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Создаёт новый астероид за пределами системы.
    /// Точка входа — случайная точка на окружности радиуса SystemSize/100 × 1.2.
    /// Начальный вектор скорости направлен примерно к центру системы
    /// с небольшим угловым смещением ±40° — это даёт разнообразие траекторий.
    /// </summary>
    private static AsteroidData CreateAsteroid(string typeId,
        AsteroidTypeConfig typeCfg, StarData star)
    {
        float systemRadius = star.SystemSize / 100f;
        float spawnRadius = systemRadius * 1.2f;

        float spawnAngle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
        var spawnPos = new Vector2(
            Mathf.Cos(spawnAngle) * spawnRadius,
            Mathf.Sin(spawnAngle) * spawnRadius);

        Vector2 toCenter = -spawnPos.normalized;
        float offsetAngle = Random.Range(-40f, 40f) * Mathf.Deg2Rad;
        float cos = Mathf.Cos(offsetAngle), sin = Mathf.Sin(offsetAngle);
        var direction = new Vector2(
            toCenter.x * cos - toCenter.y * sin,
            toCenter.x * sin + toCenter.y * cos);

        float speed = Random.Range(typeCfg.SpeedMin, typeCfg.SpeedMax);
        string graphicPath = ResolveSheetFolderPath(typeCfg.GraphicPath);

        return new AsteroidData
        {
            TypeId = typeId,
            Position = spawnPos,
            PreviousPosition = spawnPos,
            Velocity = direction * speed,
            Mass = Random.Range(typeCfg.MassMin, typeCfg.MassMax),
            CollisionRadius = typeCfg.CollisionRadius,
            GraphicPath = graphicPath,
            AnimFps = typeCfg.AnimFps,
            SelfRotationSpeed = Random.Range(
                typeCfg.SelfRotationSpeedMin, typeCfg.SelfRotationSpeedMax)
                * (Random.value > 0.5f ? 1f : -1f)
        };
    }

    // ── ВСПОМОГАТЕЛЬНЫЕ ───────────────────────────────────────────────────────

    private static int ResolveMaxAsteroids(StarData star)
    {
        if (star.MaxAsteroids >= 0) return star.MaxAsteroids;
        return GalaxyConstants.DEFAULT_MAX_ASTEROIDS;
    }

    private static float GetShipAsteroidProtection(ShipData ship)
    {
        var hull = EquipmentSystem.GetEquipped(ship, "Hull_0");
        return hull?.GetParam("AsteroidProtection", 0f) ?? 0f;
    }

    private static float GetPlanetCollisionRadius(PlanetData planet, GalaxyGenerationContext ctx)
    {
        if (ctx?.Config?.Planets?.Sizes != null &&
            ctx.Config.Planets.Sizes.TryGetValue(planet.Size, out var sizeData))
            return sizeData.BaseScale * 0.6f;
        return 0.5f;
    }

    /// <summary>
    /// Возвращает текущую мировую позицию планеты (финальная позиция, CurrentAngle).
    /// Используется в местах где раунд не важен.
    /// </summary>
    private static Vector2 GetPlanetWorldPosition(PlanetData planet)
    {
        float a = planet.OrbitRadius / 100f;
        float e = Mathf.Clamp(planet.OrbitEccentricity, 0f, 0.99f);
        float b = a * Mathf.Sqrt(1f - e * e);
        float c = a * e;
        float rad = planet.CurrentAngle * Mathf.Deg2Rad;
        float tiltRad = planet.OrbitTiltDeg * Mathf.Deg2Rad;
        float lx = Mathf.Cos(rad) * a - c;
        float ly = Mathf.Sin(rad) * b;
        float cosT = Mathf.Cos(tiltRad), sinT = Mathf.Sin(tiltRad);
        return new Vector2(lx * cosT - ly * sinT, lx * sinT + ly * cosT);
    }

    /// <summary>
    /// Позиция спутника в мировых координатах на основе текущего угла планеты.
    /// Используется для не-коллизионных целей (миникарта и пр.).
    /// </summary>
    private static Vector2 GetSatelliteWorldPosition(SatelliteData sat, PlanetData parent)
    {
        Vector2 planetPos = GetPlanetWorldPosition(parent);
        float r = sat.OrbitRadius / 100f;
        float rad = sat.CurrentAngle * Mathf.Deg2Rad;
        return planetPos + new Vector2(Mathf.Cos(rad) * r, Mathf.Sin(rad) * r * 0.4f);
    }

    /// <summary>
    /// Позиция спутника для конкретного раунда — интерполируется вместе с родительской планетой.
    /// round = 0 → PreviousAngle планеты, round = TurnRounds → CurrentAngle.
    /// </summary>
    private static Vector2 GetSatelliteWorldPosition(SatelliteData sat, PlanetData parent, int round)
    {
        Vector2 planetPos = GetPlanetPositionAtRound(parent, round);
        float r = sat.OrbitRadius / 100f;
        // Угол спутника тоже интерполируем линейно по раунду
        float t = (float)round / GalaxyData.TurnRounds;
        float satAngle = Mathf.LerpAngle(sat.CurrentAngle - 360f / sat.OrbitSpeed,
                                          sat.CurrentAngle, t);
        float rad = satAngle * Mathf.Deg2Rad;
        return planetPos + new Vector2(Mathf.Cos(rad) * r, Mathf.Sin(rad) * r * 0.4f);
    }

    /// <summary>
    /// Возвращает путь к спрайтлисту астероида без расширения
    /// (например "Graphics/Asteroids/Rocky/001").
    /// Значение берётся напрямую из AsteroidTypeConfig.GraphicPath — никакого случайного выбора.
    /// </summary>
    private static string ResolveSheetFolderPath(string configPath)
    {
        return string.IsNullOrEmpty(configPath) ? null : configPath;
    }
}

// ── Тип столкновения ─────────────────────────────────────────────────────────

/// <summary>
/// Тип объекта с которым столкнулся астероид.
/// Используется AsteroidDestroyEvent для передачи в визуальный слой.
/// None = тихий выход за границу (взрыв не спавнится).
/// </summary>
public enum AsteroidCollisionType
{
    None,    // вышел за границу — взрыв не воспроизводится
    Star,    // столкновение со звездой
    Planet,  // столкновение с планетой или спутником
    Ship,    // столкновение с кораблём
}