using UnityEngine;
using System.Collections.Generic;

public class ShipVisualController : MonoBehaviour
{
    // =========================================================================
    // Inspector
    // =========================================================================

    [Header("Renderers")]
    [SerializeField] private SpriteRenderer bodyRenderer;

    // =========================================================================
    // Runtime state
    // =========================================================================

    private Sprite[] _allFrames;           // весь спрайтлист, индексируется глобально
    private ShipData _data;
    private int bodySortingOrder;          // задаётся в Setup() через SortingLayerRegistry

    // Текущая анимация
    private ShipAnimationClip _currentClip;
    private string _currentClipName;
    private int _localFrame;               // кадр внутри текущего клипа
    private float _frameTimer;
    // Fix #5: кэшируем секунд-на-кадр при смене клипа, не пересчитываем каждый Update
    private float _currentClipSecPerFrame;

    // Поворот
    private float _targetAngle;
    private float _currentAngle;
    private const float RotationSpeed = 360f;  // градусов/сек

    // Шлейфы
    private readonly List<ThrusterInstance> _thrusters = new List<ThrusterInstance>();

    // Иконка минимапы
    private Sprite _minimapIcon;

    // =========================================================================
    // Inner types
    // =========================================================================

    private class ThrusterInstance
    {
        public SpriteRenderer Renderer;
        public Sprite[] Frames;
        public float SecPerFrame;
        public float Timer;
        public int CurrentFrame;
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /// <summary>
    /// Инициализирует контроллер по данным корабля.
    /// isPlayer определяет sortingOrder: игрок всегда рендерится поверх NPC.
    /// Вызывается один раз после спавна объекта (из SystemViewManager.SpawnShip).
    /// </summary>
    public void Setup(ShipData data, bool isPlayer = false)
    {
        _data = data;

        bodySortingOrder = isPlayer
            ? SortingLayerRegistry.Get(SortLayer.ShipPlayer)
            : SortingLayerRegistry.Get(SortLayer.ShipNpc);

        EnsureBodyRenderer();
        LoadSpritesheet();
        LoadMinimapIcon();
        SpawnThrusters();

        PlayAnimation("Idle");
    }

    /// <summary>
    /// Переключает текущую анимацию по имени.
    /// Если анимация уже играет — не перезапускает.
    /// </summary>
    public void SetAnimation(string clipName)
    {
        if (_currentClipName == clipName) return;
        if (_data?.Animations == null || !_data.Animations.TryGetValue(clipName, out var clip))
        {
            //Debug.LogWarning($"[ShipVisualController] Animation '{clipName}' not found on '{_data?.Name}'.");
            return;
        }

        _currentClip = clip;
        _currentClipName = clipName;
        _localFrame = 0;
        _frameTimer = 0f;
        // Fix #5: кэшируем при смене клипа
        _currentClipSecPerFrame = clip.FPS > 0f ? 1f / clip.FPS : 1f;
        ApplyFrame();
    }

    /// <summary>
    /// Задаёт направление движения в мировых координатах.
    /// Корабль плавно поворачивается в эту сторону.
    /// Передай Vector2.zero чтобы остановить поворот.
    /// </summary>
    public void SetMovementDirection(Vector2 direction)
    {
        if (direction.sqrMagnitude < 0.001f) return;
        _targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90f;
    }

    /// <summary>
    /// Включает или выключает шлейфы двигателей.
    /// Для игрока — вызывать при начале/конце ввода тяги,
    /// для NPC — при начале/конце движения к цели.
    /// </summary>
    public void SetThrustersActive(bool active)
    {
        foreach (var t in _thrusters)
            if (t.Renderer != null)
                t.Renderer.gameObject.SetActive(active);
    }

    /// <summary>
    /// Возвращает иконку корабля для минимапы.
    /// </summary>
    public Sprite GetMinimapIcon() => _minimapIcon;

    // =========================================================================
    // Unity lifecycle
    // =========================================================================

    private void Update()
    {
        float dt = Time.deltaTime;
        TickAnimation(dt);
        TickRotation(dt);
        TickThrusters(dt);
    }

    private void OnDestroy()
    {
        // Спрайтлист загружается через Resources — дополнительной очистки не требуется.
        // Если в будущем будет кешироваться материал — уничтожить здесь.
    }

    // =========================================================================
    // Tick methods
    // =========================================================================

    private void TickAnimation(float dt)
    {
        if (_currentClip == null || _allFrames == null) return;
        if (_currentClip.FrameCount <= 1) return;

        // Fix #5: используем кэшированное значение
        _frameTimer += dt;

        if (_frameTimer < _currentClipSecPerFrame) return;

        int advance = Mathf.FloorToInt(_frameTimer / _currentClipSecPerFrame);
        _frameTimer %= _currentClipSecPerFrame;

        int nextLocal = _localFrame + advance;

        if (_currentClip.Loop)
        {
            _localFrame = nextLocal % _currentClip.FrameCount;
        }
        else
        {
            _localFrame = Mathf.Min(nextLocal, _currentClip.FrameCount - 1);
        }

        ApplyFrame();
    }

    private void TickRotation(float dt)
    {
        _currentAngle = Mathf.MoveTowardsAngle(_currentAngle, _targetAngle, RotationSpeed * dt);
        transform.rotation = Quaternion.Euler(0f, 0f, _currentAngle);
    }

    private void TickThrusters(float dt)
    {
        foreach (var t in _thrusters)
        {
            if (t.Renderer == null || !t.Renderer.gameObject.activeSelf) continue;
            if (t.Frames == null || t.Frames.Length <= 1) continue;

            t.Timer += dt;
            if (t.Timer < t.SecPerFrame) continue;

            int advance = Mathf.FloorToInt(t.Timer / t.SecPerFrame);
            t.Timer %= t.SecPerFrame;
            t.CurrentFrame = (t.CurrentFrame + advance) % t.Frames.Length;
            t.Renderer.sprite = t.Frames[t.CurrentFrame];
        }
    }

    // =========================================================================
    // Setup helpers
    // =========================================================================

    private void EnsureBodyRenderer()
    {
        if (bodyRenderer == null)
        {
            if (!TryGetComponent(out bodyRenderer))
                bodyRenderer = gameObject.AddComponent<SpriteRenderer>();
        }
        bodyRenderer.sortingOrder = bodySortingOrder;
    }

    private void LoadSpritesheet()
    {
        if (string.IsNullOrEmpty(_data?.SpritesheetPath))
        {
            Debug.LogWarning($"[ShipVisualController] SpritesheetPath is empty for '{_data?.Name}'.");
            return;
        }

        var sprites = Resources.LoadAll<Sprite>(_data.SpritesheetPath);
        if (sprites == null || sprites.Length == 0)
        {
            Debug.LogError($"[ShipVisualController] Spritesheet not found: {_data.SpritesheetPath}");
            return;
        }

        // Сортируем по имени — совпадает с соглашением GraphicsManager
        System.Array.Sort(sprites, (a, b) => string.Compare(a.name, b.name, System.StringComparison.Ordinal));
        _allFrames = sprites;
    }

    private void LoadMinimapIcon()
    {
        if (string.IsNullOrEmpty(_data?.MinimapIconPath)) return;
        _minimapIcon = Resources.Load<Sprite>(_data.MinimapIconPath);
        if (_minimapIcon == null)
            Debug.LogWarning($"[ShipVisualController] Minimap icon not found: {_data.MinimapIconPath}");
    }

    private void SpawnThrusters()
    {
        if (_data?.Thrusters == null || _data.Thrusters.Count == 0) return;

        foreach (var thrusterData in _data.Thrusters)
        {
            var go = new GameObject("Thruster");
            go.transform.SetParent(transform, false);
            go.transform.localPosition = new Vector3(thrusterData.LocalOffset.x, thrusterData.LocalOffset.y, 0f);
            go.SetActive(false); // выключены по умолчанию

            var sr = go.AddComponent<SpriteRenderer>();
            sr.sortingOrder = SortingLayerRegistry.Get(SortLayer.ShipThruster);

            Sprite[] frames = null;
            if (!string.IsNullOrEmpty(thrusterData.SpritesheetPath))
            {
                var sprites = Resources.LoadAll<Sprite>(thrusterData.SpritesheetPath);
                if (sprites?.Length > 0)
                {
                    System.Array.Sort(sprites, (a, b) => string.Compare(a.name, b.name, System.StringComparison.Ordinal));
                    frames = sprites;
                    sr.sprite = frames[0];
                }
            }

            float secPerFrame = thrusterData.FPS > 0f ? 1f / thrusterData.FPS : 1f / 12f;
            _thrusters.Add(new ThrusterInstance
            {
                Renderer = sr,
                Frames = frames,
                SecPerFrame = secPerFrame,
                Timer = 0f,
                CurrentFrame = 0
            });
        }
    }

    private void PlayAnimation(string clipName)
    {
        if (_data?.Animations == null || !_data.Animations.TryGetValue(clipName, out var clip))
        {
            Debug.LogWarning($"[ShipVisualController] Base animation '{clipName}' not found on '{_data?.Name}'.");
            return;
        }

        _currentClip = clip;
        _currentClipName = clipName;
        _localFrame = 0;
        _frameTimer = 0f;
        // Fix #5: кэшируем при инициализации
        _currentClipSecPerFrame = clip.FPS > 0f ? 1f / clip.FPS : 1f;
        ApplyFrame();
    }

    private void ApplyFrame()
    {
        if (_currentClip == null || _allFrames == null || bodyRenderer == null) return;

        int globalIndex = _currentClip.StartFrame + _localFrame;
        if (globalIndex < 0 || globalIndex >= _allFrames.Length)
        {
            Debug.LogWarning($"[ShipVisualController] Frame index {globalIndex} out of range ({_allFrames.Length} frames).");
            return;
        }

        bodyRenderer.sprite = _allFrames[globalIndex];
    }
}