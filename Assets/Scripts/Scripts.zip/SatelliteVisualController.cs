﻿using UnityEngine;

// =====================================================================
// SatelliteVisualController.cs
// Визуальный контроллер спутника планеты.
//
// Спутник рендерится через шейдер Custom/PlanetRotation:
//   - поверхность вращается по шейдерной переменной _Rotation
//   - форма вырезается SpriteMask из родительской планеты
//   - при движении по орбите меняется глубина (sortingOrder) и масштаб
//
// Создаётся и управляется PlanetVisualController.
// UpdateVisualOrbit(dt) вызывается каждый кадр из PlanetVisualController.Update().
// =====================================================================

public class SatelliteVisualController : MonoBehaviour
{
    [Header("Renderers")]
    public SpriteRenderer SurfaceRenderer;
    public SpriteRenderer AtmosphereRenderer;
    public SpriteMask ShapeMask;

    private Material _material;
    private MaterialPropertyBlock _propBlock;

    // Shader property IDs кэшируются статически — Shader.PropertyToID дёшев, но лучше не повторять.
    private static readonly int RotationID = Shader.PropertyToID("_Rotation");
    private static readonly int MainTexID = Shader.PropertyToID("_MainTex");

    // Кэшируем шейдер статически — Shader.Find() дорог, нельзя вызывать на каждый спавн.
    // Аналогично PlanetVisualController.
    private static Shader _planetShader;
    private static Shader PlanetShader => _planetShader ??= Shader.Find("Custom/PlanetRotation");

    private SatelliteData _data;
    private float _selfRotationSpeed;   // оборотов в секунду для шейдера
    private float _currentRotation;     // текущее значение _Rotation [0..1]
    private float _visualOrbitAngle;    // текущий угол на орбите (градусы), обновляется в UpdateVisualOrbit
    private float _baseScale;           // базовый масштаб из конфига (по ключу Size)

    private void Awake()
    {
        _propBlock = new MaterialPropertyBlock();
    }

    private void OnDestroy()
    {
        // Материал создаётся через new Material() — необходимо явно уничтожить.
        if (_material != null) Destroy(_material);
    }

    // =========================================================================
    // Public API
    // =========================================================================

    /// <summary>
    /// Инициализирует контроллер по данным спутника и его родительской планеты.
    /// parent нужен для получения маски формы (MaskGraphic).
    /// Вызывается один раз из PlanetVisualController.SpawnSatellites().
    /// </summary>
    public void Setup(SatelliteData data, PlanetData parent)
    {
        _data = data;
        _visualOrbitAngle = data.CurrentAngle;

        // Создаём индивидуальный экземпляр материала (не шарим между спутниками)
        _material = new Material(PlanetShader);

        Sprite mask = GraphicsManager.Instance.GetPlanetMask(parent.MaskGraphic);
        EnsureMask(mask);

        SurfaceRenderer = EnsureRenderer(SurfaceRenderer, "Surface_Slot",
            SortingLayerRegistry.Get(SortLayer.PlanetSurface), useMask: true);
        Sprite texture = GraphicsManager.Instance.GetSprite(data.Graphic);

        if (texture != null)
        {
            SetupLayer(SurfaceRenderer, texture, mask);
            // Если DaySpeed = 0 — назначаем случайную скорость для визуального разнообразия
            _selfRotationSpeed = data.DaySpeed > 0 ? 1f / data.DaySpeed : Random.Range(0.5f, 2f);
            _currentRotation = Random.value; // случайная начальная фаза
        }

        ApplyScale(data.Size);
        UpdateWorldPosition(_visualOrbitAngle);
    }

    /// <summary>
    /// Продвигает визуальную анимацию орбиты и вращения на dt секунд.
    /// Вызывается из PlanetVisualController.Update() каждый кадр.
    /// </summary>
    public void UpdateVisualOrbit(float dt)
    {
        if (_data == null) return;

        // Угловая скорость: OrbitSpeed = дней на оборот → gradусов/сек = 360/(speed*dt) — но это за ход.
        // Для плавного визуала: за 1 сек проходим 360/OrbitSpeed градусов.
        float step = Mathf.Abs(_data.OrbitSpeed) < 0.01f ? 0f : 360f / _data.OrbitSpeed;
        _visualOrbitAngle = WrapAngle(_visualOrbitAngle + step * dt);
        UpdateWorldPosition(_visualOrbitAngle);

        // Обновляем вращение поверхности через шейдер
        if (SurfaceRenderer != null && SurfaceRenderer.gameObject.activeSelf)
        {
            _currentRotation += _selfRotationSpeed * dt;
            if (_currentRotation > 1f) _currentRotation -= 1f;

            SurfaceRenderer.GetPropertyBlock(_propBlock);
            _propBlock.SetFloat(RotationID, _currentRotation);
            SurfaceRenderer.SetPropertyBlock(_propBlock);
        }
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    /// <summary>
    /// Вычисляет и применяет мировую позицию спутника на основе угла орбиты.
    /// Наклон орбиты имитируется эллиптическим сжатием по оси Y (коэффициент 0.4).
    /// Сортировочный порядок и масштаб меняются в зависимости от «глубины» (sin угла).
    /// </summary>
    private void UpdateWorldPosition(float angleDeg)
    {
        float rad = angleDeg * Mathf.Deg2Rad;
        float r = _data.OrbitRadius / 100f;
        float incl = _data.OrbitInclination * Mathf.Deg2Rad;

        // Эллиптическое движение: Y сжимается до 40% от X для имитации наклона орбиты
        float xBase = Mathf.Cos(rad) * r;
        float yBase = Mathf.Sin(rad) * r * 0.4f;

        // Применяем наклон плоскости орбиты (поворот 2D)
        transform.localPosition = new Vector3(
            xBase * Mathf.Cos(incl) - yBase * Mathf.Sin(incl),
            xBase * Mathf.Sin(incl) + yBase * Mathf.Cos(incl),
            0f
        );

        // Иллюзия глубины: спутники «за» планетой меньше и с другим sortingOrder
        float depthFactor = Mathf.Sin(rad);
        float scaleMult = 1f - depthFactor * 0.25f;
        transform.localScale = Vector3.one * (_baseScale * scaleMult);

        // depthFactor > 0 → спутник «перед» планетой (ближе к камере)
        SetSortingOrders(depthFactor > 0
            ? SortingLayerRegistry.Get(SortLayer.SatelliteUp)
            : SortingLayerRegistry.Get(SortLayer.SatelliteDown));
    }

    /// <summary>Гарантирует наличие компонента SpriteMask и устанавливает маску.</summary>
    private void EnsureMask(Sprite mask)
    {
        if (ShapeMask == null && !TryGetComponent(out ShapeMask))
            ShapeMask = gameObject.AddComponent<SpriteMask>();
        ShapeMask.sprite = mask;
    }

    /// <summary>Инициализирует слой рендерера (привязка материала, текстуры, маски).</summary>
    private void SetupLayer(SpriteRenderer r, Sprite texture, Sprite mask)
    {
        r.gameObject.SetActive(true);
        r.material = _material;
        r.sprite = mask; // маска задаёт форму, текстура — через MaterialPropertyBlock

        if (_propBlock == null) _propBlock = new MaterialPropertyBlock();
        r.GetPropertyBlock(_propBlock);
        _propBlock.SetTexture(MainTexID, texture.texture);
        r.SetPropertyBlock(_propBlock);
    }

    /// <summary>
    /// Находит или создаёт SpriteRenderer в дочернем объекте с именем slotName.
    /// Устанавливает sortingOrder и maskInteraction.
    /// </summary>
    private SpriteRenderer EnsureRenderer(SpriteRenderer r, string slotName, int sortOrder, bool useMask)
    {
        if (r == null)
        {
            Transform slot = transform.Find(slotName);
            if (slot != null)
                r = slot.GetComponent<SpriteRenderer>();
            else
            {
                var go = new GameObject(slotName);
                go.transform.SetParent(transform, worldPositionStays: false);
                r = go.AddComponent<SpriteRenderer>();
            }
        }
        r.transform.localPosition = Vector3.zero;
        r.transform.localScale = Vector3.one;
        r.sortingOrder = sortOrder;
        r.maskInteraction = useMask ? SpriteMaskInteraction.VisibleInsideMask : SpriteMaskInteraction.None;
        return r;
    }

    /// <summary>
    /// Применяет базовый масштаб по ключу размера (Tiny / Mid / Big).
    /// Данные берутся из GalaxyConfig через GraphicsManager.
    /// </summary>
    private void ApplyScale(string sizeKey)
    {
        float scale = 1f;
        var config = GraphicsManager.Instance.GetConfig();
        if (config?.Satellites?.Sizes != null &&
            config.Satellites.Sizes.TryGetValue(sizeKey, out var data))
            scale = data.BaseScale;
        _baseScale = scale;
        transform.localScale = Vector3.one * scale;
    }

    /// <summary>Устанавливает sortingOrder для всех активных рендереров.</summary>
    private void SetSortingOrders(int order)
    {
        if (SurfaceRenderer) SurfaceRenderer.sortingOrder = order;
        if (AtmosphereRenderer) AtmosphereRenderer.sortingOrder = order + 1;
    }

    /// <summary>Нормализует угол в диапазон [0..360).</summary>
    private static float WrapAngle(float angle)
    {
        if (angle >= 360f) angle -= 360f;
        if (angle < 0f) angle += 360f;
        return angle;
    }
}