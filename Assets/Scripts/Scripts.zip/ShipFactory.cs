using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public static class ShipFactory
{
    public static ShipData BuildShipData(string shipTypeId, string factionId,
        Dictionary<string, ShipTypeConfig> availableShipTypes)
    {
        if (!availableShipTypes.TryGetValue(shipTypeId, out var cfg))
        {
            Debug.LogWarning($"[ShipFactory] ShipType '{shipTypeId}' not found.");
            return null;
        }

        var data = new ShipData
        {
            Name = shipTypeId,
            ShipTypeId = shipTypeId,
            FactionId = factionId ?? string.Empty,
            SpritesheetPath = cfg.SpritesheetPath,
            MinimapIconPath = cfg.MinimapIconPath,
            BaseHull = cfg.BaseHull,
            BaseWeight = cfg.BaseWeight,
            EngineSpeed = cfg.DefaultEngineSpeed,
        };

        if (cfg.Animations != null)
        {
            // ShipTypeConfig.Animations � ShipData.Animations ���������� ���� � ��� �� ��� �
            // ShipAnimationClip. ������ ������������ ��� ����������� �����.
            data.Animations = new Dictionary<string, ShipAnimationClip>(cfg.Animations);
        }

        if (cfg.Thrusters != null)
        {
            data.Thrusters = new List<ShipThrusterData>();
            foreach (var t in cfg.Thrusters)
                data.Thrusters.Add(new ShipThrusterData
                {
                    LocalOffset = new Vector2(t.OffsetX, t.OffsetY),
                    SpritesheetPath = t.SpritesheetPath,
                    FPS = t.FPS
                });
        }

        return data;
    }

    public static string GetRandomShipTypeForFaction(string factionId,
        Dictionary<string, List<string>> factionLineups,
        Dictionary<string, ShipTypeConfig> availableShipTypes,
        List<string> availableShipTypeKeys = null)
    {
        if (!string.IsNullOrEmpty(factionId)
            && factionLineups.TryGetValue(factionId, out var lineup)
            && lineup.Count > 0)
            return lineup[UnityEngine.Random.Range(0, lineup.Count)];

        if (availableShipTypeKeys != null && availableShipTypeKeys.Count > 0)
            return availableShipTypeKeys[UnityEngine.Random.Range(0, availableShipTypeKeys.Count)];

        int count = availableShipTypes.Count;
        return count > 0 ? availableShipTypes.Keys.ElementAt(UnityEngine.Random.Range(0, count)) : null;
    }
}

