using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// Контроллер корабля игрока.
///
/// Управление:
///   ЛКМ           — назначить точку маршрута (заменяет очередь).
///   Shift + ЛКМ   — добавить точку в конец очереди.
///   Пробел        — обрабатывается в GalaxyManager (Planning/Animating).
///
/// Паузы:
///   RouteCompleted → GalaxyManager.RequestPause(RouteCompleted)
///   LowHull        → через TurnAnimationData.PauseReasons (считается в GalaxyData)
/// </summary>
public class PlayerShip : MonoBehaviour
{
    // =========================================================================
    // Singleton
    // =========================================================================

    public static PlayerShip Instance { get; private set; }

    // =========================================================================
    // Data
    // =========================================================================

    public ShipData ShipData { get; private set; }

    /// <summary>
    /// Срабатывает когда игрок назначает новый маршрут (ЛКМ по карте).
    /// Камера подписывается чтобы включить edge-следование.
    /// </summary>
    public static event System.Action OnRouteAssigned;

    /// <summary>
    /// True если в текущем ходу игрок реально двигается (хотя бы один раунд смещение > 0).
    /// Сбрасывается в начале каждого хода, выставляется в OnTurnAnimate.
    /// </summary>
    public bool IsMovingThisTurn { get; private set; }

    // =========================================================================
    // Settings
    // =========================================================================

    [SerializeField] private GameSettingsConfig _settings;

    // =========================================================================
    // Private state
    // =========================================================================

    private Camera _cam;
    private ShipVisualController _visual;
    private PathRenderer _pathRenderer;
    private bool _isTurnInProgress;

    /// <summary>Очередь путевых точек.</summary>
    private readonly Queue<Vector2> _waypoints = new Queue<Vector2>();

    /// <summary>
    /// True после того как последняя точка маршрута достигнута.
    /// Сбрасывается при назначении нового маршрута.
    /// Предотвращает повторный RequestPause на каждый ход.
    /// </summary>
    private bool _routeCompleted = false;

    // =========================================================================
    // Init
    // =========================================================================

    public void Init(ShipData shipData, Camera cam, GameSettingsConfig settings = null)
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("[PlayerShip] Дубликат уничтожен.");
            Destroy(this);
            return;
        }
        Instance = this;

        ShipData = shipData;
        _cam = cam;
        if (settings != null) _settings = settings;

        _visual = GetComponent<ShipVisualController>();

        _pathRenderer = GetComponentInChildren<PathRenderer>();
        if (_pathRenderer == null)
        {
            var go = new GameObject("PathRenderer");
            go.transform.SetParent(transform, worldPositionStays: false);
            _pathRenderer = go.AddComponent<PathRenderer>();
        }

        Debug.Log($"[PlayerShip] Init: {ShipData.Name} speed={ShipData.EngineSpeed}");
    }

    // =========================================================================
    // Unity lifecycle
    // =========================================================================

    private void OnEnable()
    {
        GalaxyManager.OnTurnCalculate += OnTurnCalculate;
        GalaxyManager.OnTurnAnimate += OnTurnAnimate;
        GalaxyManager.OnTurnComplete += OnTurnComplete;
    }

    private void OnDisable()
    {
        GalaxyManager.OnTurnCalculate -= OnTurnCalculate;
        GalaxyManager.OnTurnAnimate -= OnTurnAnimate;
        GalaxyManager.OnTurnComplete -= OnTurnComplete;
    }

    private void Update()
    {
        if (!_isTurnInProgress)
            HandleInput();
    }

    // =========================================================================
    // Input
    // =========================================================================

    private void HandleInput()
    {
        if (!Input.GetMouseButtonDown(0)) return;
        if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject()) return;

        var worldPos = _cam.ScreenToWorldPoint(Input.mousePosition);
        var clickPos = new Vector2(worldPos.x, worldPos.y);

        var hit = Physics2D.Raycast(clickPos, Vector2.zero);
        if (hit.collider != null) return;

        KeyCode shiftKey = _settings != null ? _settings.MultiWaypointKey : KeyCode.LeftShift;
        bool addMode = Input.GetKey(shiftKey);

        if (addMode)
        {
            _waypoints.Enqueue(clickPos);
        }
        else
        {
            _waypoints.Clear();
            _waypoints.Enqueue(clickPos);
        }

        _routeCompleted = false;

        ApplyWaypointsToShipData();
        RedrawPath();

        // Сигнал камере: новый маршрут — включить edge-следование
        OnRouteAssigned?.Invoke();
    }

    // =========================================================================
    // Path drawing
    // =========================================================================

    private void RedrawPath()
    {
        if (_waypoints.Count == 0) { _pathRenderer.ClearPath(); return; }

        var star = GalaxyManager.Instance?.CurrentStar;

        // Берём позицию и курс из данных симуляции, не из Transform
        Vector2 prevPos = ShipData.Position;
        float heading = ShipData.CurrentHeading;

        // chain[0] = текущая позиция, затем точки траектории
        var chain = new List<Vector2> { prevPos };

        foreach (var wp in _waypoints)
        {
            var samples = ShipTrajectory.BuildPath(
                prevPos, wp, heading,
                star != null ? star.Position : Vector2.zero,
                star != null ? star.StarRadius : 0f);

            if (samples.Count == 0) continue;
            chain.AddRange(samples);

            // Курс для следующего сегмента — по последнему шагу текущего
            if (samples.Count >= 2)
                heading = Mathf.Atan2(
                    samples[samples.Count - 1].y - samples[samples.Count - 2].y,
                    samples[samples.Count - 1].x - samples[samples.Count - 2].x);
            prevPos = wp;
        }

        float step = ShipData.ActualSpeed / 100f;
        _pathRenderer.DrawPath(chain, step, preSampled: true);
    }

    // =========================================================================
    // Turn events
    // =========================================================================

    // Вызывается сразу после расчёта — данные уже финальные, анимация не началась.
    private void OnTurnCalculate(TurnAnimationData anim)
    {
        _isTurnInProgress = true;
        IsMovingThisTurn = false;
        _pathRenderer.ClearPath();
    }

    // Вызывается каждый кадр во время анимации.
    // progress: 0..1 — общий прогресс хода.
    // currentTick: 1..10 — текущий тик.
    private void OnTurnAnimate(float progress, int currentTick)
    {
        var animData = GalaxyManager.Instance?.LastTurnData;
        if (animData == null || !animData.ShipFrames.TryGetValue(ShipData.Uid, out var frames)) return;

        Vector2 pos;
        Vector2 direction = Vector2.zero;

        var sub = frames.SubFrames;
        if (sub != null && sub.Count >= 2)
        {
            // ── Плавная анимация по SubFrames (реальная траектория из симуляции) ──
            float fIdx = progress * (sub.Count - 1);
            int i0 = Mathf.Clamp(Mathf.FloorToInt(fIdx), 0, sub.Count - 2);
            int i1 = i0 + 1;
            float t = fIdx - i0;

            pos = Vector2.Lerp(sub[i0], sub[i1], t);
            direction = sub[i1] - sub[i0];

            // Обновляем курс для следующего хода по последнему направлению
            if (progress >= 0.99f)
            {
                var d = sub[sub.Count - 1] - sub[sub.Count - 2];
                if (d.sqrMagnitude > 0.0001f)
                    ShipData.CurrentHeading = Mathf.Atan2(d.y, d.x);
            }
        }
        else
        {
            // ── Fallback: линейная интерполяция по раундам ───────────────────
            float tickProgress = Mathf.Clamp01((progress * GalaxyData.TurnRounds) - (currentTick - 1));
            var posFrom = frames.Rounds[currentTick - 1];
            var posTo = frames.Rounds[currentTick];
            pos = Vector2.Lerp(posFrom, posTo, tickProgress);
            direction = posTo - posFrom;
        }

        transform.position = new Vector3(pos.x, pos.y, 0f);

        if (direction.sqrMagnitude > 0.0001f)
        {
            IsMovingThisTurn = true;
            _visual?.SetMovementDirection(direction);
            _visual?.SetThrustersActive(true);
            _visual?.SetAnimation("Move");
        }
        else
        {
            _visual?.SetThrustersActive(false);
        }
    }

    // Вызывается один раз когда тик 10 завершён.
    private void OnTurnComplete(TurnAnimationData anim)
    {
        _visual?.SetThrustersActive(false);
        _visual?.SetAnimation("Idle");
        _isTurnInProgress = false;

        // Снэп в финальную позицию.
        transform.position = new Vector3(ShipData.Position.x, ShipData.Position.y, 0f);

        // Фиксируем финальный курс по реальной траектории хода
        var lastAnim = GalaxyManager.Instance?.LastTurnData;
        if (lastAnim != null && lastAnim.ShipFrames.TryGetValue(ShipData.Uid, out var doneFrames))
        {
            var sub = doneFrames.SubFrames;
            if (sub != null && sub.Count >= 2)
            {
                var dv = sub[sub.Count - 1] - sub[sub.Count - 2];
                if (dv.sqrMagnitude > 0.0001f)
                    ShipData.CurrentHeading = Mathf.Atan2(dv.y, dv.x);
            }
        }

        if (_routeCompleted) return;

        // После симуляции:
        //   ShipData.TargetPosition — точка, к которой шёл корабль последним (может быть достигнута или нет)
        //   ShipData.SimWaypoints   — точки, которые не были взяты из очереди (не дошёл до них)
        //
        // Пересобираем _waypoints и сразу готовим TargetPosition + SimWaypoints для следующего хода.

        float sqDist = (ShipData.TargetPosition - ShipData.Position).sqrMagnitude;
        bool targetReached = sqDist <= 0.01f;

        // Собираем полный остаток маршрута.
        _waypoints.Clear();
        if (!targetReached)
            _waypoints.Enqueue(ShipData.TargetPosition);
        foreach (var wp in ShipData.SimWaypoints)
            _waypoints.Enqueue(wp);

        // Явно очищаем SimWaypoints: foreach по Queue<Vector2> не удаляет элементы.
        ShipData.SimWaypoints.Clear();

        Debug.Log($"[PlayerShip] OnTurnComplete: pos={ShipData.Position:F2} targetReached={targetReached} remaining={_waypoints.Count}");

        if (_waypoints.Count > 0)
        {
            // Fix #7: дублированный блок заменён вызовом ApplyWaypointsToShipData().
            ApplyWaypointsToShipData();
            RedrawPath();
        }
        else
        {
            // Весь маршрут выполнен.
            ShipData.TargetPosition = ShipData.Position;
            ShipData.SimWaypoints.Clear();
            _pathRenderer.ClearPath();
            _routeCompleted = true;

            bool pauseOnRoute = _settings == null || _settings.MovieInterruptOnActionDone;
            Debug.Log($"[PlayerShip] Route complete. PauseOnRoute={pauseOnRoute}");
            if (pauseOnRoute)
                GalaxyManager.Instance?.RequestPause(PauseReason.RouteCompleted);
        }
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    // Fix #7: вынесен общий блок подготовки ShipData для симуляции.
    // Устанавливает TargetPosition на первую точку и заполняет SimWaypoints остатком.
    // Вызывается из HandleInput() и OnTurnComplete().
    private void ApplyWaypointsToShipData()
    {
        if (_waypoints.Count == 0) return;

        ShipData.TargetPosition = _waypoints.Peek();
        ShipData.SimWaypoints.Clear();

        // Сбрасываем кривую — при назначении нового маршрута старые точки не должны использоваться.
        ShipData.BezierIndex = 0;

        // Строим кривую для первой точки маршрута уже здесь, от текущей позиции корабля.
        // Без этого ShipMoveStep уходит в прямой fallback для первой точки,
        // игнорируя инерцию курса и обход звезды.
        var star = GalaxyManager.Instance?.CurrentStar;
        ShipData.BezierWaypoints = ShipTrajectory.BuildPath(
            ShipData.Position,
            ShipData.TargetPosition,
            ShipData.CurrentHeading,
            star != null ? star.Position : Vector2.zero,
            star != null ? star.StarRadius : 0f);

        // Заполняем SimWaypoints всеми точками кроме первой (для неё кривая уже построена).
        bool isFirst = true;
        foreach (var wp in _waypoints)
        {
            if (isFirst) { isFirst = false; continue; }
            ShipData.SimWaypoints.Enqueue(wp);
        }
    }
}