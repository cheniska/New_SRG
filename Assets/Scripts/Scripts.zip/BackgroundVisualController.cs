﻿using UnityEngine;
using System.Collections.Generic;

public class BackgroundVisualController : MonoBehaviour
{
    private Transform _blackVoid;
    private SpriteRenderer _blackVoidRenderer;
    private readonly List<(Transform t, SpriteRenderer sr, float speed)> _parallaxLayers = new();
    private Camera _camera;

    private readonly List<Texture2D> _ownedTextures = new();
    private readonly List<Sprite> _ownedSprites = new();

    public void Setup(Camera targetCamera, int seed)
    {
        _camera = targetCamera;
        DestroyOwnedAssets();
        foreach (Transform child in transform) Destroy(child.gameObject);
        _parallaxLayers.Clear();

        Random.InitState(seed);
        _blackVoid = CreateBlackVoid();
        CreateStarLayer("Stars_Far", SortingLayerRegistry.Get(SortLayer.BackgroundStarsFar), parallaxSpeed: GalaxyConstants.BG_PARALLAX_FAR, starCount: GalaxyConstants.BG_STAR_COUNT_FAR, texSize: GalaxyConstants.BG_TEX_SIZE_FAR);
        CreateStarLayer("Stars_Mid", SortingLayerRegistry.Get(SortLayer.BackgroundStarsMid), parallaxSpeed: GalaxyConstants.BG_PARALLAX_MID, starCount: GalaxyConstants.BG_STAR_COUNT_MID, texSize: GalaxyConstants.BG_TEX_SIZE_FAR);
        CreateStarLayer("Stars_Near", SortingLayerRegistry.Get(SortLayer.BackgroundStarsNear), parallaxSpeed: GalaxyConstants.BG_PARALLAX_NEAR, starCount: GalaxyConstants.BG_STAR_COUNT_NEAR, texSize: GalaxyConstants.BG_TEX_SIZE_NEAR);
    }

    private void OnDestroy() => DestroyOwnedAssets();

    private void DestroyOwnedAssets()
    {
        foreach (var tex in _ownedTextures) if (tex != null) Destroy(tex);
        _ownedTextures.Clear();
        foreach (var spr in _ownedSprites) if (spr != null) Destroy(spr);
        _ownedSprites.Clear();
    }

    // Fix #25: убрана аллокация Color[1920×1080] = 2M элементов.
    // Заменена созданием 1×1 чёрного текстура с тайлингом через SpriteDrawMode.Tiled.
    // Спрайт масштабируется в LateUpdate через localScale, а не размером текстуры.
    private Transform CreateBlackVoid()
    {
        var obj = new GameObject("Background_BlackVoid");
        obj.transform.SetParent(transform);
        var sr = obj.AddComponent<SpriteRenderer>();

        var tex = new Texture2D(1, 1, TextureFormat.RGB24, false);
        tex.SetPixel(0, 0, Color.black);
        tex.Apply();

        var sprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), Vector2.one * 0.5f, 1f);
        sr.sprite = sprite;
        sr.sortingOrder = SortingLayerRegistry.Get(SortLayer.BackgroundVoid);

        _ownedTextures.Add(tex);
        _ownedSprites.Add(sprite);
        _blackVoidRenderer = sr;
        return obj.transform;
    }

    private void CreateStarLayer(string name, int sortOrder, float parallaxSpeed, int starCount, int texSize)
    {
        var layer = new GameObject(name);
        layer.transform.SetParent(transform);
        var sr = layer.AddComponent<SpriteRenderer>();
        var tex = new Texture2D(texSize, texSize, TextureFormat.RGBA32, false);
        var pixels = new Color[texSize * texSize];
        tex.SetPixels(pixels);

        for (int i = 0; i < starCount; i++)
        {
            int x = Random.Range(10, texSize - 10), y = Random.Range(10, texSize - 10);
            float b = Random.Range(0.4f, 1f);
            var c = new Color(b, b, b, 1f);
            tex.SetPixel(x, y, c); tex.SetPixel(x + 1, y, c * 0.5f); tex.SetPixel(x, y + 1, c * 0.5f);
        }
        tex.Apply();

        var sprite = Sprite.Create(tex, new Rect(0, 0, texSize, texSize), Vector2.zero, 100f, 0, SpriteMeshType.FullRect);
        sr.sprite = sprite; sr.drawMode = SpriteDrawMode.Tiled; sr.tileMode = SpriteTileMode.Continuous;
        sr.size = new Vector2(GalaxyConstants.BG_LAYER_TILE_SIZE, GalaxyConstants.BG_LAYER_TILE_SIZE);
        sr.sortingOrder = sortOrder;

        _ownedTextures.Add(tex); _ownedSprites.Add(sprite);
        _parallaxLayers.Add((layer.transform, sr, parallaxSpeed));
    }

    private void LateUpdate()
    {
        if (_camera == null || _blackVoid == null) return;
        Vector3 cam = _camera.transform.position;
        float camH = _camera.orthographicSize * 2f, camW = camH * _camera.aspect;

        // Fix #25: масштабируем через localScale — 1×1 текстура растягивается до нужного размера.
        _blackVoid.position = new Vector3(cam.x, cam.y, 500f);
        _blackVoid.localScale = new Vector3(camW * GalaxyConstants.BG_VOID_SCALE_FACTOR,
                                             camH * GalaxyConstants.BG_VOID_SCALE_FACTOR, 1f);

        foreach (var (t, sr, speed) in _parallaxLayers)
        {
            t.position = new Vector3(cam.x * (1 - speed) - sr.size.x * 0.5f,
                                     cam.y * (1 - speed) - sr.size.y * 0.5f, t.position.z);
        }
    }
}
