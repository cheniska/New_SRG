using UnityEngine;
using System.Collections.Generic;

// =====================================================================
// ShipTrajectory.cs
//
// МОДЕЛЬ: плавная кубическая кривая Безье с инерцией курса.
//
// Кривая строится через 4 точки:
//   P0 = from
//   P1 = from + forward(heading) * tension  — корабль "вылетает" по своему курсу
//   P2 = to   - forward(toDir)  * tension   — и "приходит" со стороны цели
//   P3 = to
//
// tension зависит от расстояния: чем дальше цель — тем длиннее "рукоятки".
// Это даёт естественную S-кривую при любом угле поворота и почти прямую
// когда цель впереди.
//
// Для цели СЗАДИ (угол > 90°): tension автоматически увеличивается,
// кривая делает широкую петлю — корабль сначала летит вперёд, разворачивается
// и идёт к цели. Никаких полных кругов и изломов.
//
// ПЛОТНОСТЬ ТОЧЕК:
//   Кривая сэмплируется равномерно по длине дуги (не по параметру t).
//   PathRenderer получает готовую цепочку с preSampled=true.
// =====================================================================

public static class ShipTrajectory
{
    // ── Настройки ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Базовый коэффициент tension — доля расстояния до цели для длины "рукояток" Безье.
    /// 0.4 = умеренный изгиб. Увеличь для более широких петель.
    /// </summary>
    public static float TensionFactor = 0.4f;

    /// <summary>
    /// Дополнительный коэффициент tension для цели сзади.
    /// Когда цель позади (dot < 0), tension умножается на это значение — петля становится шире.
    /// </summary>
    public static float BackwardTensionMult = 1.2f;

    /// <summary>Расстояние между соседними точками траектории (мировые единицы).</summary>
    public static float StepSize = 0.15f;

    /// <summary>Число сегментов для оценки длины кривой (точность сэмплирования).</summary>
    private static int LengthSamples = 64;

    /// <summary>Отступ от звезды при обходе.</summary>
    public const float StarAvoidMargin = 0.4f;

    private const float MinDist = 0.001f;

    // ── PUBLIC API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Строит плавную кривую Безье от from до to с учётом текущего курса heading.
    /// heading = float.NaN означает курс неизвестен — строится прямая.
    /// Если прямая пересекает звезду — добавляется промежуточная точка обхода.
    /// Возвращает список точек для ShipMoveStep (BezierWaypoints).
    /// </summary>
    public static List<Vector2> BuildPath(
        Vector2 from, Vector2 to,
        float heading,
        Vector2 starPos, float starRadius)
    {
        var result = new List<Vector2>(128);
        float avoidR = starRadius > 0f ? starRadius + StarAvoidMargin : 0f;

        if (avoidR > 0f && SegmentIntersectsCircle(from, to, starPos, avoidR))
        {
            // Обход звезды: разбиваем на два сегмента через промежуточную точку.
            Vector2 mid = ComputeAvoidWaypoint(from, to, starPos, avoidR);
            float h1 = BuildBezierSegment(from, mid, heading, result);
            BuildBezierSegment(mid, to, h1, result);
        }
        else
        {
            BuildBezierSegment(from, to, heading, result);
        }

        return result;
    }

    // ── Один сегмент кубической Безье ────────────────────────────────────────

    /// <summary>
    /// Строит кубическую кривую Безье from→to и добавляет равномерные точки в output.
    /// Возвращает heading по направлению прибытия (для стыковки следующего сегмента).
    /// </summary>
    private static float BuildBezierSegment(
        Vector2 from, Vector2 to,
        float heading, List<Vector2> output)
    {
        Vector2 delta = to - from;
        float dist = delta.magnitude;
        if (dist < MinDist) { output.Add(to); return heading; }

        float targetHeading = Mathf.Atan2(delta.y, delta.x);

        // Курс неизвестен — строим как слабую Безье без инерции
        if (float.IsNaN(heading))
        {
            Vector2 d33 = delta * 0.33f;
            SampleBezier(from, from + d33, to - d33, to, output);
            return targetHeading;
        }

        Vector2 forward = new Vector2(Mathf.Cos(heading), Mathf.Sin(heading));
        Vector2 toDir = delta.normalized;
        float dot = Vector2.Dot(forward, toDir);

        // tension: базовый — доля расстояния
        float tension = dist * TensionFactor;

        // Цель сзади — увеличиваем tension для широкой плавной петли
        if (dot < 0f)
        {
            float backFactor = Mathf.Lerp(1f, BackwardTensionMult, -dot);
            tension *= backFactor;
        }

        // P1: вылетаем по текущему курсу
        Vector2 p1 = from + forward * tension;
        // P2: заходим к цели против направления движения к ней
        Vector2 p2 = to - toDir * tension;

        SampleBezier(from, p1, p2, to, output);
        return targetHeading;
    }

    // ── Сэмплирование кривой Безье равномерно по длине ───────────────────────

    private static void SampleBezier(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3,
        List<Vector2> output)
    {
        // Оцениваем длину кривой
        float totalLength = 0f;
        Vector2 prev = p0;
        for (int i = 1; i <= LengthSamples; i++)
        {
            Vector2 pt = EvalBezier(p0, p1, p2, p3, (float)i / LengthSamples);
            totalLength += Vector2.Distance(prev, pt);
            prev = pt;
        }

        if (totalLength < MinDist) { output.Add(p3); return; }

        int count = Mathf.Max(1, Mathf.RoundToInt(totalLength / StepSize));
        float accumulated = 0f;
        prev = p0;
        int outputted = 0;

        for (int i = 1; i <= LengthSamples; i++)
        {
            float t = (float)i / LengthSamples;
            Vector2 pt = EvalBezier(p0, p1, p2, p3, t);
            float segLen = Vector2.Distance(prev, pt);
            accumulated += segLen;

            while (outputted < count && accumulated >= (outputted + 1f) * totalLength / count)
            {
                float targetDist = (outputted + 1f) * totalLength / count;
                float ratio = segLen > MinDist
                    ? 1f - (accumulated - targetDist) / segLen
                    : 1f;
                output.Add(Vector2.Lerp(prev, pt, Mathf.Clamp01(ratio)));
                outputted++;
            }

            prev = pt;
        }

        if (outputted == 0 || Vector2.Distance(output[output.Count - 1], p3) > MinDist)
            output.Add(p3);
    }

    private static Vector2 EvalBezier(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3, float t)
    {
        float u = 1f - t;
        return u * u * u * p0
             + 3f * u * u * t * p1
             + 3f * u * t * t * p2
             + t * t * t * p3;
    }

    // ── Утилиты ───────────────────────────────────────────────────────────────

    public static float NormalizeAngle(float a)
    {
        while (a > Mathf.PI) a -= 2f * Mathf.PI;
        while (a < -Mathf.PI) a += 2f * Mathf.PI;
        return a;
    }

    public static bool SegmentIntersectsCircle(Vector2 a, Vector2 b, Vector2 center, float radius)
    {
        Vector2 d = b - a;
        Vector2 f = a - center;
        float A = Vector2.Dot(d, d);
        float B = 2f * Vector2.Dot(f, d);
        float C = Vector2.Dot(f, f) - radius * radius;
        float disc = B * B - 4f * A * C;
        if (disc < 0f) return false;
        float sq = Mathf.Sqrt(disc);
        float t1 = (-B - sq) / (2f * A);
        float t2 = (-B + sq) / (2f * A);
        return (t1 >= 0f && t1 <= 1f) || (t2 >= 0f && t2 <= 1f) || (t1 < 0f && t2 > 1f);
    }

    private static Vector2 ComputeAvoidWaypoint(Vector2 from, Vector2 to, Vector2 starPos, float avoidRadius)
    {
        Vector2 d = (to - from).normalized;
        Vector2 perp = new Vector2(-d.y, d.x);
        float proj = Mathf.Clamp(Vector2.Dot(starPos - from, d), 0f, (to - from).magnitude);
        Vector2 closest = from + d * proj;
        float side = Vector2.Dot(starPos - closest, perp) >= 0f ? -1f : 1f;
        return closest + perp * (side * avoidRadius * 1.2f);
    }
}

public class PathRenderer : MonoBehaviour
{
    [Header("Dots")]
    [SerializeField] private float dotSpacing = 0.18f;
    [SerializeField] private float dotSize = 0.10f;
    [SerializeField] private float markerSize = 0.16f;
    [SerializeField] private int texResolution = 32;

    [Header("Bezier")]
    [Tooltip("Коэффициент изгиба относительно длины шага. 0 = прямая линия.")]
    [SerializeField] private float bezierCurveFactor = 0.35f;
    [SerializeField] private int bezierSegments = 60;

    [Header("Colors")]
    [SerializeField] private Color colorGreen = new Color(0.2f, 0.9f, 0.3f, 1f);
    [SerializeField] private Color colorOrange = new Color(1.0f, 0.55f, 0.1f, 1f);

    [Header("Sorting")]
    [SerializeField] private string sortingLayerName = "Default";

    [Header("Day Label")]
    [SerializeField] private int labelFontSize = 14;
    [SerializeField] private Color labelColor = Color.white;

    private Sprite _spriteGreen;
    private Sprite _spriteOrange;
    private readonly List<GameObject> _pool = new();
    private readonly List<GameObject> _active = new();
    private GameObject _labelObj;
    private TextMesh _labelMesh;

    // Perf-D: переиспользуемые буферы для расчёта кривой Безье.
    // Ресайзятся при необходимости, не пересоздаются каждый DrawPath.
    private Vector2[] _bezierBuffer = new Vector2[61];
    private float[] _cumLenBuffer = new float[61];

    private Vector2[] GetBezierBuffer(int size)
    {
        if (_bezierBuffer.Length < size) _bezierBuffer = new Vector2[size];
        return _bezierBuffer;
    }

    private float[] GetCumLenBuffer(int size)
    {
        if (_cumLenBuffer.Length < size) _cumLenBuffer = new float[size];
        return _cumLenBuffer;
    }

    private void Awake()
    {
        _spriteGreen = CreateCircleSprite(colorGreen, texResolution);
        _spriteOrange = CreateCircleSprite(colorOrange, texResolution);

        // Perf-D: инициализируем буферы заранее под ожидаемый размер
        int bufSize = bezierSegments + 1;
        _bezierBuffer = new Vector2[bufSize];
        _cumLenBuffer = new float[bufSize];

        _labelObj = new GameObject("PathDaysLabel");
        _labelObj.transform.SetParent(transform, false);
        _labelMesh = _labelObj.AddComponent<TextMesh>();
        _labelMesh.fontSize = labelFontSize;
        _labelMesh.color = labelColor;
        _labelMesh.anchor = TextAnchor.MiddleCenter;
        _labelMesh.alignment = TextAlignment.Center;
        _labelMesh.characterSize = 0.1f;

        var mr = _labelObj.GetComponent<MeshRenderer>();
        mr.sortingLayerName = sortingLayerName;
        mr.sortingOrder = SortingLayerRegistry.Offset(SortLayer.PathDot, 1);
        _labelObj.SetActive(false);
    }

    private void OnDestroy()
    {
        Destroy(_spriteGreen?.texture); Destroy(_spriteGreen);
        Destroy(_spriteOrange?.texture); Destroy(_spriteOrange);
    }

    // chain[0] = текущая позиция, chain[1..] = путевые точки.
    // Если preSampled=true — chain уже содержит плотные сэмплы кривой Безье,
    // Catmull-Rom изгиб не применяется (точки соединяются прямыми отрезками).
    public void DrawPath(List<Vector2> chain, float stepPerTurn, bool preSampled = false)
    {
        ReturnAllToPool();
        if (chain == null || chain.Count < 2) { _labelObj.SetActive(false); return; }

        float globalDist = 0f;
        for (int i = 1; i < chain.Count; i++) globalDist += Vector2.Distance(chain[i - 1], chain[i]);
        int totalDays = stepPerTurn > 0f ? Mathf.Max(1, Mathf.CeilToInt(globalDist / stepPerTurn)) : 1;

        float distSoFar = 0f;

        if (preSampled)
        {
            // Цепочка уже является кривой — рисуем точки прямо по ней без доп. изгиба.
            for (int seg = 1; seg < chain.Count; seg++)
            {
                Vector2 p = chain[seg - 1], pNext = chain[seg];
                DrawSegment(p, p, pNext, pNext, Vector2.Distance(p, pNext), stepPerTurn,
                    ref distSoFar, totalDays, isLastSegment: seg == chain.Count - 1);
            }
        }
        else
        {
            // Catmull-Rom касательные. alpha=0.5, масштаб по stepPerTurn.
            float tangentScale = bezierCurveFactor * stepPerTurn;
            var tangents = new Vector2[chain.Count];
            for (int i = 0; i < chain.Count; i++)
            {
                Vector2 prev = i > 0 ? chain[i - 1] : chain[0] - (chain[1] - chain[0]);
                Vector2 next = i < chain.Count - 1 ? chain[i + 1] : chain[^1] + (chain[^1] - chain[^2]);
                tangents[i] = (next - prev) * 0.5f * tangentScale;
            }

            for (int seg = 1; seg < chain.Count; seg++)
            {
                Vector2 p0 = chain[seg - 1], p3 = chain[seg];
                Vector2 ctrl1 = p0 + tangents[seg - 1] / 3f;
                Vector2 ctrl2 = p3 - tangents[seg] / 3f;
                DrawSegment(p0, ctrl1, ctrl2, p3, Vector2.Distance(p0, p3), stepPerTurn,
                    ref distSoFar, totalDays, isLastSegment: seg == chain.Count - 1);
            }
        }

        PlaceDot(chain[^1], _spriteGreen, markerSize);
        ShowLabel(chain[^1], totalDays);
    }

    public void ClearPath() { ReturnAllToPool(); _labelObj.SetActive(false); }

    private void DrawSegment(Vector2 p0, Vector2 ctrl1, Vector2 ctrl2, Vector2 p3,
        float segLen, float stepPerTurn, ref float distSoFar, int totalDays, bool isLastSegment)
    {
        if (segLen < 0.001f) return;

        int count = bezierSegments + 1;
        var curve = GetBezierBuffer(count);
        var cumLen = GetCumLenBuffer(count);
        BuildCubicBezier(p0, ctrl1, ctrl2, p3, bezierSegments, curve);
        BuildCumLengths(curve, count, cumLen);
        float localTraveled = 0f;

        while (localTraveled < segLen - 0.001f)
        {
            float globalTraveled = distSoFar + localTraveled;
            int day = stepPerTurn > 0f ? Mathf.FloorToInt(globalTraveled / stepPerTurn) : 0;
            float dayEndDist = stepPerTurn * (day + 1);

            float distToBound = dayEndDist - globalTraveled;

            Sprite dotSprite = day == 0 ? _spriteGreen : _spriteOrange;
            if (distToBound < dotSpacing * 0.5f && !isLastSegment) dotSprite = _spriteGreen;

            PlaceDot(SampleCurve(curve, cumLen, count, localTraveled / segLen), dotSprite, dotSize);

            if (distToBound > 0f && distToBound <= dotSpacing && day < totalDays - 1)
            {
                float boundLocal = localTraveled + distToBound;
                if (boundLocal < segLen)
                    PlaceDot(SampleCurve(curve, cumLen, count, boundLocal / segLen), _spriteGreen, markerSize);
            }
            localTraveled += dotSpacing;
        }
        distSoFar += segLen;
    }

    private static void BuildCubicBezier(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3,
        int segs, Vector2[] buffer)
    {
        for (int i = 0; i <= segs; i++)
        {
            float t = (float)i / segs, t1 = 1f - t;
            buffer[i] = t1 * t1 * t1 * p0 + 3f * t1 * t1 * t * p1 + 3f * t1 * t * t * p2 + t * t * t * p3;
        }
    }

    private static void BuildCumLengths(Vector2[] curve, int count, float[] cumLen)
    {
        cumLen[0] = 0f;
        for (int i = 1; i < count; i++) cumLen[i] = cumLen[i - 1] + Vector2.Distance(curve[i - 1], curve[i]);
    }

    private static Vector2 SampleCurve(Vector2[] curve, float[] cumLen, int count, float t)
    {
        float total = cumLen[count - 1];
        float target = Mathf.Clamp(t * total, 0f, total);
        int lo = 0, hi = count - 1;
        while (lo < hi - 1) { int mid = (lo + hi) / 2; if (cumLen[mid] < target) lo = mid; else hi = mid; }
        float segLen = cumLen[hi] - cumLen[lo];
        return segLen < 0.00001f ? curve[lo] : Vector2.Lerp(curve[lo], curve[hi], (target - cumLen[lo]) / segLen);
    }

    private void ShowLabel(Vector2 pos, int days)
    {
        _labelMesh.text = days.ToString();
        _labelObj.transform.position = new Vector3(pos.x + 0.25f, pos.y + 0.25f, 0f);
        _labelObj.SetActive(true);
    }

    private void PlaceDot(Vector2 worldPos, Sprite sprite, float size)
    {
        var obj = GetFromPool();
        obj.transform.position = new Vector3(worldPos.x, worldPos.y, 0f);
        obj.transform.localScale = Vector3.one * size;
        var sr = obj.GetComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.sortingLayerName = sortingLayerName;
        sr.sortingOrder = SortingLayerRegistry.Get(SortLayer.PathDot);
        obj.SetActive(true);
        _active.Add(obj);
    }

    private GameObject GetFromPool()
    {
        if (_pool.Count > 0) { var obj = _pool[^1]; _pool.RemoveAt(_pool.Count - 1); return obj; }
        return CreateDotObject();
    }

    private void ReturnAllToPool() { foreach (var obj in _active) { obj.SetActive(false); _pool.Add(obj); } _active.Clear(); }

    private GameObject CreateDotObject()
    {
        var obj = new GameObject("PathDot");
        obj.transform.SetParent(transform, worldPositionStays: false);
        obj.AddComponent<SpriteRenderer>();
        obj.SetActive(false);
        return obj;
    }

    private Sprite CreateCircleSprite(Color color, int res)
    {
        var tex = new Texture2D(res, res, TextureFormat.RGBA32, mipChain: false);
        tex.filterMode = FilterMode.Bilinear;
        float center = res * 0.5f, radius = center - 1f;
        var pixels = new Color[res * res];
        for (int y = 0; y < res; y++)
            for (int x = 0; x < res; x++)
            {
                float dx = x - center + 0.5f, dy = y - center + 0.5f;
                float alpha = Mathf.Clamp01(radius - Mathf.Sqrt(dx * dx + dy * dy));
                pixels[y * res + x] = new Color(color.r, color.g, color.b, color.a * alpha);
            }
        tex.SetPixels(pixels); tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, res, res), new Vector2(0.5f, 0.5f), pixelsPerUnit: res);
    }
}