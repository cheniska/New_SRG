﻿using UnityEngine;

// =====================================================================
// RadarRangeIndicator.cs
// Отображает радиус радара пунктирным кольцом в мировых координатах
// когда курсор мыши наведён на любой объект с коллайдером в сцене.
//
// Установка:
//   Добавить компонент на любой постоянный GameObject в сцене
//   (например на тот же объект где PlayerShip или SystemViewManager).
//   Никаких дополнительных ссылок не нужно — всё берётся через синглтоны.
//
// Принцип работы:
//   - Каждый кадр Physics2D.Raycast по позиции мыши.
//   - Если попали в коллайдер — показываем кольцо, иначе скрываем.
//   - Кольцо рисуется пулом SpriteRenderer-точек (как PathRenderer).
//   - Центр кольца = позиция корабля игрока.
//   - Радиус = EquipmentSystem.GetRadarRange(ship).
//   - Пунктир: чередование видимых и невидимых точек через шаг.
// =====================================================================

[DefaultExecutionOrder(100)] // после PlayerShip
public class RadarRangeIndicator : MonoBehaviour
{
    [Header("Внешний вид")]
    [Tooltip("Цвет пунктирного кольца.")]
    public Color RingColor = new Color(1f, 0.92f, 0.2f, 0.55f);

    [Tooltip("Размер одной точки пунктира в мировых единицах.")]
    public float DotSize = 0.06f;

    [Tooltip("Угловой шаг между точками (градусы). Меньше = гуще.")]
    public float DotAngularStep = 4f;

    [Tooltip("Доля видимых точек в пунктире. 0.5 = каждая вторая.")]
    [Range(0.1f, 0.9f)]
    public float DashRatio = 0.5f;

    [Tooltip("Название слоя сортировки (должно совпадать с PathRenderer.sortingLayerName).")]
    public string SortingLayerName = "Default";

    [Tooltip("Порядок сортировки внутри слоя.")]
    public int SortingOrder = 26; // чуть выше PathDot (25)

    // ── Runtime ───────────────────────────────────────────────────────────────

    private Camera _cam;
    private Sprite _dotSprite;
    private GameObject _ringRoot;
    private SpriteRenderer[] _dots;
    private int _dotCount;
    private bool _isVisible;

    // ── Unity lifecycle ───────────────────────────────────────────────────────

    private void Start()
    {
        _cam = Camera.main;
        _dotSprite = CreateCircleSprite();
        _ringRoot = new GameObject("RadarRingIndicator");
        _ringRoot.transform.SetParent(null); // в корне сцены
        _ringRoot.SetActive(false);
    }

    private void OnDestroy()
    {
        if (_ringRoot != null) Destroy(_ringRoot);
        if (_dotSprite != null) { Destroy(_dotSprite.texture); Destroy(_dotSprite); }
    }

    private void Update()
    {
        // Не показываем во время анимации хода
        if (GalaxyManager.Instance?.Phase == TurnPhase.Animating)
        {
            SetVisible(false);
            return;
        }

        // Нет игрока — нечего показывать
        var ship = PlayerShip.Instance?.ShipData;
        if (ship == null) { SetVisible(false); return; }

        float radarRange = EquipmentSystem.GetRadarRange(ship);
        if (radarRange <= 0f) { SetVisible(false); return; }

        // Мышь над UI — не показываем
        if (SystemMinimapController.IsMouseOverMinimap)
        { SetVisible(false); return; }

        // Raycast мыши в мировых координатах
        Vector2 mouseWorld = _cam.ScreenToWorldPoint(Input.mousePosition);
        var hit = Physics2D.Raycast(mouseWorld, Vector2.zero);
        bool overObject = hit.collider != null;

        if (!overObject)
        {
            SetVisible(false);
            return;
        }

        // Центр кольца — позиция корабля игрока
        Vector2 center = PlayerShip.Instance.transform.position;
        ShowRing(center, radarRange);
    }

    // ── Рисование кольца ──────────────────────────────────────────────────────

    private void ShowRing(Vector2 center, float radius)
    {
        int needed = Mathf.RoundToInt(360f / DotAngularStep);
        RebuildPoolIfNeeded(needed);

        _ringRoot.SetActive(true);
        _isVisible = true;

        // Шаг видимости: каждые N точек одна видима, остальные — нет
        // DashRatio = 0.5 → видима каждая вторая
        float dashPeriod = 1f / Mathf.Max(0.01f, DashRatio);

        for (int i = 0; i < _dotCount; i++)
        {
            float angleDeg = i * DotAngularStep;
            float angleRad = angleDeg * Mathf.Deg2Rad;
            Vector2 pos = center + new Vector2(Mathf.Cos(angleRad), Mathf.Sin(angleRad)) * radius;

            var sr = _dots[i];
            sr.transform.position = new Vector3(pos.x, pos.y, 0f);

            // Пунктир: точка видима если (i % dashPeriod) < dashPeriod * DashRatio
            bool dash = (i % dashPeriod) < (dashPeriod * DashRatio);
            sr.enabled = dash;
        }
    }

    private void SetVisible(bool visible)
    {
        if (_isVisible == visible) return;
        _isVisible = visible;
        if (_ringRoot != null) _ringRoot.SetActive(visible);
    }

    // ── Пул точек ─────────────────────────────────────────────────────────────

    private void RebuildPoolIfNeeded(int needed)
    {
        if (_dots != null && _dotCount == needed) return;

        // Уничтожаем старые
        if (_dots != null)
            foreach (var d in _dots)
                if (d != null) Destroy(d.gameObject);

        _dotCount = needed;
        _dots = new SpriteRenderer[_dotCount];

        for (int i = 0; i < _dotCount; i++)
        {
            var go = new GameObject($"RDot_{i}");
            go.transform.SetParent(_ringRoot.transform, false);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _dotSprite;
            sr.color = RingColor;
            sr.sortingLayerName = SortingLayerName;
            sr.sortingOrder = SortingOrder;
            go.transform.localScale = Vector3.one * DotSize;
            _dots[i] = sr;
        }
    }

    // ── Спрайт точки ──────────────────────────────────────────────────────────

    private static Sprite CreateCircleSprite()
    {
        const int res = 16;
        var tex = new Texture2D(res, res, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        float c = res * 0.5f, r = c - 0.5f;
        var pixels = new Color[res * res];
        for (int y = 0; y < res; y++)
            for (int x = 0; x < res; x++)
            {
                float dx = x - c + 0.5f, dy = y - c + 0.5f;
                float alpha = Mathf.Clamp01(r - Mathf.Sqrt(dx * dx + dy * dy));
                pixels[y * res + x] = new Color(1f, 1f, 1f, alpha);
            }
        tex.SetPixels(pixels);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, res, res), new Vector2(0.5f, 0.5f), res);
    }
}