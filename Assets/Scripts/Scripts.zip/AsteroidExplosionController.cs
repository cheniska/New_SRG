using UnityEngine;

// =====================================================================
// AsteroidExplosionController.cs
// Визуальная анимация взрыва астероида — однократное воспроизведение спрайтлиста.
//
// Спрайтлист загружается из GalaxyConstants.EXPLOSION_SPRITE_PATH
// (по умолчанию "Graphics/Explosions/Asteroids", задаётся в GameSettingsConfig).
// Спрайты в папке нумеруются так, чтобы сортировались по алфавиту:
//   0001.png, 0002.png, … или frame_001.png, frame_002.png, …
//
// Цветовых акцентов нет — анимация воспроизводится нейтрально (Color.white).
//
// Жизненный цикл:
//   1. SystemViewManager.SpawnExplosionEffect() создаёт GameObject
//   2. Вызывает Play()
//   3. После последнего кадра объект уничтожает себя.
// =====================================================================

public class AsteroidExplosionController : MonoBehaviour
{
    // ── Runtime ───────────────────────────────────────────────────────────────
    private SpriteRenderer _sr;
    private Sprite[] _frames;
    private float _secPerFrame;
    private float _timer;
    private int _curFrame;
    private bool _playing;

    // Кэш фреймов. Ключ — полный путь (папка или файл).
    // Не readonly — может быть инвалидирован если путь из конфига изменился.
    private static System.Collections.Generic.Dictionary<string, Sprite[]>
        _cache = new System.Collections.Generic.Dictionary<string, Sprite[]>();

    // Последний закешированный путь — для инвалидации при смене конфига.
    private static string _lastKnownPath;

    // ── Public API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Запускает однократное воспроизведение анимации взрыва.
    /// Ищет спрайтлист по пути GalaxyConstants.EXPLOSION_SPRITE_PATH.
    ///
    /// Поддерживает два формата содержимого папки:
    ///   1. Спрайтлист: любой .png + рядом .png.json с метой (FrameCount, Cols, Rows).
    ///      Нарезается через GraphicsManager — тот же путь что и у астероидов.
    ///   2. Отдельные спрайты: 0001.png, 0002.png, … — загружаются напрямую.
    /// </summary>
    public void Play()
    {
        EnsureRenderer();

        // Берём путь и параметры напрямую из Settings — единственный источник истины.
        // GalaxyConstants используется как fallback если Settings недоступен.
        var settings = GalaxyManager.Instance?.Settings;
        string path = (settings != null && !string.IsNullOrEmpty(settings.ExplosionSpritePath))
            ? settings.ExplosionSpritePath
            : GalaxyConstants.EXPLOSION_SPRITE_PATH;
        float fps = settings != null && settings.ExplosionFPS > 0f
            ? settings.ExplosionFPS
            : GalaxyConstants.EXPLOSION_FPS;
        float scale = settings != null && settings.ExplosionScale > 0f
            ? settings.ExplosionScale
            : GalaxyConstants.EXPLOSION_SCALE;

        _sr.color = Color.white;
        transform.localScale = Vector3.one * scale;
        _sr.sortingOrder = SortingLayerRegistry.Get(SortLayer.HelperOverlay);

        // Инвалидируем кеш если путь изменился
        if (path != _lastKnownPath)
        {
            _cache.Clear();
            _lastKnownPath = path;
        }

        _frames = LoadFrames(path, fps);

        if (_frames != null && _frames.Length > 0)
        {
            _sr.sprite = _frames[0];
            _secPerFrame = fps > 0f ? 1f / fps : 1f / 12f;
        }
        else
        {
            Debug.LogWarning($"[AsteroidExplosionController] No explosion sprites at '{path}' — using procedural fallback.");
            _sr.sprite = CreateCircleFallback();
            _frames = new[] { _sr.sprite };
            _secPerFrame = 0.4f;
        }

        _curFrame = 0;
        _timer = 0f;
        _playing = true;
    }

    // ── Unity ─────────────────────────────────────────────────────────────────

    private void Update()
    {
        if (!_playing) return;
        _timer += Time.deltaTime;

        if (_timer < _secPerFrame) return;

        int advance = Mathf.FloorToInt(_timer / _secPerFrame);
        _timer %= _secPerFrame;
        _curFrame += advance;

        if (_curFrame >= _frames.Length)
        {
            _playing = false;
            Destroy(gameObject);
            return;
        }

        _sr.sprite = _frames[_curFrame];
    }

    // ── Loader ────────────────────────────────────────────────────────────────

    /// <summary>
    /// Загружает фреймы взрыва из папки folderPath (берётся из GalaxyConstants.EXPLOSION_SPRITE_PATH).
    ///
    /// Алгоритм поиска:
    ///   1. Кэш по ключу folderPath.
    ///   2. Ищем в папке TextAsset с именем, оканчивающимся на ".png"
    ///      (это json-мета спрайтлиста, Unity видит его как "001.png").
    ///      Если нашли — строим полный путь "папка/001" и грузим через GraphicsManager.
    ///   3. Fallback: Resources.LoadAll<Sprite>(folderPath) — отдельные спрайты в папке.
    /// </summary>
    private static Sprite[] LoadFrames(string folderPath, float fps)
    {
        if (string.IsNullOrEmpty(folderPath)) return null;

        if (_cache.TryGetValue(folderPath, out var cached)) return cached;

        Sprite[] result = null;

        // ── Вариант 1: спрайтлист (texture + .png.json мета) ─────────────────
        // Resources видит "001.png.json" как TextAsset с именем "001.png"
        if (GraphicsManager.Instance != null)
        {
            var textAssets = Resources.LoadAll<TextAsset>(folderPath);
            foreach (var ta in textAssets)
            {
                if (!ta.name.EndsWith(".png", System.StringComparison.OrdinalIgnoreCase)) continue;
                // Имя текстуры = имя ассета без суффикса ".png" → "001"
                string texName = ta.name.Substring(0, ta.name.Length - 4);
                string sheetPath = folderPath + "/" + texName;

                var (frames, _) = GraphicsManager.Instance.GetAsteroidVisuals(sheetPath, fps);
                if (frames != null && frames.Length > 0)
                {
                    result = frames;
                    Debug.Log($"[AsteroidExplosionController] Loaded spritesheet '{sheetPath}': {frames.Length} frames.");
                    break;
                }
            }
        }

        // ── Вариант 2: отдельные спрайты ─────────────────────────────────────
        if (result == null)
        {
            var sprites = Resources.LoadAll<Sprite>(folderPath);
            if (sprites != null && sprites.Length > 0)
            {
                System.Array.Sort(sprites, (a, b) =>
                    string.Compare(a.name, b.name, System.StringComparison.OrdinalIgnoreCase));
                result = sprites;
                Debug.Log($"[AsteroidExplosionController] Loaded {sprites.Length} sprites from '{folderPath}'.");
            }
        }

        if (result == null)
            Debug.LogWarning($"[AsteroidExplosionController] No sprites found at '{folderPath}'. " +
                             $"Put a spritesheet (texture + .png.json) or numbered sprites there.");

        // Кэшируем только успешный результат — null не кэшируем,
        // чтобы повторная попытка сработала если GraphicsManager ещё не был готов.
        if (result != null)
            _cache[folderPath] = result;

        return result;
    }

    private void EnsureRenderer()
    {
        if (!TryGetComponent(out _sr))
            _sr = gameObject.AddComponent<SpriteRenderer>();
    }

    /// <summary>Процедурный кружок-заглушка если спрайты не найдены.</summary>
    private static Sprite CreateCircleFallback()
    {
        const int res = 32;
        var tex = new Texture2D(res, res, TextureFormat.RGBA32, false);
        var pixels = new Color[res * res];
        float c = res * 0.5f, r = c - 1f;
        for (int y = 0; y < res; y++)
            for (int x = 0; x < res; x++)
            {
                float dx = x - c + 0.5f, dy = y - c + 0.5f;
                float a = Mathf.Clamp01(r - Mathf.Sqrt(dx * dx + dy * dy));
                pixels[y * res + x] = new Color(1f, 1f, 1f, a);
            }
        tex.SetPixels(pixels);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, res, res), new Vector2(0.5f, 0.5f), res);
    }
}