using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;

// ── MenuController ────────────────────────────────────────────────────────────
//
// Управляет главным меню и меню настроек через UI Toolkit (UXML + USS).
//
// Структура файлов (все в Assets/UI/):
//   MainMenu.uxml        — разметка главного меню
//   SettingsMenu.uxml    — разметка меню настроек
//   MenuStyles.uss       — общие стили
//
// Настройка сцены:
//   1. Создать сцену MainMenu (Build Index 0).
//   2. Создать GameObject "MenuController".
//   3. Добавить компонент UIDocument, в Source Asset указать MainMenu.uxml.
//   4. Добавить этот скрипт на тот же GameObject.
//   5. Назначить все поля в инспекторе.
//
// Поток:
//   Кнопка clicked → OnMenuAction() → SwapDocument() или LoadScene().

[RequireComponent(typeof(UIDocument))]
public class MenuController : MonoBehaviour
{
    // ── Inspector ─────────────────────────────────────────────────────────────

    [Header("References")]
    public GameSettingsConfig GameSettings;

    [Header("UXML Assets")]
    public VisualTreeAsset MainMenuUxml;
    public VisualTreeAsset SettingsMenuUxml;

    [Header("Scene")]
    public string GameSceneName = "GameScene";

    // ── Private ───────────────────────────────────────────────────────────────

    private UIDocument _doc;
    private VisualElement _root;

    private enum MenuState { Main, Settings }
    private MenuState _state = MenuState.Main;

    private SettingsSnapshot _snapshot;

    // Текущие значения настроек в UI (до нажатия Apply)
    private readonly Dictionary<string, object> _currentValues = new();

    // Для перехвата нажатия клавиши при rebind
    private string _rebindingId = null;
    private Label _rebindingLabel = null;

    // ── Unity Lifecycle ───────────────────────────────────────────────────────

    private void Awake()
    {
        _doc = GetComponent<UIDocument>();
        _root = _doc.rootVisualElement;

        if (GameSettings == null)
            Debug.LogError("[MenuController] GameSettings not assigned!");
    }

    private void Start()
    {
        ShowMainMenu();
    }

    private void Update()
    {
        // Перехват любой клавиши во время rebind
        if (_rebindingId == null || !Input.anyKeyDown) return;

        foreach (KeyCode kc in Enum.GetValues(typeof(KeyCode)))
        {
            if (kc == KeyCode.None) continue;
            if (!Input.GetKeyDown(kc)) continue;
            FinishRebind(kc);
            break;
        }
    }

    // ── Навигация ─────────────────────────────────────────────────────────────

    private void ShowMainMenu()
    {
        _state = MenuState.Main;
        SwapDocument(MainMenuUxml);
        BindMainMenu();
        AnimateMenuIn();
    }

    private void ShowSettings()
    {
        _state = MenuState.Settings;
        _snapshot = SettingsSnapshot.Capture(GameSettings);
        SwapDocument(SettingsMenuUxml);
        BuildSettingsRows();
        BindSettingsButtons();
    }

    // Заменяет UXML в UIDocument не перезагружая сцену
    private void SwapDocument(VisualTreeAsset asset)
    {
        _root.Clear();
        asset.CloneTree(_root);
    }

    // ── Главное меню ──────────────────────────────────────────────────────────

    private void BindMainMenu()
    {
        Q<Button>("btn-new-game").clicked += () => OnMenuAction("new_game");
        Q<Button>("btn-settings").clicked += () => OnMenuAction("settings");
        Q<Button>("btn-quit").clicked += () => OnMenuAction("quit");

        // Живые часы в HUD-строке снизу
        var coordsLabel = Q<Label>("hud-coords");
        _root.schedule.Execute(() =>
        {
            coordsLabel.text = $"SYS : MAIN_MENU · {DateTime.Now:HH:mm:ss} · STATUS : STANDBY";
        }).Every(1000);

        // Добавляем кастомный элемент звёздного поля
        var starfield = Q("starfield");
        if (starfield != null)
        {
            var stars = new StarfieldElement();
            starfield.Add(stars);
            stars.StretchToParentSize();
        }
    }

    // Плавное появление логотипа и кнопок со сдвигом (имитация CSS animation-delay)
    private void AnimateMenuIn()
    {
        AnimateFadeSlide(Q("logo"), delayMs: 50);

        var buttons = _root.Query<Button>(className: "menu-btn").ToList();
        for (int i = 0; i < buttons.Count; i++)
            AnimateFadeSlide(buttons[i], delayMs: 150 + i * 80);

        AnimateFadeSlide(Q("hud-corner"), delayMs: 300);
        AnimateFadeSlide(Q("hud-bottom"), delayMs: 400);
    }

    private static void AnimateFadeSlide(VisualElement el, int delayMs)
    {
        if (el == null) return;
        el.style.opacity = 0;
        el.style.translate = new Translate(-24, 0);
        el.schedule.Execute(() =>
        {
            el.style.opacity = 1;
            el.style.translate = new Translate(0, 0);
        }).StartingIn(delayMs);
    }

    // ── Меню настроек: построение строк ──────────────────────────────────────

    private void BuildSettingsRows()
    {
        var scroll = Q<ScrollView>("settings-scroll");
        var content = scroll.contentContainer;
        content.Clear();
        _currentValues.Clear();

        string lastSection = null;

        foreach (var e in MakeSettingEntries())
        {
            _currentValues[e.Id] = e.Value;

            // Заголовок секции при смене группы
            if (e.Section != lastSection)
            {
                lastSection = e.Section;
                var lbl = new Label(e.Section.ToUpper());
                lbl.AddToClassList("section-label");
                content.Add(lbl);
            }

            content.Add(BuildRow(e));
        }
    }

    // Строит одну строку настройки (label + контрол)
    private VisualElement BuildRow(SettingEntry e)
    {
        var row = new VisualElement();
        row.AddToClassList("s-row");

        // Левая часть: название + описание
        var labelBlock = new VisualElement();
        labelBlock.AddToClassList("s-row-label");

        var name = new Label(e.Label);
        name.AddToClassList("s-row-name");
        labelBlock.Add(name);

        if (!string.IsNullOrEmpty(e.Desc))
        {
            var desc = new Label(e.Desc);
            desc.AddToClassList("s-row-desc");
            labelBlock.Add(desc);
        }

        row.Add(labelBlock);
        row.Add(BuildControl(e));
        return row;
    }

    // Выбирает тип контрола
    private VisualElement BuildControl(SettingEntry e) => e.Type switch
    {
        SettingType.Toggle => BuildToggle(e),
        SettingType.Slider => BuildSlider(e),
        SettingType.Select => BuildSelect(e),
        SettingType.KeyBind => BuildKeybind(e),
        _ => new VisualElement()
    };

    // TOGGLE — кастомный трек + ползунок (не стандартный Toggle, чтобы не бороться со стилем)
    private VisualElement BuildToggle(SettingEntry e)
    {
        bool isOn = Convert.ToBoolean(e.Value);

        var track = new VisualElement();
        track.AddToClassList("toggle-track");
        if (isOn) track.AddToClassList("toggle-track--on");

        var thumb = new VisualElement();
        thumb.AddToClassList("toggle-thumb");
        if (isOn) thumb.AddToClassList("toggle-thumb--on");
        track.Add(thumb);

        track.RegisterCallback<ClickEvent>(_ =>
        {
            isOn = !isOn;
            _currentValues[e.Id] = isOn;

            track.EnableInClassList("toggle-track--on", isOn);
            thumb.EnableInClassList("toggle-thumb--on", isOn);
        });

        return track;
    }

    // SLIDER
    private VisualElement BuildSlider(SettingEntry e)
    {
        var wrap = new VisualElement();
        wrap.AddToClassList("s-slider-wrap");

        float initial = Convert.ToSingle(e.Value);
        var slider = new Slider(e.SliderMin, e.SliderMax) { value = initial };
        slider.AddToClassList("s-slider");

        var valLabel = new Label(FmtFloat(initial, e.Decimals));
        valLabel.AddToClassList("s-slider-val");

        slider.RegisterValueChangedCallback(evt =>
        {
            float snapped = Mathf.Round(evt.newValue / e.SliderStep) * e.SliderStep;
            snapped = Mathf.Clamp(snapped, e.SliderMin, e.SliderMax);
            if (Mathf.Abs(snapped - evt.newValue) > 0.0001f)
                slider.SetValueWithoutNotify(snapped);

            _currentValues[e.Id] = snapped;
            valLabel.text = FmtFloat(snapped, e.Decimals);
        });

        wrap.Add(slider);
        wrap.Add(valLabel);
        return wrap;
    }

    // SELECT — стандартный DropdownField UI Toolkit
    private VisualElement BuildSelect(SettingEntry e)
    {
        var choices = new List<string>();
        var values = new List<string>();
        foreach (var opt in e.Options) { choices.Add(opt.Label); values.Add(opt.Value); }

        int curIdx = values.IndexOf(e.Value.ToString());
        var dropdown = new DropdownField(choices, Mathf.Max(0, curIdx));
        dropdown.AddToClassList("s-select");

        dropdown.RegisterValueChangedCallback(evt =>
        {
            int idx = choices.IndexOf(evt.newValue);
            _currentValues[e.Id] = idx >= 0 ? values[idx] : evt.newValue;
        });

        return dropdown;
    }

    // KEYBIND — кнопка-метка, ждёт нажатия клавиши через Update()
    private VisualElement BuildKeybind(SettingEntry e)
    {
        var btn = new Label(e.Value.ToString());
        btn.AddToClassList("keybind-btn");

        btn.RegisterCallback<ClickEvent>(_ =>
        {
            if (_rebindingId != null) return;   // уже слушаем другое поле
            _rebindingId = e.Id;
            _rebindingLabel = btn;
            btn.text = "...";
            btn.AddToClassList("keybind-btn--listening");
        });

        return btn;
    }

    // Фиксирует выбранную клавишу и завершает режим ожидания
    private void FinishRebind(KeyCode kc)
    {
        if (_rebindingLabel == null) return;
        _currentValues[_rebindingId] = kc.ToString();
        _rebindingLabel.text = kc.ToString();
        _rebindingLabel.RemoveFromClassList("keybind-btn--listening");
        _rebindingId = null;
        _rebindingLabel = null;
    }

    // ── Кнопки настроек ───────────────────────────────────────────────────────

    private void BindSettingsButtons()
    {
        Q<Button>("btn-back").clicked += () => OnMenuAction("back");
        Q<Button>("btn-apply").clicked += ApplyAndClose;
    }

    // ── Центральный обработчик действий ───────────────────────────────────────

    public void OnMenuAction(string action)
    {
        switch (action)
        {
            case "new_game":
                SceneManager.LoadScene(GameSceneName);
                break;

            case "settings":
                ShowSettings();
                break;

            case "quit":
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
                break;

            case "back":
                _snapshot?.Restore(GameSettings);
                ShowMainMenu();
                break;

            default:
                Debug.LogWarning($"[MenuController] Unknown action: {action}");
                break;
        }
    }

    private void ApplyAndClose()
    {
        ApplyCurrentValues();
        PersistSettings();
        ShowMainMenu();
    }

    // ── Применение _currentValues → GameSettings ──────────────────────────────

    private void ApplyCurrentValues()
    {
        var gs = GameSettings;
        var v = _currentValues;

        GetBool(v, "EnableEdgeScrolling", x => gs.EnableEdgeScrolling = x);
        GetBool(v, "EnableCentering", x => gs.EnableCentering = x);
        GetFloat(v, "MoveSpeed", x => gs.MoveSpeed = x);
        GetFloat(v, "ZoomSpeed", x => gs.ZoomSpeed = x);
        GetFloat(v, "MinZoom", x => gs.MinZoom = x);
        GetFloat(v, "MaxZoom", x => gs.MaxZoom = x);
        GetFloat(v, "TurnDuration", x => gs.TurnDuration = x);
        GetBool(v, "MovieInterruptOnActionDone", x => gs.MovieInterruptOnActionDone = x);
        GetInt(v, "DragMouseButton", x => gs.DragMouseButton = x);
        GetKeyCode(v, "PausePlayKey", x => gs.PausePlayKey = x);
        GetKeyCode(v, "ResetCameraKey", x => gs.ResetCameraKey = x);
        GetKeyCode(v, "CenterCameraKey", x => gs.CenterCameraKey = x);
        GetKeyCode(v, "MultiWaypointKey", x => gs.MultiWaypointKey = x);
    }

    // ── Список настроек ───────────────────────────────────────────────────────

    private List<SettingEntry> MakeSettingEntries()
    {
        var gs = GameSettings;
        return new List<SettingEntry>
        {
            // Camera
            SE_Toggle ("Camera",   "EnableEdgeScrolling",        "Edge Scrolling",     "Двигать камеру при наведении на край экрана",  gs.EnableEdgeScrolling),
            SE_Toggle ("Camera",   "EnableCentering",            "Center on Player",   "Клавиша C центрирует камеру на корабле",       gs.EnableCentering),
            SE_Slider ("Camera",   "MoveSpeed",                  "Camera Speed",       null, gs.MoveSpeed,   5,    60,  1f,   0),
            SE_Slider ("Camera",   "ZoomSpeed",                  "Zoom Speed",         null, gs.ZoomSpeed,   2,    30,  1f,   0),
            SE_Slider ("Camera",   "MinZoom",                    "Min Zoom",           null, gs.MinZoom,     2,    10,  0.5f, 1),
            SE_Slider ("Camera",   "MaxZoom",                    "Max Zoom",           null, gs.MaxZoom,     10,   50,  1f,   0),
            // Game
            SE_Slider ("Game",     "TurnDuration",               "Turn Duration",      "Длительность анимации хода (сек)", gs.TurnDuration, 0.5f, 6f, 0.5f, 1),
            SE_Toggle ("Game",     "MovieInterruptOnActionDone", "Pause on Route End", "Авто-пауза при завершении маршрута", gs.MovieInterruptOnActionDone),
            // Controls
            SE_Select ("Controls", "DragMouseButton",            "Drag Button",        "Кнопка мыши для перетаскивания камеры",
                gs.DragMouseButton.ToString(),
                new[] { new SelectOption("0","Left"), new SelectOption("1","Right"), new SelectOption("2","Middle") }),
            SE_Key    ("Controls", "PausePlayKey",               "Pause / Play",       null, gs.PausePlayKey.ToString()),
            SE_Key    ("Controls", "ResetCameraKey",             "Reset Camera",       null, gs.ResetCameraKey.ToString()),
            SE_Key    ("Controls", "CenterCameraKey",            "Center Camera",      null, gs.CenterCameraKey.ToString()),
            SE_Key    ("Controls", "MultiWaypointKey",           "Multi-Waypoint",     "Удерживать для цепочки путевых точек", gs.MultiWaypointKey.ToString()),
        };
    }

    // ── Сохранение / загрузка через PlayerPrefs ───────────────────────────────

    private void PersistSettings()
    {
        var gs = GameSettings;
        PlayerPrefs.SetInt("EnableEdgeScrolling", gs.EnableEdgeScrolling ? 1 : 0);
        PlayerPrefs.SetInt("EnableCentering", gs.EnableCentering ? 1 : 0);
        PlayerPrefs.SetFloat("MoveSpeed", gs.MoveSpeed);
        PlayerPrefs.SetFloat("ZoomSpeed", gs.ZoomSpeed);
        PlayerPrefs.SetFloat("MinZoom", gs.MinZoom);
        PlayerPrefs.SetFloat("MaxZoom", gs.MaxZoom);
        PlayerPrefs.SetFloat("TurnDuration", gs.TurnDuration);
        PlayerPrefs.SetInt("MovieInterruptOnActionDone", gs.MovieInterruptOnActionDone ? 1 : 0);
        PlayerPrefs.SetInt("DragMouseButton", gs.DragMouseButton);
        PlayerPrefs.SetString("PausePlayKey", gs.PausePlayKey.ToString());
        PlayerPrefs.SetString("ResetCameraKey", gs.ResetCameraKey.ToString());
        PlayerPrefs.SetString("CenterCameraKey", gs.CenterCameraKey.ToString());
        PlayerPrefs.SetString("MultiWaypointKey", gs.MultiWaypointKey.ToString());
        PlayerPrefs.Save();
    }

    // Вызывать из GalaxyManager.Awake() один раз.
    public static void LoadSavedSettings(GameSettingsConfig gs)
    {
        if (!PlayerPrefs.HasKey("TurnDuration")) return;   // первый запуск — дефолты

        gs.EnableEdgeScrolling = PlayerPrefs.GetInt("EnableEdgeScrolling", 1) == 1;
        gs.EnableCentering = PlayerPrefs.GetInt("EnableCentering", 1) == 1;
        gs.MoveSpeed = PlayerPrefs.GetFloat("MoveSpeed", gs.MoveSpeed);
        gs.ZoomSpeed = PlayerPrefs.GetFloat("ZoomSpeed", gs.ZoomSpeed);
        gs.MinZoom = PlayerPrefs.GetFloat("MinZoom", gs.MinZoom);
        gs.MaxZoom = PlayerPrefs.GetFloat("MaxZoom", gs.MaxZoom);
        gs.TurnDuration = PlayerPrefs.GetFloat("TurnDuration", gs.TurnDuration);
        gs.MovieInterruptOnActionDone = PlayerPrefs.GetInt("MovieInterruptOnActionDone", 1) == 1;
        gs.DragMouseButton = PlayerPrefs.GetInt("DragMouseButton", gs.DragMouseButton);

        TryParseKey("PausePlayKey", gs.PausePlayKey, kc => gs.PausePlayKey = kc);
        TryParseKey("ResetCameraKey", gs.ResetCameraKey, kc => gs.ResetCameraKey = kc);
        TryParseKey("CenterCameraKey", gs.CenterCameraKey, kc => gs.CenterCameraKey = kc);
        TryParseKey("MultiWaypointKey", gs.MultiWaypointKey, kc => gs.MultiWaypointKey = kc);
    }

    private static void TryParseKey(string pref, KeyCode fallback, Action<KeyCode> set)
    {
        var s = PlayerPrefs.GetString(pref, fallback.ToString());
        if (Enum.TryParse(s, out KeyCode kc)) set(kc);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private T Q<T>(string name) where T : VisualElement => _root.Q<T>(name);
    private VisualElement Q(string name) => _root.Q(name);

    private static string FmtFloat(float v, int dec) =>
        dec == 0 ? Mathf.RoundToInt(v).ToString() : v.ToString("F" + dec);

    private static void GetBool(Dictionary<string, object> d, string k, Action<bool> s) { if (d.TryGetValue(k, out var v)) s(Convert.ToBoolean(v)); }
    private static void GetFloat(Dictionary<string, object> d, string k, Action<float> s) { if (d.TryGetValue(k, out var v)) s(Convert.ToSingle(v)); }
    private static void GetInt(Dictionary<string, object> d, string k, Action<int> s) { if (d.TryGetValue(k, out var v)) s(Convert.ToInt32(v)); }
    private static void GetKeyCode(Dictionary<string, object> d, string k, Action<KeyCode> s)
    { if (d.TryGetValue(k, out var v) && Enum.TryParse(v.ToString(), out KeyCode kc)) s(kc); }

    // Билдеры SettingEntry с короткими именами
    private static SettingEntry SE_Toggle(string sec, string id, string lbl, string desc, bool val)
        => new() { Section = sec, Id = id, Label = lbl, Desc = desc, Type = SettingType.Toggle, Value = val };

    private static SettingEntry SE_Slider(string sec, string id, string lbl, string desc,
        float val, float min, float max, float step, int dec)
        => new()
        {
            Section = sec,
            Id = id,
            Label = lbl,
            Desc = desc,
            Type = SettingType.Slider,
            Value = val,
            SliderMin = min,
            SliderMax = max,
            SliderStep = step,
            Decimals = dec
        };

    private static SettingEntry SE_Select(string sec, string id, string lbl, string desc,
        string val, SelectOption[] opts)
        => new() { Section = sec, Id = id, Label = lbl, Desc = desc, Type = SettingType.Select, Value = val, Options = opts };

    private static SettingEntry SE_Key(string sec, string id, string lbl, string desc, string val)
        => new() { Section = sec, Id = id, Label = lbl, Desc = desc, Type = SettingType.KeyBind, Value = val };
}

// ── SettingsSnapshot ──────────────────────────────────────────────────────────

internal class SettingsSnapshot
{
    private bool EnableEdgeScrolling, EnableCentering, MovieInterruptOnActionDone;
    private float MoveSpeed, ZoomSpeed, MinZoom, MaxZoom, TurnDuration;
    private int DragMouseButton;
    private KeyCode PausePlayKey, ResetCameraKey, CenterCameraKey, MultiWaypointKey;

    public static SettingsSnapshot Capture(GameSettingsConfig gs) => new()
    {
        EnableEdgeScrolling = gs.EnableEdgeScrolling,
        EnableCentering = gs.EnableCentering,
        MovieInterruptOnActionDone = gs.MovieInterruptOnActionDone,
        MoveSpeed = gs.MoveSpeed,
        ZoomSpeed = gs.ZoomSpeed,
        MinZoom = gs.MinZoom,
        MaxZoom = gs.MaxZoom,
        TurnDuration = gs.TurnDuration,
        DragMouseButton = gs.DragMouseButton,
        PausePlayKey = gs.PausePlayKey,
        ResetCameraKey = gs.ResetCameraKey,
        CenterCameraKey = gs.CenterCameraKey,
        MultiWaypointKey = gs.MultiWaypointKey,
    };

    public void Restore(GameSettingsConfig gs)
    {
        gs.EnableEdgeScrolling = EnableEdgeScrolling;
        gs.EnableCentering = EnableCentering;
        gs.MovieInterruptOnActionDone = MovieInterruptOnActionDone;
        gs.MoveSpeed = MoveSpeed;
        gs.ZoomSpeed = ZoomSpeed;
        gs.MinZoom = MinZoom;
        gs.MaxZoom = MaxZoom;
        gs.TurnDuration = TurnDuration;
        gs.DragMouseButton = DragMouseButton;
        gs.PausePlayKey = PausePlayKey;
        gs.ResetCameraKey = ResetCameraKey;
        gs.CenterCameraKey = CenterCameraKey;
        gs.MultiWaypointKey = MultiWaypointKey;
    }
}

// ── SettingEntry ──────────────────────────────────────────────────────────────

internal enum SettingType { Toggle, Slider, Select, KeyBind }

internal class SettingEntry
{
    public string Section;
    public string Id;
    public string Label;
    public string Desc;
    public SettingType Type;
    public object Value;
    public float SliderMin, SliderMax, SliderStep;
    public int Decimals;
    public SelectOption[] Options;
}

internal class SelectOption
{
    public string Value;
    public string Label;
    public SelectOption(string v, string l) { Value = v; Label = l; }
}

// ── StarfieldElement ──────────────────────────────────────────────────────────
// Кастомный VisualElement — рисует мерцающие звёзды через Painter2D.
// Добавляется программно в элемент name="starfield" в BindMainMenu().

public class StarfieldElement : VisualElement
{
    private struct Star { public float X, Y, R, Phase, Speed; }

    private const int Count = 240;
    private readonly Star[] _stars = new Star[Count];
    private float _time;

    public StarfieldElement()
    {
        style.position = Position.Absolute;
        pickingMode = PickingMode.Ignore;

        var rng = new System.Random(42);
        for (int i = 0; i < Count; i++)
            _stars[i] = new Star
            {
                X = (float)rng.NextDouble(),
                Y = (float)rng.NextDouble(),
                R = (float)(rng.NextDouble() * 1.3 + 0.2),
                Phase = (float)(rng.NextDouble() * Math.PI * 2),
                Speed = (float)(rng.NextDouble() * 0.008 + 0.002),
            };

        generateVisualContent += Draw;

        // ~20 fps достаточно для фоновой анимации звёзд
        schedule.Execute(() => { _time += 0.05f; MarkDirtyRepaint(); }).Every(50);
    }

    private void Draw(MeshGenerationContext ctx)
    {
        var p = ctx.painter2D;
        float w = resolvedStyle.width;
        float h = resolvedStyle.height;
        if (w <= 0 || h <= 0) return;

        foreach (var s in _stars)
        {
            float a = 0.5f + 0.5f * Mathf.Sin(_time * s.Speed * 10f + s.Phase);
            p.fillColor = new Color(0.7f, 0.87f, 1f, a * 0.85f);
            p.BeginPath();
            p.Arc(new Vector2(s.X * w, s.Y * h), s.R, 0f, 360f);
            p.Fill();
        }
    }
}