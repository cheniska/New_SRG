﻿using UnityEngine;
using UnityEngine.UI;
// =====================================================================
// EllipseOrbitGraphic
// Рисует эллиптическую орбиту через Canvas Graphic API (без Texture2D).
// Используется SystemMinimapController для отрисовки орбит планет.
// =====================================================================

/// <summary>
/// Кастомный Canvas Graphic, рисующий эллипс с заданной шириной линии.
/// Эксцентриситет управляет формой: 0 = окружность, 0.99 = почти прямая линия.
/// </summary>
[RequireComponent(typeof(CanvasRenderer))]
public class EllipseOrbitGraphic : Graphic
{
    /// <summary>Эксцентриситет орбиты [0..1). Соответствует PlanetData.OrbitEccentricity.</summary>
    [Range(0f, 1f)] public float Eccentricity = 0f;
    /// <summary>Толщина линии орбиты в пикселях UI.</summary>
    public float LineWidth = 1.5f;
    /// <summary>Число сегментов полилинии. Больше = плавнее, но дороже.</summary>
    public int Segments = 128;

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
        if (Segments < 8) return;

        float e = Mathf.Clamp(Eccentricity, 0f, 0.99f);
        // Полуоси берём из размеров RectTransform — ими управляет SystemMinimapController
        float a = rectTransform.rect.width * 0.5f;
        float b = a * Mathf.Sqrt(1f - e * e);
        float half = LineWidth * 0.5f;

        for (int i = 0; i < Segments; i++)
        {
            float t0 = (float)i / Segments * Mathf.PI * 2f;
            float t1 = (float)(i + 1) / Segments * Mathf.PI * 2f;

            Vector2 p0 = new Vector2(Mathf.Cos(t0) * a, Mathf.Sin(t0) * b);
            Vector2 p1 = new Vector2(Mathf.Cos(t1) * a, Mathf.Sin(t1) * b);

            // Нормаль к сегменту — используется для задания ширины линии
            Vector2 dir = (p1 - p0).normalized;
            Vector2 normal = new Vector2(-dir.y, dir.x);

            int idx = i * 4;
            vh.AddVert(p0 + normal * half, color, Vector2.zero);
            vh.AddVert(p0 - normal * half, color, Vector2.zero);
            vh.AddVert(p1 - normal * half, color, Vector2.zero);
            vh.AddVert(p1 + normal * half, color, Vector2.zero);

            vh.AddTriangle(idx, idx + 1, idx + 2);
            vh.AddTriangle(idx, idx + 2, idx + 3);
        }
    }
}
// =====================================================================
// RadarFogGraphic.cs
// Canvas Graphic — туман войны поверх миникарты с прозрачной «дыркой» радара.
//
// Алгоритм:
//   Рисует два концентрических кольца треугольников:
//     1. inner → fade: прозрачный → почти прозрачный (мягкая граница дырки)
//     2. fade  → outer: почти прозрачный → FogColor (непрозрачный туман)
//   outerR = полудиагональ контейнера × 1.2 — всегда перекрывает всё.
//   Контейнер миникарты должен использовать RectMask2D для обрезки углов.
//
// Управляется из SystemMinimapController.UpdateRadarVisuals() каждый кадр.
// =====================================================================

[RequireComponent(typeof(CanvasRenderer))]
public class RadarFogGraphic : Graphic
{
    /// <summary>
    /// Центр прозрачной зоны в локальных координатах контейнера миникарты
    /// (anchoredPosition игрока).
    /// </summary>
    public Vector2 HoleCenter;

    /// <summary>Радиус прозрачной зоны («дырки») в пикселях UI.</summary>
    public float HoleRadius = 50f;

    /// <summary>Цвет и плотность тумана снаружи радара.</summary>
    public Color FogColor = new Color(0f, 0f, 0f, 0.6f);

    /// <summary>Сегменты окружности дырки. 48–64 оптимально для миникарты.</summary>
    public int Segments = 64;

    /// <summary>
    /// Ширина плавного перехода у края дырки (пикселей UI).
    /// 0 = резкая граница, 4–8 = плавная.
    /// </summary>
    public float EdgeFadeWidth = 5f;

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
        if (Segments < 8) return;

        Rect r = rectTransform.rect;
        float outerR = Mathf.Sqrt(r.width * r.width + r.height * r.height) * 0.5f * 1.2f;

        float innerR = Mathf.Max(0f, HoleRadius);
        float fadeR = innerR + Mathf.Max(0f, EdgeFadeWidth);

        Color cTransparent = new Color(FogColor.r, FogColor.g, FogColor.b, 0f);
        Color cFade = new Color(FogColor.r, FogColor.g, FogColor.b, FogColor.a * 0.12f);
        Color cOpaque = new Color(FogColor.r, FogColor.g, FogColor.b, FogColor.a);

        for (int i = 0; i < Segments; i++)
        {
            float a0 = (float)i / Segments * Mathf.PI * 2f;
            float a1 = (float)(i + 1) / Segments * Mathf.PI * 2f;

            Vector2 d0 = new Vector2(Mathf.Cos(a0), Mathf.Sin(a0));
            Vector2 d1 = new Vector2(Mathf.Cos(a1), Mathf.Sin(a1));

            Vector2 pInner0 = HoleCenter + d0 * innerR;
            Vector2 pInner1 = HoleCenter + d1 * innerR;
            Vector2 pFade0 = HoleCenter + d0 * fadeR;
            Vector2 pFade1 = HoleCenter + d1 * fadeR;
            Vector2 pOuter0 = HoleCenter + d0 * outerR;
            Vector2 pOuter1 = HoleCenter + d1 * outerR;

            int b = i * 8;

            // Кольцо 1: inner → fade
            vh.AddVert(pInner0, cTransparent, Vector2.zero); // b+0
            vh.AddVert(pInner1, cTransparent, Vector2.zero); // b+1
            vh.AddVert(pFade0, cFade, Vector2.zero); // b+2
            vh.AddVert(pFade1, cFade, Vector2.zero); // b+3

            // Кольцо 2: fade → outer
            vh.AddVert(pFade0, cFade, Vector2.zero); // b+4
            vh.AddVert(pFade1, cFade, Vector2.zero); // b+5
            vh.AddVert(pOuter0, cOpaque, Vector2.zero); // b+6
            vh.AddVert(pOuter1, cOpaque, Vector2.zero); // b+7

            // Треугольники кольца 1
            vh.AddTriangle(b + 0, b + 2, b + 1);
            vh.AddTriangle(b + 1, b + 2, b + 3);

            // Треугольники кольца 2
            vh.AddTriangle(b + 4, b + 6, b + 5);
            vh.AddTriangle(b + 5, b + 6, b + 7);
        }
    }
}
