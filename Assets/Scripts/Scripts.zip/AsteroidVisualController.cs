using UnityEngine;

// =====================================================================
// AsteroidVisualController.cs
// Визуальный контроллер астероида — анимирует спрайтлист.
//
// Формат ресурсов (пример пути в GalaxyConfig.json):
//   "GraphicPath": "Graphics/Asteroids/Rocky/001"
//
// Рядом с текстурой должен лежать json-мета с тем же именем + суффикс .png:
//   Resources/Graphics/Asteroids/Rocky/001       <- Texture2D
//   Resources/Graphics/Asteroids/Rocky/001.png   <- TextAsset (json-мета)
//
// Мета-формат:
//   { "FrameCount": 79, "Cols": 10, "Rows": 8 }
//
// Загрузка и нарезка делегированы в GraphicsManager.GetAsteroidVisuals() —
// там же кэш, повторной нарезки при следующем спавне не будет.
//
// В Update():
//   TickAnimation — перелистывает кадры по таймеру, Loop.
//   TickRotation  — вращает transform на SelfRotationSpeed °/сек (тумблинг).
//
// UpdateVisualPosition() вызывается каждый кадр из SystemViewManager.AnimateSystem().
// =====================================================================

public class AsteroidVisualController : MonoBehaviour
{
    [Header("Renderer")]
    public SpriteRenderer SpriteRenderer;

    // ── Animation ─────────────────────────────────────────────────────────────
    private Sprite[] _frames;
    private float _secPerFrame;
    private float _frameTimer;
    private int _curFrame;

    // ── Rotation ──────────────────────────────────────────────────────────────
    private float _rotationSpeed; // °/сек, знак задаёт направление тумблинга

    // ── Setup ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Инициализирует контроллер по данным астероида.
    /// Вызывается один раз из SystemViewManager.SpawnAsteroidVisual().
    /// </summary>
    public void Setup(AsteroidData data)
    {
        _rotationSpeed = data.SelfRotationSpeed;

        EnsureRenderer();
        SpriteRenderer.sortingOrder = SortingLayerRegistry.Get(SortLayer.Asteroid);

        LoadSpritesheet(data);

        float scale = Mathf.Clamp(data.CollisionRadius * 2f, 0.2f, 1.5f);
        transform.localScale = Vector3.one * scale;
        transform.localPosition = new Vector3(data.Position.x, data.Position.y, 0f);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Обновляет мировую позицию. Вызывается каждый кадр из SystemViewManager.AnimateSystem().
    /// </summary>
    public void UpdateVisualPosition(Vector2 pos)
    {
        transform.localPosition = new Vector3(pos.x, pos.y, 0f);
    }

    // ── Unity lifecycle ───────────────────────────────────────────────────────

    private void Update()
    {
        float dt = Time.deltaTime;
        TickAnimation(dt);
        TickRotation(dt);
    }

    // ── Private ───────────────────────────────────────────────────────────────

    private void TickAnimation(float dt)
    {
        if (_frames == null || _frames.Length <= 1) return;

        _frameTimer += dt;
        if (_frameTimer < _secPerFrame) return;

        int advance = Mathf.FloorToInt(_frameTimer / _secPerFrame);
        _frameTimer %= _secPerFrame;
        _curFrame = (_curFrame + advance) % _frames.Length;
        SpriteRenderer.sprite = _frames[_curFrame];
    }

    private void TickRotation(float dt)
    {
        transform.Rotate(0f, 0f, _rotationSpeed * dt);
    }

    private void LoadSpritesheet(AsteroidData data)
    {
        if (string.IsNullOrEmpty(data.GraphicPath))
        {
            Debug.LogWarning($"[AsteroidVisualController] Asteroid '{data.Uid[..8]}' has empty GraphicPath.");
            return;
        }

        if (GraphicsManager.Instance == null)
        {
            Debug.LogWarning("[AsteroidVisualController] GraphicsManager.Instance is null.");
            return;
        }

        var (frames, secPerFrame) = GraphicsManager.Instance.GetAsteroidVisuals(
            data.GraphicPath, data.AnimFps);

        if (frames != null && frames.Length > 0)
        {
            _frames = frames;
            _secPerFrame = secPerFrame;
            _curFrame = 0;
            _frameTimer = 0f;
            SpriteRenderer.sprite = _frames[0];
        }
        else
        {
            Debug.LogError($"[AsteroidVisualController] No frames loaded from '{data.GraphicPath}'. " +
                           $"Asteroid '{data.Uid[..8]}' renders without sprite.");
        }
    }

    private void EnsureRenderer()
    {
        if (SpriteRenderer != null) return;
        if (!TryGetComponent(out SpriteRenderer))
            SpriteRenderer = gameObject.AddComponent<SpriteRenderer>();
    }
}