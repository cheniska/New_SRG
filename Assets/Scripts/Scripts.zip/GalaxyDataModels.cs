using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System;

// Рантаймовые данные галактики. Сериализуются в JSON при сохранении/загрузке.

#region Interfaces

public interface IGalaxyEntity
{
    string Uid { get; }
    string FactionId { get; }
    Dictionary<string, string> CustomProperties { get; }
}

#endregion

// ── TURN ANIMATION DATA ───────────────────────────────────────────────────────
// Перенесено из SystemViewManager.cs: типы данных симуляции должны жить рядом
// с GalaxyData, а не в файле визуального контроллера.

// Результат расчёта одного хода — читается аниматорами (SystemViewManager, PlayerShip и др.).
// Заполняется в GalaxyData.GalaxyNextDay() и живёт до начала следующего расчёта.
//
// Структура:
//   ShipFrames       — позиции корабля в каждом из 10 раундов (для интерполяции внутри тика)
//   PlanetAngles     — углы планет (from/to), как раньше
//   ShotEvents       — выстрелы привязанные к раунду (будущий бой)
//   DeathEvents      — смерти, показываются в тике 10
//   PauseReasons     — причины остановки авторежима после этого хода
//   AsteroidSpawns   — новые астероиды появившиеся в этом ходу
//   AsteroidDestroys — астероиды уничтоженные в этом ходу (коллизия или выход за границу)

public class TurnAnimationData
{
    // Ключ — ShipData.Uid.
    // Rounds[0] = позиция до хода, Rounds[i] = позиция после i-го раунда (i = 1..10).
    // Аниматор делает Lerp между [round-1] и [round] внутри тика.
    public Dictionary<string, ShipRoundFrames> ShipFrames = new();

    // Ключ — PlanetData.Uid. Аниматор делает Lerp от From до To по progress.
    public Dictionary<string, (float From, float To)> PlanetAngles = new();

    // Выстрелы (заполняется позже, когда появится бой).
    public List<ShotEvent> Shots = new();

    // Смерти — показываются в тике 10.
    public List<string> DeathUids = new();

    // Причины паузы после этого хода. Заполняется симуляцией.
    public List<PauseReason> PauseReasons = new();

    // Астероиды — события спавна и уничтожения для визуала.
    public List<AsteroidSpawnEvent> AsteroidSpawns = new();
    public List<AsteroidDestroyEvent> AsteroidDestroys = new();

    // Позиции астероидов по раундам — аналог ShipFrames.
    // Заполняется в AsteroidSystem.TickAsteroids, читается в SystemViewManager.AnimateSystem.
    public Dictionary<string, AsteroidRoundFrames> AsteroidFrames = new();
}

// Позиции астероида по раундам — зеркало ShipRoundFrames.
// Rounds[0] = позиция до хода, Rounds[i] = позиция после i-го раунда (i = 1..10).
public class AsteroidRoundFrames
{
    public Vector2[] Rounds = new Vector2[11]; // индексы 0..10
}

// Позиции корабля по раундам.
// Rounds[0] = позиция до начала хода (PreviousPosition).
// Rounds[i] = позиция после i-го раунда движения (i = 1..10).
// SubFrames — плотный список позиций по траектории за весь ход (для плавной анимации).
// Если SubFrames непуст — PlayerShip.OnTurnAnimate использует его вместо Rounds.
public class ShipRoundFrames
{
    public Vector2[] Rounds = new Vector2[11]; // индексы 0..10
    /// <summary>
    /// Все позиции корабля вдоль траектории за ход (по BezierWaypoints).
    /// SubFrames[0] = стартовая позиция, SubFrames[Last] = финальная.
    /// Заполняется в ShipNextDay если корабль имеет кривую.
    /// </summary>
    public List<Vector2> SubFrames;
}

// Один выстрел — привязан к раунду для визуала.
public struct ShotEvent
{
    public string AttackerUid;
    public string TargetUid;
    public string WeaponId;
    public int DamageDealt;
    public int Round;        // 1..10 — в каком раунде показать вспышку
}

// Причины остановки авторежима. Любая запись в TurnAnimationData.PauseReasons
// приводит к тому что GalaxyManager не запускает следующий ход автоматически.
public enum PauseReason
{
    PlayerInput,      // пробел нажат вручную
    RouteCompleted,   // игрок достиг конечной точки маршрута
    LowHull,          // HP игрока упал ниже порога
    AsteroidImpact,   // астероид попал в корабль игрока
    EnemyDetected,    // враг появился в системе игрока (будущее)
    QuestTrigger,     // триггер квеста (будущее)
}

// ── ASTEROID DATA ─────────────────────────────────────────────────────────────
//
// Транзитный объект пролетающий через систему по прямолинейной траектории
// с учётом гравитационного притяжения звезды (AsteroidSystem.ApplyGravity).
//
// Жизненный цикл:
//   Спавн (за границей системы) → движение через систему → уничтожение при
//   коллизии или выходе за границу → дроп предметов → удаление из StarData.Asteroids.

[Serializable]
public class AsteroidData
{
    public string Uid { get; set; } = Guid.NewGuid().ToString();

    /// <summary>Ключ типа астероида (Rocky, Metallic, …) из AsteroidConfigSection.Types.</summary>
    public string TypeId { get; set; }

    // ── Физика ───────────────────────────────────────────────────────────────

    public Vector2 Position { get; set; }

    /// <summary>Позиция в предыдущем раунде — для интерполяции визуала.</summary>
    [JsonIgnore] public Vector2 PreviousPosition { get; set; }

    /// <summary>
    /// Вектор скорости (мировых единиц за ход).
    /// Изменяется каждый раунд через AsteroidSystem.ApplyGravity:
    ///   нарастает при сближении со звездой, убывает при удалении.
    /// </summary>
    public Vector2 Velocity { get; set; }

    /// <summary>Масса — влияет на урон при столкновении.</summary>
    public float Mass { get; set; }

    /// <summary>Радиус коллизии в мировых единицах.</summary>
    public float CollisionRadius { get; set; }

    // ── Визуал ───────────────────────────────────────────────────────────────

    /// <summary>Путь к спрайту (выбирается случайно при спавне из папки типа).</summary>
    public string GraphicPath { get; set; }

    /// <summary>
    /// Скорость визуального вращения спрайта (градусов в секунду).
    /// Отрицательное значение — вращение в обратном направлении.
    /// </summary>
    public float SelfRotationSpeed { get; set; }

    /// <summary>FPS анимации спрайтлиста. Берётся из AsteroidTypeConfig.AnimFps.</summary>
    public float AnimFps { get; set; } = 12f;

    // ── Состояние ────────────────────────────────────────────────────────────

    /// <summary>
    /// Помечается true при коллизии или выходе за границу системы.
    /// AsteroidSystem удаляет такие астероиды в конце последнего раунда хода.
    /// </summary>
    [JsonIgnore] public bool IsDestroyed { get; set; }
}

// ── ITEM STACK ────────────────────────────────────────────────────────────────
//
// Стопка стакаемых предметов (минералы).
// Хранится в ShipInventory.Stacks по ключу ItemId.
// TotalWeight = количество единиц = суммарный вес (каждая единица = 1 вес).
// BasePrice — цена за единицу веса.

[Serializable]
public class ItemStack
{
    /// <summary>Ключ предмета в ItemsConfig.Minerals (например "CommonMineral").</summary>
    public string ItemId { get; set; }

    /// <summary>Категория предмета (например "Mineral").</summary>
    public string Category { get; set; }

    public string Name { get; set; }

    /// <summary>Количество единиц в стопке. Каждая единица = 1 вес.</summary>
    public int TotalWeight { get; set; }

    /// <summary>Базовая цена за единицу веса.</summary>
    public int BasePrice { get; set; }

    /// <summary>Суммарная стоимость стопки.</summary>
    [JsonIgnore] public int TotalPrice => TotalWeight * BasePrice;
}

// ── ASTEROID ANIMATION EVENTS ─────────────────────────────────────────────────

/// <summary>Событие спавна астероида — визуал должен создать новый объект.</summary>
public struct AsteroidSpawnEvent
{
    public string AsteroidUid;
}

/// <summary>
/// Событие уничтожения астероида.
/// Position      — точка уничтожения для эффекта взрыва и спавна дропа.
/// DroppedItems  — оборудование выпавшее при разрушении.
/// DroppedStacks — минералы выпавшие при разрушении.
/// HitPlayer     — true если уничтожен столкновением с кораблём игрока.
/// CollisionType — тип столкновения; определяет цвет взрыва и наличие эффекта.
/// </summary>
public struct AsteroidDestroyEvent
{
    public string AsteroidUid;
    public Vector2 Position;
    public List<ItemInstance> DroppedItems;
    public List<ItemStack> DroppedStacks;
    public bool HitPlayer;
    /// <summary>None = тихий выход за границу (без взрыва и дропа).</summary>
    public AsteroidCollisionType CollisionType;
    /// <summary>Раунд столкновения (1..10). 0 = выход за границу.</summary>
    public int CollisionRound;
    /// <summary>Момент внутри раунда [0..1] в который произошло касание.</summary>
    public float CollisionT;
}

#region Runtime Data

// Корневой объект. После десериализации вызвать InitializeLookups(), после генерации — InitSimulation().
public class GalaxyData
{
    public int Width;
    public int Height;
    public int CurrentTurn = 0;
    public string StartDateString = "01.01.0001";

    public List<ConstellationData> Constellations = new List<ConstellationData>(); // единственный источник истины

    [JsonIgnore] public Dictionary<string, StarData> StarsMap = new();
    [JsonIgnore] public Dictionary<string, PlanetData> PlanetsMap = new();
    [JsonIgnore] public Dictionary<string, ConstellationData> ConstellationsMap = new();

    private static readonly System.Globalization.DateTimeStyles _dateStyles = System.Globalization.DateTimeStyles.None;
    [JsonIgnore] private DateTime _cachedStartDate;
    [JsonIgnore] private string _cachedStartDateString;

    private DateTime GetStartDate()
    {
        if (_cachedStartDateString == StartDateString) return _cachedStartDate;
        _cachedStartDateString = StartDateString;
        if (!DateTime.TryParseExact(StartDateString, "dd.MM.yyyy", null, _dateStyles, out _cachedStartDate))
            _cachedStartDate = new DateTime(1, 1, 1);
        return _cachedStartDate;
    }

    public string GetCurrentDate() => GetStartDate().AddDays(CurrentTurn).ToString("dd.MM.yyyy");

    // Пересобирает индексные словари из иерархии Constellations → Stars → Planets.
    // Вызывать после десериализации или генерации.
    public void InitializeLookups()
    {
        StarsMap.Clear(); PlanetsMap.Clear(); ConstellationsMap.Clear();

        foreach (var c in Constellations)
        {
            TryAdd(ConstellationsMap, c.Uid, c);
            foreach (var star in c.Stars)
            {
                star.ParentConstellation = c;
                TryAdd(StarsMap, star.Uid, star);
                foreach (var planet in star.Planets) { planet.ParentStar = star; TryAdd(PlanetsMap, planet.Uid, planet); }
            }
        }
    }

    // ── РАСЧЁТ ХОДА ──────────────────────────────────────────────────────────
    //
    // Иерархия вызовов:
    //   GalaxyNextDay
    //     └─ для каждой звезды: StarNextDay
    //           ├─ TrySpawnAsteroid (1 раз до цикла раундов)
    //           ├─ для каждой планеты: PlanetNextDay   (фаза расчёта планеты)
    //           └─ для каждого корабля + астероидов: ShipNextDay / TickAsteroids (10 раундов)
    //
    // Возвращает TurnAnimationData — данные для аниматоров (SystemViewManager, PlayerShip).
    // Фаза фильма (10 шагов) живёт в GalaxyManager.TickMovieMode — здесь только расчёт.
    // PauseReasons заполняется GalaxyManager после получения результата.

    public const int TurnRounds = 10;

    /// <summary>
    /// Рассчитывает один ход галактики.
    /// ctx нужен для AsteroidSystem (конфиг астероидов, ItemsConfig, Equipment для дропа).
    /// </summary>
    public TurnAnimationData GalaxyNextDay(GalaxyGenerationContext ctx = null)
    {
        CurrentTurn++;
        var anim = new TurnAnimationData();

        foreach (var star in StarsMap.Values)
            star.StarNextDay(anim, ctx);

        return anim;
    }

    // Инициализирует начальные углы вращения. Вызывать один раз перед симуляцией.
    public void InitSimulation()
    {
        foreach (var c in Constellations)
            foreach (var star in c.Stars)
                foreach (var planet in star.Planets)
                    planet.InitRotation();
    }

    private static void TryAdd<T>(Dictionary<string, T> map, string key, T value)
    {
        if (!string.IsNullOrEmpty(key) && !map.ContainsKey(key)) map.Add(key, value);
    }
}

// Логическая группа звёздных систем.
public class ConstellationData
{
    // public setter + [JsonConstructor] для корректной десериализации.
    // Guid.NewGuid() как дефолт гарантирует уникальность при создании новых объектов.
    public string Uid { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public Vector2 Center { get; set; }
    public List<StarData> Stars { get; set; } = new();
    public int? FixedStarsCount { get; set; }
    // Owner сохранён для внутреннего использования генератора (агрегация из дочерних звёзд).
    public string Owner { get; set; }

    [JsonConstructor]
    public ConstellationData() { }

    public ConstellationData(string name, Vector2 center) { Name = name; Center = center; }
}

public class StarData : IGalaxyEntity
{
    public string Uid { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Type { get; set; }
    public string Color { get; set; }
    public Vector2 Position { get; set; }
    public string FactionId { get; set; }
    public int GraphVar { get; set; }
    public int SystemSize { get; set; }
    public int BackgroundSeed { get; set; }
    public string MapIcon { get; set; }
    public string PlanetsNoneCount { get; set; }

    /// <summary>
    /// Радиус звезды в мировых единицах. Зависит от GraphicSizeMult типа звезды.
    /// Используется для обхода кораблями и граничных проверок астероидов.
    /// Выставляется в GalaxyGenerator.FinalizeStarProps.
    /// </summary>
    public float StarRadius { get; set; }

    public List<PlanetData> Planets { get; set; } = new();
    public List<ShipData> Ships { get; set; } = new();
    public List<string> ConnectedStarUids { get; set; } = new();
    public Dictionary<string, string> CustomProperties { get; private set; } = new();

    /// <summary>
    /// Данные цветного отображения имени. Вычисляется при генерации через OwnershipDisplayResolver.
    /// Используется логгером, галакартой и StarLabelRenderer.
    /// </summary>
    public StarNameRenderData NameRenderData { get; set; }

    /// <summary>
    /// Активные астероиды в системе.
    /// Заполняется только если в системе есть игрок (AsteroidSystem.TrySpawnAsteroid).
    /// </summary>
    public List<AsteroidData> Asteroids { get; set; } = new();

    /// <summary>
    /// Максимальное число одновременных астероидов в этой системе.
    /// -1 = использовать GalaxyConstants.DEFAULT_MAX_ASTEROIDS.
    /// Может быть задан в PremadeConfig.FixedStarData.MaxAsteroids.
    /// </summary>
    public int MaxAsteroids { get; set; } = -1;

    [JsonIgnore] public ConstellationData ParentConstellation { get; set; }

    // Расчёт одного хода для всей звёздной системы.
    // Вызывается из GalaxyData.GalaxyNextDay для каждой звезды.
    //
    // Порядок:
    //   1. TrySpawnAsteroid (только если есть игрок)
    //   2. PlanetNextDay для каждой планеты  — фаза расчёта планет
    //   3. ShipNextDay для каждого корабля + TickAsteroids — 10 раундов
    public void StarNextDay(TurnAnimationData anim, GalaxyGenerationContext ctx = null)
    {
        // ── Проверяем наличие игрока ──────────────────────────────────────────
        bool playerPresent = false;
        foreach (var s in Ships)
            if (s.IsPlayer) { playerPresent = true; break; }

        // ── Спавн астероидов — один раз в начале хода ─────────────────────────
        if (playerPresent && ctx != null)
            AsteroidSystem.TrySpawnAsteroid(this, ctx, anim);

        // ── Фаза расчёта планет ───────────────────────────────────────────────
        foreach (var planet in Planets)
        {
            planet.PlanetNextDay();
            anim.PlanetAngles[planet.Uid] = (planet.PreviousAngle, planet.CurrentAngle);
        }

        // ── Инициализация кадров для кораблей (раунд 0 = позиция до хода) ────
        foreach (var ship in Ships)
        {
            var frames = new ShipRoundFrames();
            frames.Rounds[0] = ship.Position;
            anim.ShipFrames[ship.Uid] = frames;
        }

        // ── Инициализация кадров для астероидов (раунд 0 = позиция до хода) ──
        if (playerPresent)
        {
            foreach (var asteroid in Asteroids)
            {
                if (asteroid.IsDestroyed) continue;
                var frames = new AsteroidRoundFrames();
                frames.Rounds[0] = asteroid.Position;
                anim.AsteroidFrames[asteroid.Uid] = frames;
            }
        }

        // ── Фаза расчёта кораблей и астероидов: 10 раундов ───────────────────
        // В каждом раунде:
        //   1. CombatRound    — бой (заглушка, будет заменена CombatSystem)
        //   2. ShipNextDay    — один раунд движения + фиксация позиции в anim
        //   3. TickAsteroids  — физика астероидов + коллизии
        for (int round = 1; round <= GalaxyData.TurnRounds; round++)
        {
            CombatRound(round, anim);

            foreach (var ship in Ships)
                ship.ShipNextDay(round, anim);

            if (playerPresent && ctx != null)
                AsteroidSystem.TickAsteroids(this, round, anim, ctx);
        }
    }

    // Один раунд боя внутри системы.
    // Заглушка — заменяется реальной боевой логикой когда появится CombatSystem.
    // round: 1..10 — нужен для записи ShotEvent в anim.
    private void CombatRound(int round, TurnAnimationData anim)
    {
        // TODO: CombatSystem.ProcessRound(this, round, anim)
    }
}

public class PlanetData : IGalaxyEntity
{
    public string Uid { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Size { get; set; }

    public int OrbitIndex { get; set; }
    public float OrbitRadius { get; set; }
    public float OrbitSpeed { get; set; }
    public float InitialAngle { get; set; }
    public float OrbitEccentricity;
    public float OrbitTiltDeg;

    public string Race { get; set; }
    public string Type { get; set; }
    public string FactionId { get; set; }
    public string CurrentColor { get; set; }
    public string Graphic { get; set; }
    public string MaskGraphic { get; set; }
    public string Atmosphere { get; set; }
    public string OrbitalObjects { get; set; }
    public int SatellitesCount { get; set; }
    public int DaySpeed { get; set; }
    public int CloudsSpeed { get; set; }

    public float CurrentAngle { get; set; }
    public float PreviousAngle { get; set; }

    public Dictionary<string, string> CustomProperties { get; private set; } = new();
    public List<SatelliteData> Satellites { get; set; } = new();

    /// <summary>Путь к кастомной иконке планеты на миникарте. null = дефолтная иконка.</summary>
    public string MinimapIconPath { get; set; }

    [JsonIgnore] public StarData ParentStar { get; set; }

    private const float NearZero = 0.001f;

    // PreviousAngle сохраняется здесь же перед вычислением.
    // Вычисляет финальный угол за один ход и обновляет спутников.
    public void PlanetNextDay()
    {
        PreviousAngle = CurrentAngle; // бывший BeginTurn()
        CurrentAngle = AdvanceAngle(CurrentAngle, OrbitSpeed);

        foreach (var sat in Satellites)
        {
            sat.CurrentAngle = AdvanceAngle(sat.CurrentAngle, sat.OrbitSpeed);
            if (sat.DaySpeed > 0) sat.CurrentRotationAngle += 360f / sat.DaySpeed;
        }
    }

    public void InitRotation() { CurrentAngle = PreviousAngle = InitialAngle; }

    string IGalaxyEntity.FactionId => FactionId ?? GalaxyConstants.RACE_NONE_KEY;

    private static float AdvanceAngle(float current, float speed)
    {
        if (Mathf.Abs(speed) < NearZero) return current;
        float next = current + 360f / speed;
        if (next >= 360f) next -= 360f;
        if (next < 0f) next += 360f;
        return next;
    }
}

public class SatelliteData : IGalaxyEntity
{
    public string Uid { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; }
    public string Size { get; set; } = "Mid";

    public float OrbitRadius { get; set; }
    public float OrbitSpeed { get; set; }
    public float CurrentAngle { get; set; }
    public float OrbitInclination { get; set; }

    public string Graphic { get; set; }
    public string Atmosphere { get; set; }

    public int DaySpeed { get; set; }
    public int CloudsSpeed { get; set; }
    public float CurrentRotationAngle { get; set; }

    public string Race { get; set; }
    public string FactionId { get; set; }
    public Dictionary<string, string> CustomProperties { get; private set; } = new();

    string IGalaxyEntity.FactionId => FactionId ?? GalaxyConstants.RACE_NONE_KEY;
}

public class RaceInfo
{
    public string Name { get; private set; }
    public string Color { get; private set; }
    public string EmblemPath { get; private set; }

    public RaceInfo(string name, string color, string emblemPath)
    {
        Name = name;
        Color = color?.ToLowerInvariant() ?? GalaxyConstants.DEFAULT_COLOR;
        EmblemPath = emblemPath;
    }
}

#endregion

// ── SHIP DATA ─────────────────────────────────────────────────────────────────

// TODO: ShipData нарушает SRP — смешивает визуальные данные, характеристики и данные симуляции.
// Целевое разделение:
//   ShipVisualData  — SpritesheetPath, MinimapIconPath, Animations, Thrusters
//   ShipStatsData   — BaseHull, BaseWeight, EngineSpeed
//   ShipData        — Position, TargetPosition, SimWaypoints, CurrentStarUid, CurrentHull + ссылки на Visual/Stats
// Рефакторинг требует изменений в ShipFactory, GalaxyManager.SpawnPlayer, SystemViewManager.SpawnShips,
// сериализации (GalaxySaveManager) и ShipVisualController.
public class ShipData
{
    public string Uid { get; set; } = Guid.NewGuid().ToString();

    public string ShipTypeId;
    public string Name;

    // Визуальные данные
    public string SpritesheetPath;
    public string MinimapIconPath;
    public Dictionary<string, ShipAnimationClip> Animations;
    public List<ShipThrusterData> Thrusters;

    // Базовые характеристики из конфига ShipType.
    // BaseHull — запасной дефолт для MaxHull если корпус не установлен.
    // BaseWeight, EngineSpeed — устаревшие, оставлены для совместимости ShipFactory.
    public int BaseHull;
    public int BaseWeight;
    public int EngineSpeed;

    public string FactionId;
    public bool IsPlayer;

    // ── Позиции ───────────────────────────────────────────────────────────────

    public Vector2 Position;
    [JsonIgnore] public Vector2 PreviousPosition;
    public Vector2 TargetPosition;

    /// <summary>
    /// Очередь путевых точек для симуляции одного хода.
    /// Заполняется PlayerShip перед GalaxyNextDay().
    /// ShipMoveStep автоматически переходит к следующей точке,
    /// если текущая достигнута в рамках раунда.
    /// После расчёта хода содержит оставшиеся (не достигнутые) точки.
    /// </summary>
    [JsonIgnore] public Queue<Vector2> SimWaypoints = new Queue<Vector2>();

    /// <summary>
    /// Текущий курс корабля (радианы, CCW от оси X).
    /// Обновляется в ShipMoveStep по направлению движения.
    /// Используется ShipTrajectory для построения изгиба следующей кривой.
    /// float.NaN = курс неизвестен (только что создан).
    /// </summary>
    [JsonIgnore] public float CurrentHeading = float.NaN;

    /// <summary>
    /// Плотный список точек текущей кривой Безье для движения в этом ходу.
    /// Строится PlayerShip.ApplyWaypointsToShipData() перед каждым ходом.
    /// ShipMoveStep последовательно идёт по этим точкам.
    /// </summary>
    [JsonIgnore] public List<Vector2> BezierWaypoints = new List<Vector2>();

    /// <summary>Индекс следующей точки в BezierWaypoints которую нужно достичь.</summary>
    [JsonIgnore] public int BezierIndex = 0;

    public string CurrentStarUid;
    public string PreviousStarUid;

    // ── HP ────────────────────────────────────────────────────────────────────

    public int CurrentHull;
    public int MaxHull;

    // ── Оборудование ──────────────────────────────────────────────────────────

    /// <summary>
    /// Все ItemInstance корабля (установленные в слоты + в трюме).
    /// Ключ — ItemInstance.Uid. Единственный источник истины для предметов.
    /// EquipmentSlots и ShipInventory хранят только Uid-ссылки.
    /// </summary>
    public Dictionary<string, ItemInstance> AllItems { get; set; } = new();

    /// <summary>Установленное снаряжение. Ключ — "Category_Index", значение — ItemInstance.Uid.</summary>
    public EquipmentSlots Equipment { get; set; } = new();

    /// <summary>Предметы в трюме (не установлены в слоты).</summary>
    public ShipInventory Inventory { get; set; } = new();

    /// <summary>
    /// Активирован ли форсаж на текущий ход.
    /// Выставляется игроком до StartTurn(), сбрасывается в false в EquipmentSystem.ApplyTurnEffects.
    /// </summary>
    [JsonIgnore] public bool ForsageActive { get; set; } = false;

    // ── Computed ──────────────────────────────────────────────────────────────

    /// <summary>
    /// Актуальная скорость корабля. Вычисляется через EquipmentSystem:
    /// учитывает двигатель, форсаж, суммарный вес и артефакты SpeedMult.
    /// Если двигатель сломан или не установлен — возвращает 0.
    /// </summary>
    [JsonIgnore]
    public float ActualSpeed => EquipmentSystem.CalculateSpeed(this);

    /// <summary>Суммарный вес установленного оборудования + груза в трюме.</summary>
    [JsonIgnore]
    public int TotalWeight => EquipmentSystem.GetEquippedWeight(this) + Inventory.TotalWeight();

    // ── Движение ──────────────────────────────────────────────────────────────

    // ── Движение по кривой Безье ─────────────────────────────────────────────
    //
    // ShipMoveStep движется по BezierWaypoints — плотному списку точек кривой,
    // построенному ShipTrajectory.BuildPath() перед каждым ходом.
    //
    // Если BezierWaypoints пуст (нет кривой) — fallback на прямолинейное движение
    // к TargetPosition (совместимость с NPC у которых нет кривой).
    //
    // После прохода всех точек кривой берётся следующая пользовательская точка
    // из SimWaypoints и строится новая кривая от текущей позиции.
    //
    // CurrentHeading обновляется по направлению каждого шага — используется
    // для построения следующей кривой с правильным изгибом.

    public void ShipMoveStep(int stepDivisor)
    {
        if (CurrentHull <= 0) return;
        float fullStep = ActualSpeed / 100f;
        float remaining = fullStep / stepDivisor;

        int safetyLimit = stepDivisor * 10;
        int iterations = 0;

        while (remaining > 0.0001f)
        {
            if (++iterations > safetyLimit)
            {
                Debug.LogWarning($"[ShipData] ShipMoveStep: safety limit for {Uid}. Breaking.");
                break;
            }

            // ── Есть кривая Безье — идём по ней ─────────────────────────────
            if (BezierWaypoints != null && BezierIndex < BezierWaypoints.Count)
            {
                Vector2 nextPt = BezierWaypoints[BezierIndex];
                Vector2 dir = nextPt - Position;
                float dist = dir.magnitude;

                if (dist < 0.001f)
                {
                    // Точка достигнута — переходим к следующей
                    Position = nextPt;
                    BezierIndex++;
                    continue;
                }

                // Обновляем курс по текущему направлению движения
                CurrentHeading = Mathf.Atan2(dir.y, dir.x);

                if (dist <= remaining)
                {
                    remaining -= dist;
                    Position = nextPt;
                    BezierIndex++;
                }
                else
                {
                    Position += dir.normalized * remaining;
                    remaining = 0f;
                }
            }
            else
            {
                // ── Кривая исчерпана — берём следующую пользовательскую точку ──
                if (SimWaypoints.Count > 0)
                {
                    Vector2 nextTarget = SimWaypoints.Dequeue();
                    TargetPosition = nextTarget;

                    // Строим новую кривую от текущей позиции к следующей точке
                    var star = FindCurrentStar();
                    BezierWaypoints = ShipTrajectory.BuildPath(
                        Position,
                        nextTarget,
                        CurrentHeading,
                        star != null ? star.Position : Vector2.zero,
                        star != null ? star.StarRadius : 0f);
                    BezierIndex = 0;
                    continue;
                }

                // ── Нет ни кривой ни следующей точки — fallback прямо к цели ──
                Vector2 toTarget = TargetPosition - Position;
                float toDist = toTarget.magnitude;
                if (toDist < 0.001f) break;

                CurrentHeading = Mathf.Atan2(toTarget.y, toTarget.x);

                if (toDist <= remaining)
                {
                    remaining -= toDist;
                    Position = TargetPosition;
                }
                else
                {
                    Position += toTarget.normalized * remaining;
                    remaining = 0f;
                }
                break;
            }
        }
    }

    /// <summary>
    /// Ищет StarData текущей системы корабля через GalaxyManager.
    /// Используется для обхода звезды при построении кривой.
    /// </summary>
    private StarData FindCurrentStar()
    {
        if (string.IsNullOrEmpty(CurrentStarUid)) return null;
        var map = GalaxyManager.Instance?.GeneratedGalaxy?.StarsMap;
        if (map == null) return null;
        map.TryGetValue(CurrentStarUid, out var star);
        return star;
    }

    // Один раунд движения корабля.
    // Вызывается из StarData.StarNextDay для каждого раунда (round = 1..TurnRounds).
    // Делает 1/TurnRounds шага, применяет износ и эффекты, фиксирует позицию в anim.
    public void ShipNextDay(int round, TurnAnimationData anim)
    {
        if (CurrentHull <= 0)
        {
            if (anim.ShipFrames.TryGetValue(Uid, out var deadFrames))
                deadFrames.Rounds[round] = Position;
            return;
        }

        // Запоминаем позиции BezierWaypoints ДО хода — для SubFrames
        // В первом раунде инициализируем SubFrames стартовой позицией
        if (round == 1 && anim.ShipFrames.TryGetValue(Uid, out var initFrames))
        {
            initFrames.SubFrames = new List<Vector2> { Position };
        }

        Vector2 posBefore = Position;
        ShipMoveStep(GalaxyData.TurnRounds);
        bool moved = (Position - posBefore).sqrMagnitude > 0.0001f;

        // Эффекты оборудования и износ от движения — в последнем раунде.
        if (round == GalaxyData.TurnRounds)
        {
            var equipConfig = GalaxyManager.Instance?.Context?.Equipment;
            EquipmentSystem.ApplyTurnEffects(this, equipConfig, moved);
        }

        if (anim.ShipFrames.TryGetValue(Uid, out var frames))
        {
            frames.Rounds[round] = Position;

            // Добавляем текущую позицию в SubFrames для плавной анимации
            if (frames.SubFrames != null)
                frames.SubFrames.Add(Position);
        }
    }

    // ── Урон ──────────────────────────────────────────────────────────────────

    /// <summary>
    /// Применяет урон к кораблю по полной формуле:
    /// уязвимость корпуса → щит → броня → HP → попадание по оборудованию.
    /// equipConfig нужен для определения CanBeDamagedByWeapon.
    /// Если equipConfig == null — простое вычитание rawDamage из HP.
    /// </summary>
    public void ApplyDamage(
        int rawDamage,
        string damageType,
        int armorPierce = 0,
        float equipHitChance = 0f,
        int equipDamage = 0,
        EquipmentConfig equipConfig = null)
    {
        if (equipConfig != null)
            EquipmentSystem.ApplyDamage(this, rawDamage, damageType, armorPierce,
                                        equipHitChance, equipDamage, equipConfig);
        else
            CurrentHull = Mathf.Max(0, CurrentHull - rawDamage);
    }

    // ── Инициализация ─────────────────────────────────────────────────────────

    public void InitOnSpawn(StarData star, Vector2 spawnPos)
    {
        Position = PreviousPosition = TargetPosition = spawnPos;
        CurrentStarUid = star?.Uid;
        PreviousStarUid = star?.Uid;

        if (BaseHull <= 0)
            Debug.LogWarning($"[ShipData] InitOnSpawn: BaseHull={BaseHull} for ship '{Name}' — using fallback 100. Check ShipType config.");

        // MaxHull: из установленного корпуса если есть, иначе BaseHull.
        var hull = EquipmentSystem.GetEquipped(this, "Hull_0");
        MaxHull = hull != null
            ? Mathf.RoundToInt(hull.GetParam("HP", BaseHull > 0 ? BaseHull : 100f))
            : (BaseHull > 0 ? BaseHull : 100);

        CurrentHull = MaxHull;

        // Пересобрать индекс инвентаря после десериализации из JSON.
        Inventory.RebuildIndex();
    }
}

public class ShipAnimationClip
{
    [Newtonsoft.Json.JsonProperty("StartFrame")] public int StartFrame;
    [Newtonsoft.Json.JsonProperty("FrameCount")] public int FrameCount;
    [Newtonsoft.Json.JsonProperty("FPS")] public float FPS;
    [Newtonsoft.Json.JsonProperty("Loop")] public bool Loop = true;
}

public class ShipThrusterData
{
    public Vector2 LocalOffset;
    public string SpritesheetPath;
    public float FPS = 12f;
}

// ── RUNTIME EQUIPMENT DATA MODELS ────────────────────────────────────────────
//
// ItemInstance   — рантаймовый экземпляр предмета (создаётся из EquipmentItemConfig)
// EquipmentSlots — слоты корабля/станции (Equipment["Weapon_0"] = ItemInstance.Uid)
// ShipInventory  — трюм корабля (предметы не в слотах + стаки минералов)
//
// Все три сериализуются вместе с ShipData в GalaxySaveManager.

// ── ITEM INSTANCE ─────────────────────────────────────────────────────────────

/// <summary>
/// Рантаймовый экземпляр предмета оборудования.
/// Создаётся из шаблона EquipmentItemConfig через ItemInstance.FromConfig().
/// Хранит изменяемое состояние: Durability, CurrentFuel, Modification, Modules.
/// </summary>
[Serializable]
public class ItemInstance
{
    // ── Идентификация ─────────────────────────────────────────────────────────

    /// <summary>Уникальный ID экземпляра (GUID). Используется как ключ в Equipment/Inventory.</summary>
    public string Uid { get; set; } = Guid.NewGuid().ToString();

    /// <summary>ID категории (Hull, Engine, Weapons, …).</summary>
    public string Category { get; set; }

    /// <summary>ID шаблона предмета (E_Fast, SH_Heavy, …).</summary>
    public string ItemId { get; set; }

    // ── Характеристики (копируются из конфига при создании) ───────────────────

    public string Name { get; set; }
    public string Description { get; set; }
    public int Weight { get; set; }
    public int Price { get; set; }     // финальная цена с учётом множителей
    public int TechLevel { get; set; }
    public bool NoWear { get; set; }
    public bool AllowModules { get; set; }

    public string ManufacturerRace { get; set; }
    public string ManufacturerFaction { get; set; }

    // ── Изменяемое состояние ──────────────────────────────────────────────────

    /// <summary>Текущая прочность. При 0 предмет не работает.</summary>
    public int Durability { get; set; }

    /// <summary>Максимальная прочность (финальная с учётом множителей производителя).</summary>
    public int MaxDurability { get; set; }

    /// <summary>Текущее количество топлива. Только для FuelTank.</summary>
    public int CurrentFuel { get; set; }

    // ── Параметры (float-числа из Params конфига) ─────────────────────────────

    /// <summary>
    /// Кэш числовых параметров. Заполняется при создании из конфига.
    /// Строковые параметры (DamageType) хранятся в ParamStrings.
    /// </summary>
    public Dictionary<string, float> Params { get; set; } = new();
    public Dictionary<string, string> ParamStrings { get; set; } = new();

    // ── Аккумуляторы износа ──────────────────────────────────────────────────
    // Накапливают действия для порогового списания прочности.
    // Только для Droid и CargoGrabber.

    /// <summary>Накопленные HP вылечено дроидом. Износ списывается при достижении WearThreshold.</summary>
    public float HealAccumulator { get; set; } = 0f;

    /// <summary>Накопленный вес груза захваченный CargoGrabber. Износ при достижении WearThreshold.</summary>
    public float CargoAccumulator { get; set; } = 0f;

    // ── Модификации ───────────────────────────────────────────────────────────
    // Реализация отложена, поля зарезервированы для сериализации.

    public string Modification { get; set; }
    public List<string> Modules { get; set; } = new();

    // ── WeaponVulnerability (только для Hull) ─────────────────────────────────
    // Копируется из HullSeries при создании. Может быть изменена модификациями/артефактами.

    public Dictionary<string, float> WeaponVulnerability { get; set; }

    // ── COMPUTED HELPERS ──────────────────────────────────────────────────────

    /// <summary>Предмет работает (Durability > 0).</summary>
    [JsonIgnore] public bool IsWorking => Durability > 0;

    /// <summary>Возвращает числовой параметр или defaultValue.</summary>
    public float GetParam(string key, float defaultValue = 0f) =>
        Params.TryGetValue(key, out var v) ? v : defaultValue;

    /// <summary>Возвращает строковый параметр или defaultValue.</summary>
    public string GetParamString(string key, string defaultValue = null) =>
        ParamStrings.TryGetValue(key, out var v) ? v : defaultValue;

    /// <summary>Уязвимость к типу урона (1.0 если не задана). Только Hull.</summary>
    public float GetVulnerability(string damageType) =>
        WeaponVulnerability != null && WeaponVulnerability.TryGetValue(damageType, out var v) ? v : 1.0f;

    // ── FACTORY ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Создаёт ItemInstance из конфига предмета и серии корпуса (если Hull).
    /// Применяет множители производителя к цене и MaxDurability.
    /// equipConfig нужен для получения HullSeries.
    /// raceManufacturingMult / factionManufacturingMult — из конфига рас/фракций.
    /// </summary>
    public static ItemInstance FromConfig(
        string category,
        string itemId,
        EquipmentItemConfig cfg,
        EquipmentConfig equipConfig,
        float priceMult = 1f,
        float durabilityMult = 1f)
    {
        if (cfg == null) return null;

        var inst = new ItemInstance
        {
            Category = category,
            ItemId = itemId,
            Name = cfg.Name,
            Description = cfg.Description,
            Weight = cfg.Weight,
            TechLevel = cfg.TechLevel,
            NoWear = cfg.NoWear,
            AllowModules = cfg.AllowModules,
            ManufacturerRace = cfg.Manufacturer?.Race,
            ManufacturerFaction = cfg.Manufacturer?.Faction,

            Price = Mathf.RoundToInt(cfg.Price * priceMult),
            MaxDurability = Mathf.Max(1, Mathf.RoundToInt(cfg.MaxDurability * durabilityMult)),
        };
        inst.Durability = inst.MaxDurability;

        // Копируем параметры из конфига
        if (cfg.Params != null)
        {
            foreach (var kv in cfg.Params)
            {
                // Пробуем float — если не получается, берём как строку
                try { inst.Params[kv.Key] = kv.Value.ToObject<float>(); }
                catch
                {
                    try { inst.ParamStrings[kv.Key] = kv.Value.ToObject<string>(); } catch { }
                }
            }
        }

        // Для FuelTank инициализируем CurrentFuel = Capacity
        if (category == "FuelTank")
            inst.CurrentFuel = Mathf.RoundToInt(inst.GetParam("Capacity"));

        // Для Hull копируем WeaponVulnerability из серии
        if (category == "Hull" && equipConfig != null)
        {
            string seriesId = cfg.HullSeries;
            var series = equipConfig.GetSeries(seriesId);
            if (series != null)
            {
                inst.WeaponVulnerability = new Dictionary<string, float>(series.WeaponVulnerability);
                // Добавляем HP из Params в MaxHull (удобно читать напрямую)
                // HP хранится в Params["HP"], снаружи читается через GetParam("HP")
            }
        }

        return inst;
    }
}

// ── EQUIPMENT SLOTS ───────────────────────────────────────────────────────────

/// <summary>
/// Слоты оборудования корабля/станции.
/// Ключ — "Category_Index" (например "Weapon_0", "Shield_0", "Artefacts_3").
/// Значение — Uid установленного ItemInstance, или null если слот пуст.
///
/// Доступные слоты определяются серией корпуса (HullSeries.Slots),
/// ограниченной глобальными лимитами (EquipmentTypes.MaxSlots).
/// Слоты с count=0 в серии — заблокированы.
/// </summary>
[Serializable]
public class EquipmentSlots
{
    /// <summary>Карта "SlotKey → ItemInstance.Uid". Null = пустой слот.</summary>
    public Dictionary<string, string> Slots { get; set; } = new();

    // ── QUERIES ───────────────────────────────────────────────────────────────

    /// <summary>Возвращает Uid предмета в слоте, или null.</summary>
    public string GetItemUid(string slotKey) =>
        Slots.TryGetValue(slotKey, out var uid) ? uid : null;

    /// <summary>Занят ли слот.</summary>
    public bool IsOccupied(string slotKey) =>
        Slots.TryGetValue(slotKey, out var uid) && uid != null;

    /// <summary>Все занятые слоты категории.</summary>
    public IEnumerable<string> GetOccupiedSlotsOfCategory(string category)
    {
        foreach (var kv in Slots)
            if (kv.Value != null && kv.Key.StartsWith(category + "_", StringComparison.Ordinal))
                yield return kv.Key;
    }

    /// <summary>Все ключи слотов категории (включая пустые).</summary>
    public IEnumerable<string> GetAllSlotsOfCategory(string category)
    {
        foreach (var kv in Slots)
            if (kv.Key.StartsWith(category + "_", StringComparison.Ordinal))
                yield return kv.Key;
    }

    // ── MUTATION ──────────────────────────────────────────────────────────────

    /// <summary>Устанавливает предмет в слот. Возвращает предыдущий Uid (или null).</summary>
    public string Set(string slotKey, string itemUid)
    {
        Slots.TryGetValue(slotKey, out var prev);
        Slots[slotKey] = itemUid;
        return prev;
    }

    /// <summary>Очищает слот. Возвращает Uid предмета который был там (или null).</summary>
    public string Clear(string slotKey)
    {
        Slots.TryGetValue(slotKey, out var prev);
        Slots[slotKey] = null;
        return prev;
    }

    /// <summary>
    /// Пересобирает слоты под новую серию корпуса.
    /// Слоты которые остаются — сохраняются. Новые добавляются пустыми.
    /// Удалённые слоты возвращаются как список Uid для выгрузки в инвентарь.
    /// </summary>
    public List<string> RebuildForSeries(HullSeriesConfig series, EquipmentConfig equipConfig)
    {
        var evicted = new List<string>();
        var newSlots = new Dictionary<string, string>();

        foreach (var kv in series.Slots)
        {
            string category = kv.Key;
            int maxGlobal = equipConfig.GetTypeConfig(category)?.MaxSlots ?? 1;
            int count = Mathf.Min(kv.Value, maxGlobal);

            for (int i = 0; i < count; i++)
            {
                string key = $"{category}_{i}";
                // Сохраняем существующие
                newSlots[key] = Slots.TryGetValue(key, out var uid) ? uid : null;
            }
        }

        // Слоты которые были и не вошли в новый набор → выгрузить
        foreach (var kv in Slots)
            if (kv.Value != null && !newSlots.ContainsKey(kv.Key))
                evicted.Add(kv.Value);

        Slots = newSlots;
        return evicted;
    }

    /// <summary>
    /// Инициализирует слоты для серии корпуса (с нуля, без переноса).
    /// Вызывается при первом надевании корпуса или спавне корабля.
    /// </summary>
    public void InitForSeries(HullSeriesConfig series, EquipmentConfig equipConfig)
    {
        Slots.Clear();
        if (series == null) return;

        foreach (var kv in series.Slots)
        {
            string category = kv.Key;
            int maxGlobal = equipConfig.GetTypeConfig(category)?.MaxSlots ?? 1;
            int count = Mathf.Min(kv.Value, maxGlobal);
            for (int i = 0; i < count; i++)
                Slots[$"{category}_{i}"] = null;
        }
    }
}

// ── SHIP INVENTORY ────────────────────────────────────────────────────────────

/// <summary>
/// Трюм корабля — предметы не установленные в слоты.
/// Число слотов не ограничено; ограничение — вместимость корпуса (freeSpace).
///
/// Два типа хранения:
///   Items  — обычные предметы (ItemInstance), каждый уникален.
///   Stacks — стакаемые предметы (ItemStack), хранятся по ItemId.
///            Используются для минералов: каждая единица = 1 вес.
/// </summary>
[Serializable]
public class ShipInventory
{
    public List<ItemInstance> Items { get; set; } = new();

    /// <summary>
    /// Стопки стакаемых предметов (минералы и др.).
    /// Ключ — ItemId (например "CommonMineral").
    /// Каждая единица стека = 1 вес.
    /// </summary>
    public Dictionary<string, ItemStack> Stacks { get; set; } = new();

    [JsonIgnore]
    private readonly Dictionary<string, ItemInstance> _index = new();

    // ── QUERIES ───────────────────────────────────────────────────────────────

    public ItemInstance GetByUid(string uid) =>
        _index.TryGetValue(uid, out var item) ? item : null;

    public bool Contains(string uid) => _index.ContainsKey(uid);

    public int Count => Items.Count;

    /// <summary>Суммарный вес предметов + стаков.</summary>
    public int TotalWeight()
    {
        int w = 0;
        foreach (var item in Items) w += item.Weight;
        return w + TotalStacksWeight();
    }

    /// <summary>Суммарный вес всех стаков (минералов).</summary>
    public int TotalStacksWeight()
    {
        int w = 0;
        foreach (var s in Stacks.Values) w += s.TotalWeight;
        return w;
    }

    // ── MUTATION — обычные предметы ───────────────────────────────────────────

    public void Add(ItemInstance item)
    {
        if (item == null) return;
        Items.Add(item);
        _index[item.Uid] = item;
    }

    public bool Remove(string uid)
    {
        var item = GetByUid(uid);
        if (item == null) return false;
        Items.Remove(item);
        _index.Remove(uid);
        return true;
    }

    public ItemInstance TakeByUid(string uid)
    {
        var item = GetByUid(uid);
        if (item != null) Remove(uid);
        return item;
    }

    // ── MUTATION — стаки ──────────────────────────────────────────────────────

    /// <summary>
    /// Добавляет стопку в инвентарь.
    /// Если стопка с таким ItemId уже существует — увеличивает TotalWeight.
    /// </summary>
    public void AddStack(ItemStack stack)
    {
        if (stack == null || string.IsNullOrEmpty(stack.ItemId)) return;

        if (Stacks.TryGetValue(stack.ItemId, out var existing))
        {
            existing.TotalWeight += stack.TotalWeight;
        }
        else
        {
            Stacks[stack.ItemId] = new ItemStack
            {
                ItemId = stack.ItemId,
                Category = stack.Category,
                Name = stack.Name,
                TotalWeight = stack.TotalWeight,
                BasePrice = stack.BasePrice
            };
        }
    }

    /// <summary>
    /// Забирает amount единиц из стопки.
    /// Возвращает ItemStack с реально взятым количеством (может быть меньше amount).
    /// Если стопка опустела — удаляет её из словаря.
    /// Возвращает null если стопка с таким ItemId не найдена.
    /// </summary>
    public ItemStack TakeStack(string itemId, int amount)
    {
        if (!Stacks.TryGetValue(itemId, out var stack)) return null;

        int taken = Mathf.Min(amount, stack.TotalWeight);
        stack.TotalWeight -= taken;

        if (stack.TotalWeight <= 0)
            Stacks.Remove(itemId);

        return new ItemStack
        {
            ItemId = stack.ItemId,
            Category = stack.Category,
            Name = stack.Name,
            TotalWeight = taken,
            BasePrice = stack.BasePrice
        };
    }

    /// <summary>Перестраивает индекс после десериализации.</summary>
    public void RebuildIndex()
    {
        _index.Clear();
        foreach (var item in Items)
            if (item != null) _index[item.Uid] = item;
    }
}