﻿using UnityEngine;
using System.Collections.Generic;

public enum SortLayer
{
    // ── Фон (параллакс) ──────────────────────────────────────────────────────
    BackgroundVoid = -100,   // чёрная подложка
    BackgroundStarsFar = -95,    // дальние звёзды параллакса
    BackgroundStarsMid = -90,    // средние звёзды параллакса
    BackgroundStarsNear = -85,    // ближние звёзды параллакса

    // ── Планеты и их слои ────────────────────────────────────────────────────
    Planet = 0,      // корневой объект планеты (не рендерит сам)
    SatelliteDown = 2,      // спутник «за» планетой
    PlanetSurface = 5,      // поверхность планеты (шейдер Custom/PlanetRotation)
    PlanetAtmosphere = 6,      // атмосфера / облака
    PlanetOrbital = 7,      // кольца / орбитальные объекты
    SatelliteUp = 8,      // спутник «перед» планетой

    // ── Звезда ───────────────────────────────────────────────────────────────
    Star = 10,     // корневой объект звезды

    // ── Астероиды ─────────────────────────────────────────────────────────────
    Asteroid = 15,     // астероиды — между звездой (10) и кораблями (19+)

    // ── Корабли ──────────────────────────────────────────────────────────────
    ShipThruster = 19,     // шлейф двигателя (под корпусом)
    ShipNpc = 20,     // NPC-корабли, транспорты
    ShipBig = 25,     // крупные корабли / станции
    ShipPlayer = 30,     // корабль игрока (всегда поверх NPC)

    // ── Вспомогательные объекты ──────────────────────────────────────────────
    PathDot = 25,     // точки маршрута (PathRenderer)
    HelperOverlay = 45,     // прочие helper-визуализации

    // ── Интерфейс (UI) ───────────────────────────────────────────────────────
    Interface = 100,    // все UI-элементы поверх всего
}

public static class SortingLayerRegistry
{
    // Обращение по перечислению — основной способ.
    public static int Get(SortLayer layer) => (int)layer;

    // Обращение по строковому имени — для случаев, когда слой хранится как string.
    // Возвращает 0 и пишет предупреждение, если имя не найдено.
    private static readonly Dictionary<string, int> _byName = BuildNameMap();

    public static int Get(string layerName)
    {
        if (_byName.TryGetValue(layerName, out int value)) return value;
        UnityEngine.Debug.LogWarning($"[SortingLayerRegistry] Unknown layer name: '{layerName}'. Returning 0.");
        return 0;
    }

    // Смещение от базового слоя — удобно для внутренних sub-layers.
    // Пример: SortingLayerRegistry.Offset(SortLayer.SatelliteDown, -1)
    public static int Offset(SortLayer layer, int delta) => (int)layer + delta;

    private static Dictionary<string, int> BuildNameMap()
    {
        var map = new Dictionary<string, int>();
        foreach (SortLayer layer in System.Enum.GetValues(typeof(SortLayer)))
            map[layer.ToString()] = (int)layer;
        return map;
    }
}