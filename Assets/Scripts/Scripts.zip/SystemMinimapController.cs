using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;

// =====================================================================
// SystemMinimapController.cs
// Мини-карта текущей звёздной системы.
//
// Отображает:
//   - Иконку звезды в центре
//   - Эллиптические орбиты планет (EllipseOrbitGraphic)
//   - Иконки планет, двигающиеся по орбитам
//   - Прямоугольник видимой области камеры
//
// Взаимодействие:
//   - ЛКМ / Drag по минимапе перемещает камеру в соответствующую мировую точку.
//   - IsMouseOverMinimap — статичный флаг для блокировки ввода CameraController.
// =====================================================================

public class SystemMinimapController : MonoBehaviour,
    IPointerClickHandler, IDragHandler, IPointerEnterHandler, IPointerExitHandler
{
    [Header("UI References")]
    [SerializeField] private RectTransform minimapContainer;
    [SerializeField] private RectTransform screenBoundsRect;
    [SerializeField] private Camera mainCamera;

    [Header("Settings")]
    [SerializeField] private Vector2 starIconSize = new Vector2(20, 20);
    [SerializeField] private Vector2 planetIconSize = new Vector2(6, 6);
    [SerializeField] private Vector2 playerIconSize = new Vector2(10, 10);
    [SerializeField] private float orbitAlpha = 0.3f;

    /// <summary>Fallback-иконка — используется если специфичная иконка звезды/планеты не найдена.</summary>
    private const string PlanetIconPath = "Graphics/Planets/Mask/minimap";

    /// <summary>
    /// Иконка астероида на миникарте.
    /// Берётся из GalaxyConstants.ASTEROID_MINIMAP_ICON_PATH.
    /// Если не найдена — используется тот же спрайт что и у планет/игрока.
    /// </summary>
    private static string AsteroidIconPath => GalaxyConstants.ASTEROID_MINIMAP_ICON_PATH;

    private float _worldRadius;
    private readonly Dictionary<PlanetData, RectTransform> _planetIcons = new Dictionary<PlanetData, RectTransform>();
    private readonly List<GameObject> _minimapObjects = new List<GameObject>();

    // Иконка игрока
    private RectTransform _playerIcon;

    // Иконки NPC-кораблей: ключ — ShipData.Uid
    private readonly Dictionary<string, Image> _npcShipImages = new Dictionary<string, Image>();

    // Иконки астероидов: ключ — AsteroidData.Uid
    private readonly Dictionary<string, RectTransform> _asteroidIcons = new Dictionary<string, RectTransform>();
    // Кэш Image для астероидов (для управления видимостью)
    private readonly Dictionary<string, Image> _asteroidImages = new Dictionary<string, Image>();

    // Линия траектории астероида при наведении
    private GameObject _asteroidTrailObj;
    private UnityEngine.UI.Image[] _asteroidTrailDots;
    private string _hoveredAsteroidUid;
    private const int TrailDotCount = 12;        // число точек предсказания
    private const int TrailPredictSteps = 40;    // раундов вперёд для предсказания

    // Dirty-флаг: обновляем screenBounds только когда камера реально переместилась.
    private Vector3 _lastCamPos;
    private float _lastCamSize;

    // ── Радар ────────────────────────────────────────────────────────────────
    // Жёлтое кольцо — граница дальности радара
    private EllipseOrbitGraphic _radarRingGraphic;
    private GameObject _radarRingObj;
    // Туман войны — тёмный overlay поверх зоны вне радара
    private RadarFogGraphic _radarFogGraphic;
    private GameObject _radarFogObj;
    // Последний рассчитанный радиус радара в мировых единицах
    private float _lastRadarWorldRadius = -1f;
    // Throttle для лог-спама радара (логируем раз в 2 сек)
    private float _radarLogTimer = 0f;
    private const float RadarLogInterval = 2f;
    // Throttle для диагностики Update (логируем раз в 3 сек, только первые 10 раз)
    private float _updateDiagTimer = 0f;
    private int _updateDiagCount = 0;
    private const int UpdateDiagMaxCount = 10;

    /// <summary>True пока курсор находится над минимапой. Читается CameraController.</summary>
    public static bool IsMouseOverMinimap { get; private set; }

    private bool IsReady => minimapContainer != null && mainCamera != null && _worldRadius > 0;

    // =========================================================================
    // Public API
    // =========================================================================

    /// <summary>
    /// Перестраивает минимапу для указанной звёздной системы.
    /// worldRadius — радиус системы в мировых единицах (SystemSize / 100f).
    /// </summary>
    public void InitializeMinimap(StarData star, float worldRadius)
    {
        ClearMinimap();
        if (minimapContainer == null) return;

        _worldRadius = worldRadius;

        CreateStarIcon(star);
        foreach (var planet in star.Planets)
        {
            CreateOrbitRing(planet);
            CreatePlanetIcon(planet);
        }

        // Иконки NPC-кораблей
        foreach (var ship in star.Ships)
            if (!ship.IsPlayer) CreateNpcShipIcon(ship);

        // Иконки астероидов
        foreach (var asteroid in star.Asteroids)
            if (!asteroid.IsDestroyed) CreateAsteroidIcon(asteroid);

        // Иконка игрока создаётся поверх всего — после инициализации системы.
        CreatePlayerIcon();

        SetupScreenBounds();
    }

    /// <summary>
    /// Вызывается из SystemViewManager когда визуал астероида создаётся в середине хода.
    /// Создаёт иконку на миникарте если её ещё нет.
    /// </summary>
    public void OnAsteroidSpawned(AsteroidData asteroid)
    {
        if (!_asteroidIcons.ContainsKey(asteroid.Uid))
            CreateAsteroidIcon(asteroid);
    }

    /// <summary>Удаляет все объекты минимапы и сбрасывает словарь иконок.</summary>
    public void ClearMinimap()
    {
        foreach (var obj in _minimapObjects)
            if (obj != null) Destroy(obj);
        _minimapObjects.Clear();
        _planetIcons.Clear();
        _npcShipImages.Clear();
        _asteroidIcons.Clear();
        _asteroidImages.Clear();
        _playerIcon = null;
        _hoveredAsteroidUid = null;
        _asteroidTrailDots = null;
        if (_asteroidTrailObj != null) { Destroy(_asteroidTrailObj); _asteroidTrailObj = null; }
        DestroyRadarVisuals();
    }

    /// <summary>
    /// Обновляет позицию иконки планеты на минимапе.
    /// Вызывается из SystemViewManager.AnimateSystem() каждый кадр во время хода.
    /// </summary>
    public void UpdatePlanetPosition(PlanetData planet, Vector3 worldPos)
    {
        if (_planetIcons.TryGetValue(planet, out var rt))
            rt.anchoredPosition = WorldToMapPos(worldPos);
    }

    /// <summary>
    /// Обновляет позицию иконки игрока на минимапе.
    /// Вызывается из SystemViewManager.AnimateSystem() каждый кадр.
    /// </summary>
    public void UpdatePlayerPosition(Vector2 worldPos)
    {
        if (_playerIcon != null)
            _playerIcon.anchoredPosition = WorldToMapPos(worldPos);
    }

    // =========================================================================
    // Unity lifecycle
    // =========================================================================

    private void OnEnable()
    {
        GalaxyManager.OnTurnComplete += OnTurnComplete;
    }

    private void OnDisable()
    {
        GalaxyManager.OnTurnComplete -= OnTurnComplete;
    }

    /// <summary>
    /// При завершении хода удаляем иконки уничтоженных астероидов.
    /// Делаем это здесь, а не в Update — к моменту Update астероид уже
    /// удалён из star.Asteroids и IsDestroyed проверить невозможно.
    /// </summary>
    private void OnTurnComplete(TurnAnimationData anim)
    {
        if (anim == null) return;
        foreach (var evt in anim.AsteroidDestroys)
            RemoveAsteroidIcon(evt.AsteroidUid);
    }

    private void Update()
    {
        // ── Диагностика IsReady (первые 10 раз) ──────────────────────────────
        if (_updateDiagCount < UpdateDiagMaxCount)
        {
            _updateDiagTimer -= Time.deltaTime;
            if (_updateDiagTimer <= 0f)
            {
                _updateDiagTimer = 3f;
                _updateDiagCount++;
                Debug.Log($"[Radar/Update] #{_updateDiagCount} IsReady={IsReady} " +
                          $"minimapContainer={minimapContainer != null} " +
                          $"mainCamera={mainCamera != null} " +
                          $"_worldRadius={_worldRadius} " +
                          $"screenBoundsRect={screenBoundsRect != null}");
            }
        }

        if (!IsReady || screenBoundsRect == null) return;

        Vector3 camPos = mainCamera.transform.position;
        float camSize = mainCamera.orthographicSize;

        // Обновляем bounds только при реальном изменении камеры — избегаем лишних вычислений.
        if (camPos != _lastCamPos || !Mathf.Approximately(camSize, _lastCamSize))
        {
            RefreshScreenBounds();
            _lastCamPos = camPos;
            _lastCamSize = camSize;
        }

        // Обновляем позицию игрока напрямую из Transform — работает и в паузе, и в анимации.
        Vector2 playerWorldPos = Vector2.zero;
        if (_playerIcon != null && PlayerShip.Instance != null)
        {
            var pp = PlayerShip.Instance.transform.position;
            playerWorldPos = new Vector2(pp.x, pp.y);
            _playerIcon.anchoredPosition = WorldToMapPos(pp);
            _playerIcon.SetAsLastSibling(); // всегда поверх планет и screenBounds
        }

        // ── Радар ────────────────────────────────────────────────────────────
        float radarWorldRadius = GetPlayerRadarWorldRadius();
        UpdateRadarVisuals(playerWorldPos, radarWorldRadius);

        // ── Видимость NPC-кораблей по радару ─────────────────────────────────
        foreach (var kv in _npcShipImages)
        {
            if (kv.Value == null) continue;
            // Позиция иконки NPC в мировых единицах — берём из её anchoredPosition
            Vector2 npcMapPos = kv.Value.rectTransform.anchoredPosition;
            Vector2 npcWorldPos = MapPosToWorld(npcMapPos);
            bool inRange = radarWorldRadius <= 0f ||
                           (npcWorldPos - playerWorldPos).magnitude <= radarWorldRadius;
            kv.Value.gameObject.SetActive(inRange);
        }

        // Обновляем позиции иконок астероидов
        var star = GalaxyManager.Instance?.CurrentStar;
        if (star?.Asteroids != null)
        {
            var svm = SystemViewManager.Instance;
            bool isAnimating = GalaxyManager.Instance?.Phase == TurnPhase.Animating;

            foreach (var asteroid in star.Asteroids)
            {
                Vector2 astWorldPos;
                if (_asteroidIcons.TryGetValue(asteroid.Uid, out var rt))
                {
                    if (isAnimating && svm != null && svm.TryGetAsteroidVisualPosition(asteroid.Uid, out var visPos))
                        astWorldPos = visPos;
                    else
                        astWorldPos = asteroid.Position;
                    rt.anchoredPosition = WorldToMapPos(astWorldPos);

                    // Видимость астероида по радару
                    bool inRange = radarWorldRadius <= 0f ||
                                   (astWorldPos - playerWorldPos).magnitude <= radarWorldRadius;
                    if (_asteroidImages.TryGetValue(asteroid.Uid, out var img) && img != null)
                        img.gameObject.SetActive(inRange);
                }
                else
                    CreateAsteroidIcon(asteroid);
            }
        }

        // Траектория при наведении на иконку астероида
        UpdateAsteroidTrail();
    }

    // =========================================================================
    // Масштабирование: единственный источник истины — WorldToMapScale()
    // =========================================================================

    /// <summary>
    /// Возвращает коэффициент пересчёта мировых координат в координаты минимапы.
    /// 95% от минимального размера контейнера делится на диаметр системы.
    /// </summary>
    private float WorldToMapScale()
    {
        if (minimapContainer == null || _worldRadius <= 0) return 1f;
        float minDim = Mathf.Min(minimapContainer.rect.width, minimapContainer.rect.height);
        return minDim * 0.95f / (_worldRadius * 2f);
    }

    /// <summary>Переводит мировую позицию в anchoredPosition на минимапе.</summary>
    private Vector2 WorldToMapPos(Vector3 worldPos)
    {
        float scale = WorldToMapScale();
        return new Vector2(worldPos.x * scale, worldPos.y * scale);
    }

    /// <summary>
    /// Обратный перевод anchoredPosition минимапы в мировые координаты.
    /// Использует тот же WorldToMapScale() — гарантирует согласованность.
    /// </summary>
    private Vector2 MapPosToWorld(Vector2 localPos)
    {
        float scale = WorldToMapScale();
        if (scale == 0f) return Vector2.zero;
        return localPos / scale;
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private void SetupScreenBounds()
    {
        if (screenBoundsRect == null) return;
        screenBoundsRect.SetAsLastSibling();
        _lastCamPos = Vector3.one * float.MaxValue; // принудительный первый refresh
        RefreshScreenBounds();
    }

    private void RefreshScreenBounds()
    {
        float scale = WorldToMapScale();
        float camHeight = 2f * mainCamera.orthographicSize;
        float camWidth = camHeight * mainCamera.aspect;
        screenBoundsRect.sizeDelta = new Vector2(camWidth * scale, camHeight * scale);
        screenBoundsRect.anchoredPosition = WorldToMapPos(mainCamera.transform.position);
    }

    private void CreateStarIcon(StarData star)
    {
        var (_, img, rt) = SpawnMinimapElement("Mini_Star", siblingIndex: 0);

        // Пробуем специфичную иконку звезды (MapIcon), иначе — общий fallback
        Sprite sprite = null;
        if (!string.IsNullOrEmpty(star.MapIcon)) sprite = Resources.Load<Sprite>(star.MapIcon);
        if (sprite == null) sprite = Resources.Load<Sprite>(PlanetIconPath);

        img.sprite = sprite;
        img.preserveAspect = true;
        rt.sizeDelta = starIconSize;
    }

    private void CreateOrbitRing(PlanetData planet)
    {
        float scale = WorldToMapScale();

        // Полуось a: из реального радиуса орбиты (делим на 100 для мировых единиц),
        // либо эстетический fallback если радиус не задан.
        float a = planet.OrbitRadius > 0f
            ? (planet.OrbitRadius / 100f)
            : (2f + planet.OrbitIndex * 1.5f);

        float e = Mathf.Clamp(planet.OrbitEccentricity, 0f, 0.99f);
        float b = a * Mathf.Sqrt(1f - e * e); // малая полуось
        float c = a * e;                       // расстояние от центра до фокуса

        var obj = new GameObject($"Mini_Orbit_{planet.Name}");
        var rt = obj.AddComponent<RectTransform>();
        var ellipse = obj.AddComponent<EllipseOrbitGraphic>();

        obj.transform.SetParent(minimapContainer, false);
        obj.transform.SetSiblingIndex(0);
        _minimapObjects.Add(obj);

        // Ширина = 2a, высота = 2b
        rt.sizeDelta = new Vector2(a * 2f * scale, b * 2f * scale);

        // Смещаем центр эллипса от фокуса (звезды в 0,0) с учётом наклона орбиты
        float tiltRad = planet.OrbitTiltDeg * Mathf.Deg2Rad;
        rt.anchoredPosition = new Vector2(
            -c * scale * Mathf.Cos(tiltRad),
            -c * scale * Mathf.Sin(tiltRad)
        );
        rt.localRotation = Quaternion.Euler(0f, 0f, planet.OrbitTiltDeg);

        ellipse.Eccentricity = e;
        ellipse.color = new Color(1f, 1f, 1f, orbitAlpha);
        ellipse.LineWidth = 1.5f;
        ellipse.Segments = CalculateOrbitSegments(a * scale);
    }

    /// <summary>
    /// Адаптивное число сегментов для орбитального эллипса:
    /// ~1 сегмент на 2px, минимум 32, максимум 256.
    /// </summary>
    private int CalculateOrbitSegments(float screenRadius)
    {
        int segments = Mathf.RoundToInt(screenRadius * Mathf.PI * 2f / 2f);
        return Mathf.Clamp(segments, 32, 256);
    }

    private void CreatePlanetIcon(PlanetData planet)
    {
        var (_, img, rt) = SpawnMinimapElement($"Mini_P_{planet.Name}", siblingIndex: 2);

        // Иконка: кастомная из PlanetData.MinimapIconPath или дефолт
        Sprite sprite = null;
        if (!string.IsNullOrEmpty(planet.MinimapIconPath))
            sprite = Resources.Load<Sprite>(planet.MinimapIconPath);
        if (sprite == null)
            sprite = Resources.Load<Sprite>(PlanetIconPath);
        img.sprite = sprite;

        // Цвет через OwnershipDisplayResolver
        var ctx = GalaxyManager.Instance?.Context;
        img.color = ctx != null
            ? OwnershipDisplayResolver.ResolvePlanetMinimapColor(planet, ctx)
            : (ColorUtility.TryParseHtmlString(planet.CurrentColor, out Color fallback) ? fallback : Color.white);

        rt.sizeDelta = planetIconSize;
        _planetIcons[planet] = rt;
    }

    /// <summary>
    /// Создаёт статическую иконку NPC-корабля на минимапе.
    /// Цвет определяется через OwnershipDisplayResolver по фракции корабля.
    /// NPC-корабли не анимируются на миникарте (упрощение для текущего этапа).
    /// </summary>
    private void CreateNpcShipIcon(ShipData ship)
    {
        var (_, img, rt) = SpawnMinimapElement($"Mini_Ship_{ship.Uid}", siblingIndex: 1);

        Sprite icon = null;
        if (!string.IsNullOrEmpty(ship.MinimapIconPath))
            icon = Resources.Load<Sprite>(ship.MinimapIconPath);
        if (icon == null)
            icon = Resources.Load<Sprite>(PlanetIconPath);

        img.sprite = icon;

        var ctx = GalaxyManager.Instance?.Context;
        img.color = ctx != null
            ? OwnershipDisplayResolver.ResolveShipMinimapColor(ship, ctx)
            : Color.white;

        rt.sizeDelta = planetIconSize;
        rt.anchoredPosition = WorldToMapPos(ship.Position);

        // Сохраняем Image для управления видимостью через радар
        _npcShipImages[ship.Uid] = img;
    }

    /// <summary>
    /// Создаёт иконку корабля игрока на минимапе.
    /// Использует MinimapIcon из ShipVisualController если доступна, иначе — fallback.
    /// </summary>
    private void CreatePlayerIcon()
    {
        var (_, img, rt) = SpawnMinimapElement("Mini_Player", siblingIndex: 0);

        // Пробуем иконку из ShipVisualController игрока
        Sprite icon = null;
        if (PlayerShip.Instance != null)
            icon = PlayerShip.Instance.GetComponent<ShipVisualController>()?.GetMinimapIcon();
        if (icon == null)
            icon = Resources.Load<Sprite>(PlanetIconPath);

        img.sprite = icon;
        img.color = Color.white;
        rt.sizeDelta = playerIconSize;

        _playerIcon = rt;
    }

    private (GameObject obj, Image img, RectTransform rt) SpawnMinimapElement(string name, int siblingIndex)
    {
        var obj = new GameObject(name);
        var rt = obj.AddComponent<RectTransform>();
        var img = obj.AddComponent<Image>();
        obj.transform.SetParent(minimapContainer, false);
        obj.transform.SetSiblingIndex(siblingIndex);
        _minimapObjects.Add(obj);
        return (obj, img, rt);
    }

    // ── Asteroid minimap methods ──────────────────────────────────────────────

    /// <summary>
    /// Создаёт серую иконку астероида на миникарте.
    /// Размер чуть меньше планет для визуального различия.
    /// </summary>
    private void CreateAsteroidIcon(AsteroidData asteroid)
    {
        var (_, img, rt) = SpawnMinimapElement($"Mini_Asteroid_{asteroid.Uid}", siblingIndex: 1);

        Sprite icon = null;
        if (!string.IsNullOrEmpty(AsteroidIconPath))
            icon = Resources.Load<Sprite>(AsteroidIconPath);
        if (icon == null)
            icon = Resources.Load<Sprite>(PlanetIconPath);

        img.sprite = icon;
        img.color = new Color(0.72f, 0.68f, 0.60f, 0.9f); // тёплый серый — отличается от планет

        rt.sizeDelta = planetIconSize * 0.75f;
        rt.anchoredPosition = WorldToMapPos(asteroid.Position);

        _asteroidIcons[asteroid.Uid] = rt;
        _asteroidImages[asteroid.Uid] = img;

        // Делаем иконку интерактивной — отслеживаем наведение для траектории
        var trigger = (rt.gameObject.GetComponent<UnityEngine.EventSystems.EventTrigger>()
                    ?? rt.gameObject.AddComponent<UnityEngine.EventSystems.EventTrigger>());

        string uid = asteroid.Uid;
        var enterEntry = new UnityEngine.EventSystems.EventTrigger.Entry
        { eventID = UnityEngine.EventSystems.EventTriggerType.PointerEnter };
        enterEntry.callback.AddListener(_ => _hoveredAsteroidUid = uid);
        trigger.triggers.Add(enterEntry);

        var exitEntry = new UnityEngine.EventSystems.EventTrigger.Entry
        { eventID = UnityEngine.EventSystems.EventTriggerType.PointerExit };
        exitEntry.callback.AddListener(_ => { if (_hoveredAsteroidUid == uid) _hoveredAsteroidUid = null; });
        trigger.triggers.Add(exitEntry);
    }

    /// <summary>Удаляет иконку астероида с миникарты (при уничтожении).</summary>
    private void RemoveAsteroidIcon(string uid)
    {
        if (!_asteroidIcons.TryGetValue(uid, out var rt)) return;
        if (rt != null && rt.gameObject != null)
        {
            _minimapObjects.Remove(rt.gameObject);
            Destroy(rt.gameObject);
        }
        _asteroidIcons.Remove(uid);
        _asteroidImages.Remove(uid);

        if (_hoveredAsteroidUid == uid)
        {
            _hoveredAsteroidUid = null;
            SetTrailVisible(false);
        }
    }

    /// <summary>
    /// Обновляет линию предсказанной траектории астероида.
    /// Симулирует TrailPredictSteps раундов вперёд — только позицию и гравитацию,
    /// без коллизий, для визуальной подсказки.
    /// </summary>
    private void UpdateAsteroidTrail()
    {
        if (string.IsNullOrEmpty(_hoveredAsteroidUid))
        {
            SetTrailVisible(false);
            return;
        }

        var star = GalaxyManager.Instance?.CurrentStar;
        AsteroidData src = star?.Asteroids?.Find(a => a.Uid == _hoveredAsteroidUid);
        if (src == null || src.IsDestroyed)
        {
            SetTrailVisible(false);
            return;
        }

        EnsureTrailDots();
        SetTrailVisible(true);

        // Симулируем траекторию — только физика, без коллизий
        float gravityConst = GalaxyManager.Instance?.Context?.Config?.Asteroids?.GravityConst
                             ?? GalaxyConstants.ASTEROID_GRAVITY_CONST;

        var pos = src.Position;
        var vel = src.Velocity;
        float systemRadius = (star.SystemSize / 100f) * 1.5f;

        int step = Mathf.Max(1, TrailPredictSteps / TrailDotCount);
        int dotIdx = 0;

        for (int i = 0; i < TrailPredictSteps && dotIdx < TrailDotCount; i++)
        {
            // Гравитация (та же формула что в AsteroidSystem.ApplyGravity)
            Vector2 toStar = -pos;
            float distSq = toStar.sqrMagnitude;
            if (distSq >= 0.01f)
            {
                float acc = gravityConst / distSq;
                vel += toStar.normalized * acc / GalaxyData.TurnRounds;
            }
            pos += vel / GalaxyData.TurnRounds;

            // Раз в step шагов — ставим точку
            if ((i + 1) % step == 0)
            {
                var dot = _asteroidTrailDots[dotIdx];
                dot.rectTransform.anchoredPosition = WorldToMapPos(pos);

                // Прозрачность убывает по мере удаления от астероида
                float alpha = Mathf.Lerp(0.7f, 0.1f, (float)dotIdx / TrailDotCount);
                dot.color = new Color(1f, 0.85f, 0.3f, alpha); // оранжево-жёлтый

                // Уменьшаем если вышел за границу системы
                if (pos.magnitude > systemRadius)
                {
                    // Гасим оставшиеся точки
                    for (int j = dotIdx; j < TrailDotCount; j++)
                        _asteroidTrailDots[j].color = Color.clear;
                    break;
                }
                dotIdx++;
            }
        }

        // Гасим неиспользованные точки
        for (int i = dotIdx; i < TrailDotCount; i++)
            _asteroidTrailDots[i].color = Color.clear;
    }

    /// <summary>Создаёт точки траектории если ещё не созданы.</summary>
    private void EnsureTrailDots()
    {
        if (_asteroidTrailDots != null && _asteroidTrailDots.Length == TrailDotCount) return;

        if (_asteroidTrailObj != null) Destroy(_asteroidTrailObj);
        _asteroidTrailObj = new GameObject("AsteroidTrail");
        _asteroidTrailObj.transform.SetParent(minimapContainer, false);
        _minimapObjects.Add(_asteroidTrailObj);

        _asteroidTrailDots = new UnityEngine.UI.Image[TrailDotCount];
        float dotSize = 2.5f;
        for (int i = 0; i < TrailDotCount; i++)
        {
            var go = new GameObject($"TrailDot_{i}");
            go.transform.SetParent(_asteroidTrailObj.transform, false);
            var img = go.AddComponent<UnityEngine.UI.Image>();
            var rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(dotSize, dotSize);

            // Загружаем спрайт точки — используем тот же что у планет
            var sprite = Resources.Load<Sprite>(PlanetIconPath);
            if (sprite != null) img.sprite = sprite;
            img.color = Color.clear;

            // Точки не должны перехватывать клики
            img.raycastTarget = false;

            _asteroidTrailDots[i] = img;
        }
    }

    /// <summary>Показывает/скрывает все точки траектории.</summary>
    private void SetTrailVisible(bool visible)
    {
        if (_asteroidTrailDots == null) return;
        if (!visible)
            foreach (var dot in _asteroidTrailDots)
                if (dot != null) dot.color = Color.clear;
    }

    // =========================================================================
    // Radar — кольцо и туман войны
    // =========================================================================

    /// <summary>
    /// Возвращает дальность радара игрока в мировых единицах.
    /// 0 = нет радара (туман и кольцо не отображаются, всё видно).
    /// </summary>
    private float GetPlayerRadarWorldRadius()
    {
        var ship = PlayerShip.Instance?.ShipData;
        if (ship == null)
        {
            Debug.LogWarning("[Radar] GetPlayerRadarWorldRadius: PlayerShip.Instance или ShipData == null");
            return 0f;
        }

        float result = EquipmentSystem.GetRadarRange(ship);
        return result;
    }

    /// <summary>
    /// Создаёт или обновляет кольцо радара и туман войны.
    /// Вызывается каждый кадр из Update().
    /// </summary>
    private void UpdateRadarVisuals(Vector2 playerWorldPos, float radarWorldRadius)
    {
        if (minimapContainer == null)
        {
            Debug.LogError("[Radar] UpdateRadarVisuals: minimapContainer == null!");
            return;
        }

        // Нет радара → полное затемнение (дырка радиуса 0 = вся карта закрыта)
        if (radarWorldRadius <= 0f)
        {
            if (_radarRingObj != null) _radarRingObj.SetActive(false);

            // Показываем туман с HoleRadius=0 — видна только точка центра (звезда)
            EnsureRadarFog();
            _radarFogObj.SetActive(true);
            var fogRtNoRadar = _radarFogObj.GetComponent<RectTransform>();
            fogRtNoRadar.anchoredPosition = Vector2.zero;
            fogRtNoRadar.sizeDelta = minimapContainer.rect.size;
            _radarFogGraphic.HoleCenter = Vector2.zero; // центр карты = звезда
            _radarFogGraphic.HoleRadius = 0f;           // дырки нет — всё закрыто
            _radarFogGraphic.SetVerticesDirty();

            _lastRadarWorldRadius = -1f;
            return;
        }

        float scale = WorldToMapScale();
        float radarMapRadius = radarWorldRadius * scale;
        Vector2 playerMapPos = playerWorldPos * scale;

        // ── Периодическое логирование (раз в RadarLogInterval сек) ───────────
        _radarLogTimer -= Time.deltaTime;
        if (_radarLogTimer <= 0f)
        {
            _radarLogTimer = RadarLogInterval;
            Debug.Log($"[Radar] ACTIVE: worldRadius={radarWorldRadius:F2} mapScale={scale:F2} " +
                      $"mapRadius={radarMapRadius:F1}px playerWorldPos={playerWorldPos} " +
                      $"playerMapPos={playerMapPos} containerSize={minimapContainer.rect.size}");
        }

        // ── Кольцо ───────────────────────────────────────────────────────────
        EnsureRadarRing();
        _radarRingObj.SetActive(true);
        var ringRt = _radarRingObj.GetComponent<RectTransform>();
        ringRt.anchoredPosition = playerMapPos;
        float ringDiameter = radarMapRadius * 2f;
        ringRt.sizeDelta = new Vector2(ringDiameter, ringDiameter);
        _radarRingGraphic.SetLayoutDirty();

        // ── Туман войны ───────────────────────────────────────────────────────
        EnsureRadarFog();
        _radarFogObj.SetActive(true);
        var fogRt = _radarFogObj.GetComponent<RectTransform>();
        fogRt.anchoredPosition = Vector2.zero;
        fogRt.sizeDelta = minimapContainer.rect.size;
        _radarFogGraphic.HoleCenter = playerMapPos;
        _radarFogGraphic.HoleRadius = radarMapRadius;
        _radarFogGraphic.SetVerticesDirty();

        _lastRadarWorldRadius = radarWorldRadius;
    }

    private void EnsureRadarRing()
    {
        if (_radarRingObj != null) return;

        Debug.Log("[Radar] EnsureRadarRing: создаём объект кольца радара");
        _radarRingObj = new GameObject("Radar_Ring");
        _radarRingObj.transform.SetParent(minimapContainer, false);

        var rt = _radarRingObj.AddComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);

        _radarRingGraphic = _radarRingObj.AddComponent<EllipseOrbitGraphic>();
        _radarRingGraphic.Eccentricity = 0f;
        _radarRingGraphic.LineWidth = 1.5f;
        _radarRingGraphic.Segments = 64;
        _radarRingGraphic.color = new Color(1f, 0.9f, 0.1f, 0.85f); // жёлтый
        _radarRingGraphic.raycastTarget = false;

        // Кольцо поверх всех иконок, но под туманом
        _radarRingObj.transform.SetSiblingIndex(minimapContainer.childCount - 1);
    }

    private void EnsureRadarFog()
    {
        if (_radarFogObj != null) return;

        Debug.Log("[Radar] EnsureRadarFog: создаём объект тумана войны");
        _radarFogObj = new GameObject("Radar_Fog");
        _radarFogObj.transform.SetParent(minimapContainer, false);

        var rt = _radarFogObj.AddComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.sizeDelta = Vector2.zero;
        rt.anchoredPosition = Vector2.zero;

        _radarFogGraphic = _radarFogObj.AddComponent<RadarFogGraphic>();
        _radarFogGraphic.FogColor = new Color(0f, 0f, 0f, 0.6f);
        _radarFogGraphic.raycastTarget = false;
        _radarFogGraphic.Segments = 64;

        // Туман поверх всего остального на миникарте
        _radarFogObj.transform.SetAsLastSibling();
    }

    private void DestroyRadarVisuals()
    {
        if (_radarRingObj != null) { Destroy(_radarRingObj); _radarRingObj = null; _radarRingGraphic = null; }
        if (_radarFogObj != null) { Destroy(_radarFogObj); _radarFogObj = null; _radarFogGraphic = null; }
        _lastRadarWorldRadius = -1f;
    }

    private void MoveCameraToPoint(PointerEventData eventData)
    {
        if (!IsReady) return;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            minimapContainer, eventData.position, eventData.pressEventCamera, out Vector2 local))
        {
            Vector2 worldXY = MapPosToWorld(local);
            mainCamera.transform.position = new Vector3(
                worldXY.x,
                worldXY.y,
                mainCamera.transform.position.z
            );
            RefreshScreenBounds();
        }
    }

    // =========================================================================
    // Event handlers
    // =========================================================================
    public void OnDrag(PointerEventData e) => MoveCameraToPoint(e);
    public void OnPointerClick(PointerEventData e) => MoveCameraToPoint(e);
    public void OnPointerEnter(PointerEventData e) => IsMouseOverMinimap = true;
    public void OnPointerExit(PointerEventData e) => IsMouseOverMinimap = false;
}