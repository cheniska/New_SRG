﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Text;

// =====================================================================
// InventoryUIController.cs
// Панель снаряжения игрока. Открывается клавишей InventoryKey (default: I).
//
// Подключение:
//   1. GameObject → UI → Canvas (если нет)
//   2. Внутри Canvas: Create Empty → "InventoryUI"
//   3. Add Component → InventoryUIController
//   4. Назначить поле Settings → твой GameSettingsConfig
//   5. Все UI-объекты создаются автоматически в Start()
// =====================================================================

public class InventoryUIController : MonoBehaviour
{
    [Header("Настройки")]
    public GameSettingsConfig Settings;

    [Tooltip("Fallback-клавиша если Settings не назначен.")]
    public KeyCode FallbackKey = KeyCode.I;

    // ── Runtime ───────────────────────────────────────────────────────────────
    private GameObject _panel;
    private Text _textComponent;
    private ScrollRect _scrollRect;
    private bool _isVisible;
    private KeyCode _toggleKey;

    // ── Unity Lifecycle ───────────────────────────────────────────────────────

    private void Start()
    {
        _toggleKey = (Settings != null) ? Settings.InventoryKey : FallbackKey;
        BuildUI();
        _panel.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKeyDown(_toggleKey))
            Toggle();
    }

    private void OnEnable()
    {
        GalaxyManager.OnTurnCalculate += OnTurnCalculate;
    }

    private void OnDisable()
    {
        GalaxyManager.OnTurnCalculate -= OnTurnCalculate;
    }

    private void OnTurnCalculate(TurnAnimationData _)
    {
        // Закрываем инвентарь при начале хода
        if (_isVisible)
        {
            _isVisible = false;
            _panel.SetActive(false);
        }
    }

    // ── Toggle ────────────────────────────────────────────────────────────────

    private void Toggle()
    {
        // Открытие инвентаря невозможно во время анимации хода
        if (GalaxyManager.Instance?.Phase == TurnPhase.Animating)
        {
            Debug.Log("[InventoryUIController] Cannot open inventory during turn animation.");
            return;
        }

        _isVisible = !_isVisible;
        _panel.SetActive(_isVisible);
        if (_isVisible)
            StartCoroutine(RefreshNextFrame());
    }

    private System.Collections.IEnumerator RefreshNextFrame()
    {
        yield return null;

        Refresh();

        yield return null;

        Canvas.ForceUpdateCanvases();
        if (_scrollRect != null)
        {
            LayoutRebuilder.ForceRebuildLayoutImmediate(_scrollRect.content);
            _scrollRect.verticalNormalizedPosition = 1f;
        }

        // Диагностика
        if (_textComponent != null)
        {
            var rt = _textComponent.GetComponent<RectTransform>();
            Debug.Log($"[Inventory] text='{_textComponent.text.Substring(0, Mathf.Min(40, _textComponent.text.Length))}'");
            Debug.Log($"[Inventory] text color={_textComponent.color}");
            Debug.Log($"[Inventory] content rect={rt.rect}  sizeDelta={rt.sizeDelta}");
            Debug.Log($"[Inventory] content pos={rt.anchoredPosition}");
            Debug.Log($"[Inventory] viewport rect={_scrollRect?.viewport?.rect}");
            Debug.Log($"[Inventory] panel active={_panel.activeSelf}");
        }
    }

    // ── Refresh content ───────────────────────────────────────────────────────

    private void Refresh()
    {
        if (_textComponent == null) return;

        var ship = PlayerShip.Instance?.ShipData;
        if (ship == null)
        {
            _textComponent.text = "Нет данных о корабле.";
            return;
        }

        var equipConfig = GalaxyManager.Instance?.Context?.Equipment;
        var sb = new StringBuilder(1024);

        // ── Характеристики ────────────────────────────────────────────────────
        float speed = ship.ActualSpeed;
        int equippedW = EquipmentSystem.GetEquippedWeight(ship);
        int inventoryW = ship.Inventory.TotalWeight();
        int totalW = equippedW + inventoryW;
        int hullCap = EquipmentSystem.GetHullCapacity(ship);
        int freeSpace = EquipmentSystem.GetFreeSpace(ship);
        int fuel = EquipmentSystem.GetCurrentFuel(ship);
        int fuelCap = EquipmentSystem.GetFuelCapacity(ship);
        int jumpRange = EquipmentSystem.GetJumpRange(ship);

        sb.AppendLine($"Корабль : {ship.Name}");
        sb.AppendLine($"HP      : {ship.CurrentHull} / {ship.MaxHull}");
        sb.AppendLine($"Скорость: {speed:F0}");
        sb.AppendLine($"Вес     : {totalW}  (снар: {equippedW}  груз: {inventoryW})");
        sb.AppendLine($"Корпус  : {hullCap}  свободно: {freeSpace}");
        if (fuelCap > 0)
            sb.AppendLine($"Топливо : {fuel} / {fuelCap}    прыжок: {jumpRange}");

        // ── Снаряжение ────────────────────────────────────────────────────────
        sb.AppendLine("");
        sb.AppendLine("=== Снаряжение ===");

        if (ship.Equipment == null || ship.Equipment.Slots.Count == 0)
        {
            sb.AppendLine("  (нет слотов)");
        }
        else
        {
            var groups = new Dictionary<string, List<string>>();
            foreach (var key in ship.Equipment.Slots.Keys)
            {
                string cat = EquipmentSystem.SlotCategory(key);
                if (!groups.ContainsKey(cat)) groups[cat] = new List<string>();
                groups[cat].Add(key);
            }

            foreach (var kv in groups)
            {
                string label = GetCategoryLabel(kv.Key, equipConfig);
                sb.AppendLine($"  [{label}]");
                foreach (var slotKey in kv.Value)
                {
                    string uid = ship.Equipment.GetItemUid(slotKey);
                    if (uid == null || !ship.AllItems.TryGetValue(uid, out var item))
                    {
                        sb.AppendLine("    -- пусто");
                        continue;
                    }
                    string dur = item.NoWear ? "без износа" : $"прочн: {item.Durability}/{item.MaxDurability}";
                    sb.AppendLine($"    {item.Name}  |  {dur}{GetExtra(item)}");
                }
            }
        }

        // ── Трюм ─────────────────────────────────────────────────────────────
        if (ship.Inventory != null && ship.Inventory.Count > 0)
        {
            sb.AppendLine("");
            sb.AppendLine($"=== Трюм ({ship.Inventory.Count} пред.) ===");
            foreach (var item in ship.Inventory.Items)
            {
                if (item == null) continue;
                sb.AppendLine($"  {item.Category}: {item.Name}  вес: {item.Weight}");
            }
        }

        // ── Минералы (стаки) ──────────────────────────────────────────────────────
        if (ship.Inventory.Stacks != null && ship.Inventory.Stacks.Count > 0)
        {
            sb.AppendLine("");
            sb.AppendLine("=== Минералы ===");
            foreach (var kv in ship.Inventory.Stacks)
            {
                var stack = kv.Value;
                sb.AppendLine($"  {stack.Name}: {stack.TotalWeight} ед." +
                              $"  (цена: {stack.BasePrice}/ед.  итого: {stack.TotalPrice})");
            }
            sb.AppendLine($"  Итого: {ship.Inventory.TotalStacksWeight()} ед.");
        }

        _textComponent.text = sb.ToString();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private string GetExtra(ItemInstance item)
    {
        switch (item.Category)
        {
            case "Engine":
                return $"  скор: {item.GetParam("Speed"):F0}  прыжок: {item.GetParam("JumpRange"):F0}";
            case "FuelTank":
                return $"  объём: {item.GetParam("Capacity"):F0}";
            case "Shield":
                return $"  блок: {item.GetParam("BlockPercent"):F0}%";
            case "Weapons":
                return $"  {item.GetParam("MinDmg"):F0}-{item.GetParam("MaxDmg"):F0} ({item.GetParamString("DamageType", "?")})  дальн: {item.GetParam("Range"):F0}";
            case "Hull":
                return $"  HP: {item.GetParam("HP"):F0}  броня: {item.GetParam("Armor"):F0}  [{item.GetParamString("Series", "?")}]";
            case "Radar":
                return $"  радиус: {item.GetParam("Range"):F0}";
            case "Droid":
                {
                    float healPt = item.GetParam("HealPerTurn");
                    float dmg = item.GetParam("Damage");
                    float ht = item.GetParam("WearThreshold", 30f);
                    string r = "";
                    if (healPt > 0f) r += $"  лечение: +{healPt:F0}/ход  накоп: {item.HealAccumulator:F0}/{ht:F0}";
                    if (dmg > 0f) r += $"  урон: {dmg:F0}";
                    return r;
                }
            case "CargoGrabber":
                {
                    float ct = item.GetParam("WearThreshold", 5000f);
                    return $"  мощн: {item.GetParam("Power"):F0}  дальн: {item.GetParam("Range"):F0}" +
                           $"  накоп: {item.CargoAccumulator:F0}/{ct:F0}";
                }
            case "Artefacts":
                {
                    float sm = item.GetParam("SpeedMult", 1f);
                    float h = item.GetParam("HealPerTurn");
                    string r = "";
                    if (sm != 1f) r += $"  скор x{sm:F2}";
                    if (h > 0f) r += $"  рем +{h:F0}/ход";
                    return r;
                }
            default: return "";
        }
    }

    private string GetCategoryLabel(string cat, EquipmentConfig cfg)
    {
        if (cfg != null)
        {
            var t = cfg.GetTypeConfig(cat);
            if (t != null && !string.IsNullOrEmpty(t.DisplayName)) return t.DisplayName;
        }
        return cat switch
        {
            "Hull" => "Корпус",
            "Engine" => "Двигатель",
            "FuelTank" => "Топливный бак",
            "Forsage" => "Форсаж",
            "Shield" => "Щит",
            "Radar" => "Радар",
            "Scaner" => "Сканер",
            "Droid" => "Дроид",
            "CargoGrabber" => "Грузовой захват",
            "Weapons" => "Оружие",
            "Artefacts" => "Артефакты",
            _ => cat
        };
    }

    // ── Build UI ──────────────────────────────────────────────────────────────

    private void BuildUI()
    {
        // ── Панель ────────────────────────────────────────────────────────────
        _panel = new GameObject("InventoryPanel");
        _panel.transform.SetParent(transform, false);

        var panelRt = _panel.AddComponent<RectTransform>();
        panelRt.anchorMin = new Vector2(0.5f, 0.5f);
        panelRt.anchorMax = new Vector2(0.5f, 0.5f);
        panelRt.pivot = new Vector2(0.5f, 0.5f);
        panelRt.sizeDelta = new Vector2(640f, 540f);
        panelRt.anchoredPosition = Vector2.zero;

        _panel.AddComponent<Image>().color = new Color(0.04f, 0.06f, 0.10f, 0.96f);

        // ── Заголовок ─────────────────────────────────────────────────────────
        {
            var go = new GameObject("Title");
            go.transform.SetParent(_panel.transform, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.sizeDelta = new Vector2(-40f, 38f);
            rt.anchoredPosition = new Vector2(0f, 0f);
            var txt = go.AddComponent<Text>();
            txt.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            txt.text = "Снаряжение корабля  [I]";
            txt.fontSize = 17;
            txt.fontStyle = FontStyle.Bold;
            txt.color = new Color(0.65f, 0.85f, 1f);
            txt.alignment = TextAnchor.MiddleCenter;
        }

        // ── Кнопка закрытия ───────────────────────────────────────────────────
        {
            var go = new GameObject("CloseBtn");
            go.transform.SetParent(_panel.transform, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.sizeDelta = new Vector2(36f, 36f);
            rt.anchoredPosition = new Vector2(-2f, 0f);
            go.AddComponent<Image>().color = new Color(0.55f, 0.1f, 0.1f, 0.9f);
            var btn = go.AddComponent<Button>();
            btn.onClick.AddListener(() => { _isVisible = false; _panel.SetActive(false); });

            var tgo = new GameObject("X");
            tgo.transform.SetParent(go.transform, false);
            var trt = tgo.AddComponent<RectTransform>();
            trt.anchorMin = Vector2.zero; trt.anchorMax = Vector2.one; trt.sizeDelta = Vector2.zero;
            var ttxt = tgo.AddComponent<Text>();
            ttxt.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            ttxt.text = "X"; ttxt.fontSize = 16; ttxt.color = Color.white;
            ttxt.alignment = TextAnchor.MiddleCenter;
        }

        // ── Разделитель ───────────────────────────────────────────────────────
        {
            var go = new GameObject("Divider");
            go.transform.SetParent(_panel.transform, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.01f, 1f);
            rt.anchorMax = new Vector2(0.99f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.sizeDelta = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(0f, -38f);
            go.AddComponent<Image>().color = new Color(0.3f, 0.45f, 0.65f, 0.6f);
        }

        // ── Scrollbar ─────────────────────────────────────────────────────────
        GameObject sbHandleGo;
        Scrollbar scrollbar;
        {
            var sbGo = new GameObject("Scrollbar");
            sbGo.transform.SetParent(_panel.transform, false);
            var sbRt = sbGo.AddComponent<RectTransform>();
            sbRt.anchorMin = new Vector2(1f, 0f);
            sbRt.anchorMax = new Vector2(1f, 1f);
            sbRt.pivot = new Vector2(1f, 1f);
            sbRt.offsetMin = new Vector2(-14f, 0f);
            sbRt.offsetMax = new Vector2(0f, -40f);
            sbGo.AddComponent<Image>().color = new Color(0.08f, 0.08f, 0.12f, 0.9f);
            scrollbar = sbGo.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.BottomToTop;

            var areaGo = new GameObject("SlidingArea");
            areaGo.transform.SetParent(sbGo.transform, false);
            var areaRt = areaGo.AddComponent<RectTransform>();
            areaRt.anchorMin = Vector2.zero; areaRt.anchorMax = Vector2.one; areaRt.sizeDelta = Vector2.zero;

            sbHandleGo = new GameObject("Handle");
            sbHandleGo.transform.SetParent(areaGo.transform, false);
            var handleRt = sbHandleGo.AddComponent<RectTransform>();
            handleRt.anchorMin = Vector2.zero; handleRt.anchorMax = Vector2.one; handleRt.sizeDelta = Vector2.zero;
            var handleImg = sbHandleGo.AddComponent<Image>();
            handleImg.color = new Color(0.3f, 0.5f, 0.75f, 0.85f);

            scrollbar.handleRect = handleRt;
            scrollbar.targetGraphic = handleImg;
        }

        // ── Viewport ──────────────────────────────────────────────────────────
        var vpGo = new GameObject("Viewport");
        vpGo.transform.SetParent(_panel.transform, false);
        var vpRt = vpGo.AddComponent<RectTransform>();
        vpRt.anchorMin = Vector2.zero;
        vpRt.anchorMax = Vector2.one;
        vpRt.offsetMin = new Vector2(4f, 4f);
        vpRt.offsetMax = new Vector2(-18f, -42f);
        // RectMask2D не требует Image и работает надёжнее чем Mask+Image
        vpGo.AddComponent<RectMask2D>();

        // ── Content ───────────────────────────────────────────────────────────
        var contentGo = new GameObject("Content");
        contentGo.transform.SetParent(vpGo.transform, false);
        var contentRt = contentGo.AddComponent<RectTransform>();
        // Якорь: прибит к верху viewport, растягивается по ширине
        contentRt.anchorMin = new Vector2(0f, 1f);
        contentRt.anchorMax = new Vector2(1f, 1f);
        contentRt.pivot = new Vector2(0f, 1f);
        contentRt.sizeDelta = new Vector2(0f, 0f);
        contentRt.anchoredPosition = Vector2.zero;

        _textComponent = contentGo.AddComponent<Text>();
        _textComponent.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        _textComponent.fontSize = 14;
        _textComponent.color = new Color(0.88f, 0.88f, 0.92f);
        _textComponent.alignment = TextAnchor.UpperLeft;
        _textComponent.supportRichText = false;
        _textComponent.horizontalOverflow = HorizontalWrapMode.Wrap;
        _textComponent.verticalOverflow = VerticalWrapMode.Overflow;
        _textComponent.lineSpacing = 1.2f;

        // ContentSizeFitter — высота Content подстраивается под текст
        var fitter = contentGo.AddComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        // ── ScrollRect (на панели) ────────────────────────────────────────────
        _scrollRect = _panel.AddComponent<ScrollRect>();
        _scrollRect.content = contentRt;
        _scrollRect.viewport = vpRt;
        _scrollRect.horizontal = false;
        _scrollRect.vertical = true;
        _scrollRect.scrollSensitivity = 40f;
        _scrollRect.movementType = ScrollRect.MovementType.Clamped;
        _scrollRect.verticalScrollbar = scrollbar;
        _scrollRect.verticalScrollbarVisibility =
            ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport;
        _scrollRect.verticalNormalizedPosition = 1f;
    }
}